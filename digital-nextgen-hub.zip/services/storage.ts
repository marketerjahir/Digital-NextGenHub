import { User, Transaction, MonthlyUpdate, TransactionType } from '../types';

const KEYS = {
  USERS: 'dnh_users',
  TRANSACTIONS: 'dnh_transactions',
  MONTHLY_UPDATES: 'dnh_monthly_updates',
  CURRENT_USER_ID: 'dnh_current_user_id',
  RECENT_NUMBERS: 'dnh_recent_numbers',
  ACADEMIC_HISTORY: 'dnh_academic_history',
  ACADEMIC_LOGO: 'dnh_academic_logo',
  THEME: 'dnh_theme',
  ADMIN_CREDS: 'dnh_admin_creds'
};

const cloudSync = {
  user: (user: User) => {
    try { (window as any).google?.script?.run?.syncUserToCloud(user); } catch(e) {}
  },
  transaction: (tx: Transaction) => {
    try { (window as any).google?.script?.run?.syncTransactionToCloud(tx); } catch(e) {}
  },
  login: (userId: string, userName: string) => {
    try { (window as any).google?.script?.run?.syncLoginToCloud(userId, userName); } catch(e) {}
  }
};

export const StorageService = {
  getUsers: (): User[] => {
    const data = localStorage.getItem(KEYS.USERS);
    return data ? JSON.parse(data) : [];
  },

  saveUser: (user: User) => {
    const users = StorageService.getUsers();
    users.push(user);
    localStorage.setItem(KEYS.USERS, JSON.stringify(users));
    cloudSync.user(user);
  },

  updateUser: (updatedUser: User) => {
    const users = StorageService.getUsers();
    const index = users.findIndex(u => u.id === updatedUser.id);
    if (index !== -1) {
      users[index] = updatedUser;
      localStorage.setItem(KEYS.USERS, JSON.stringify(users));
      cloudSync.user(updatedUser);
    }
  },

  deleteUser: (id: string) => {
    const users = StorageService.getUsers().filter(u => u.id !== id);
    localStorage.setItem(KEYS.USERS, JSON.stringify(users));
    try { (window as any).google?.script?.run?.deleteUserGlobally(id); } catch(e) {}
  },

  findUser: (id: string): User | undefined => {
    const users = StorageService.getUsers();
    return users.find(u => u.id === id);
  },

  updateUserPassword: (id: string, newPass: string) => {
    const users = StorageService.getUsers();
    const index = users.findIndex(u => u.id === id);
    if (index !== -1) {
      users[index].password = newPass;
      localStorage.setItem(KEYS.USERS, JSON.stringify(users));
      cloudSync.user(users[index]);
    }
  },

  login: (id: string): void => {
    localStorage.setItem(KEYS.CURRENT_USER_ID, id);
    const u = StorageService.findUser(id);
    if (u) cloudSync.login(u.id, u.fullName);
  },

  logout: (): void => {
    localStorage.removeItem(KEYS.CURRENT_USER_ID);
  },

  getCurrentUser: (): User | null => {
    const id = localStorage.getItem(KEYS.CURRENT_USER_ID);
    if (!id) return null;
    return StorageService.findUser(id) || null;
  },

  getTheme: (): 'light' | 'dark' => {
    return (localStorage.getItem(KEYS.THEME) as 'light' | 'dark') || 'light';
  },

  saveTheme: (theme: 'light' | 'dark') => {
    localStorage.setItem(KEYS.THEME, theme);
  },

  getTransactions: (userId: string): Transaction[] => {
    const data = localStorage.getItem(KEYS.TRANSACTIONS);
    const all: Transaction[] = data ? JSON.parse(data) : [];
    return all.filter(t => t.userId === userId);
  },

  saveTransaction: (tx: Transaction) => {
    const data = localStorage.getItem(KEYS.TRANSACTIONS);
    const all: Transaction[] = data ? JSON.parse(data) : [];
    all.push(tx);
    localStorage.setItem(KEYS.TRANSACTIONS, JSON.stringify(all));
    cloudSync.transaction(tx);
  },

  updateTransaction: (tx: Transaction) => {
    const data = localStorage.getItem(KEYS.TRANSACTIONS);
    const all: Transaction[] = data ? JSON.parse(data) : [];
    const index = all.findIndex(t => t.id === tx.id);
    if (index !== -1) {
      all[index] = tx;
      localStorage.setItem(KEYS.TRANSACTIONS, JSON.stringify(all));
      // Optionally sync to cloud if your backend supports update
      try { (window as any).google?.script?.run?.syncTransactionToCloud(tx); } catch(e) {}
    }
  },

  getMonthlyUpdates: (userId: string): MonthlyUpdate[] => {
    const data = localStorage.getItem(KEYS.MONTHLY_UPDATES);
    const all: MonthlyUpdate[] = data ? JSON.parse(data) : [];
    return all.filter(u => u.userId === userId);
  },

  saveMonthlyUpdate: (update: MonthlyUpdate) => {
    const data = localStorage.getItem(KEYS.MONTHLY_UPDATES);
    const all: MonthlyUpdate[] = data ? JSON.parse(data) : [];
    all.push(update);
    localStorage.setItem(KEYS.MONTHLY_UPDATES, JSON.stringify(all));
  },

  getRecentNumbers: (): string[] => {
    const data = localStorage.getItem(KEYS.RECENT_NUMBERS);
    return data ? JSON.parse(data) : [];
  },

  saveRecentNumber: (num: string) => {
    const numbers = StorageService.getRecentNumbers();
    if (!numbers.includes(num)) {
      numbers.push(num);
      localStorage.setItem(KEYS.RECENT_NUMBERS, JSON.stringify(numbers));
    }
  },

  getAcademicHistory: (field: string): string[] => {
    const data = localStorage.getItem(KEYS.ACADEMIC_HISTORY);
    const history = data ? JSON.parse(data) : {};
    return history[field] || [];
  },

  saveAcademicEntry: (field: string, value: string) => {
    if (!value || value.trim() === '') return;
    const data = localStorage.getItem(KEYS.ACADEMIC_HISTORY);
    const history = data ? JSON.parse(data) : {};
    const fieldHistory = history[field] || [];
    if (!fieldHistory.includes(value)) {
      fieldHistory.push(value);
      history[field] = fieldHistory;
      localStorage.setItem(KEYS.ACADEMIC_HISTORY, JSON.stringify(history));
    }
  },

  getAcademicLogo: (): string | null => {
    return localStorage.getItem(KEYS.ACADEMIC_LOGO);
  },

  saveAcademicLogo: (base64: string | null) => {
    if (base64) {
      localStorage.setItem(KEYS.ACADEMIC_LOGO, base64);
    } else {
      localStorage.removeItem(KEYS.ACADEMIC_LOGO);
    }
  },

  getAdminCreds: () => {
    const data = localStorage.getItem(KEYS.ADMIN_CREDS);
    return data ? JSON.parse(data) : { id: 'master_admin', pass1: 'digital77', pass2: 'hub99' };
  },

  saveAdminCreds: (id: string, p1: string, p2: string) => {
    localStorage.setItem(KEYS.ADMIN_CREDS, JSON.stringify({ id, pass1: p1, pass2: p2 }));
    try { (window as any).google?.script?.run?.updateAdminCreds(id, p1, p2); } catch(e) {}
  }
};