
export enum TransactionType {
  CASH_IN = 'Cash In',
  CASH_OUT = 'Cash Out',
  MOBILE_RECHARGE = 'Mobile Recharge',
  BILL_PAY = 'Bill Pay',
  SEND_MONEY = 'Send Money'
}

export interface User {
  id: string; // Auto-generated
  fullName: string;
  country: string; // Added
  countryCode: string; // Added
  mobile: string;
  email: string; // Added
  password: string;
  registeredAt: string;
  profilePic?: string; // Base64 string for profile image
}

export interface Transaction {
  id: string;
  userId: string;
  type: TransactionType;
  mobileNumber: string;
  customerName: string;
  amount: number;
  charge: number;
  note: string;
  timestamp: string; // ISO string
  dateStr: string; // YYYY-MM-DD for easy grouping
}

export interface MonthlyUpdate {
  id: string;
  userId: string;
  month: string; // YYYY-MM
  addedAmount: number;
  timestamp: string;
  personName?: string; // Support for multiple individuals
}

export type Screen = 
  | 'LOGIN' 
  | 'REGISTER' 
  | 'FORGOT_PASSWORD' 
  | 'HOME' 
  | 'PROFILE' 
  | 'DASHBOARD_ENTRY' 
  | 'HISTORY' 
  | 'DAILY_TX' 
  | 'MONTHLY_HISAB' 
  | 'TOTAL_HISAB' 
  | 'GAME_ZONE' 
  | 'CALCULATOR' 
  | 'PRAYER_TIMES'
  | 'BAZAR_HISAB'
  | 'ACADEMIC_ZONE'
  | 'LAB_REPORT'
  | 'INDEX_CREATE'
  | 'ASSIGNMENT_COVER'
  | 'NORMAL_CV'
  | 'CHANGE_PASSWORD'
  | 'ISLAMIC_HUB'
  | 'HADITH_ZONE'
  | 'SURAH_ZONE'
  | 'ISLAMIC_ADVICE'
  | 'PROPHETS_ZONE'
  | 'SAHABA_ZONE'
  | 'SCIENTIST_ZONE'
  | 'ADMIN_LOGIN'
  | 'ADMIN_DASHBOARD';
