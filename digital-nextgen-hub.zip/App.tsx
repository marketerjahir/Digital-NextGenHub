
import React, { useState, useEffect, useRef } from 'react';
import { Layout, Button, Input } from './components/Layout';
import { Screen, User, TransactionType } from './types';
import { StorageService } from './services/storage';
import { Icons, COUNTRIES } from './constants';
import { Dashboard } from './pages/Dashboard';
import { History } from './pages/History';
import { MonthlyHisab } from './pages/MonthlyHisab';
import { GameZone } from './pages/GameZone';
import { Calculator } from './pages/Calculator';
import { PrayerTimes } from './pages/PrayerTimes';
import { BazarHisab } from './pages/BazarHisab';
import { LabReport } from './pages/LabReport';
import { IndexCreate } from './pages/IndexCreate';
import { AssignmentCover } from './pages/AssignmentCover';
import { NormalCV } from './pages/NormalCV';
import { ChangePassword } from './pages/ChangePassword'; // Using specific component if extracted
import { IslamicHub } from './pages/IslamicHub';
import { HadithZone } from './pages/HadithZone';
import { SurahZone } from './pages/SurahZone';
import { IslamicAdvice } from './pages/IslamicAdvice';
import { ProphetsZone } from './pages/ProphetsZone';
import { SahabaZone } from './pages/SahabaZone';
import { ScientistZone } from './pages/ScientistZone';
import { AdminPanel } from './pages/AdminPanel';

const App: React.FC = () => {
  const [screen, setScreen] = useState<Screen>('LOGIN');
  const [user, setUser] = useState<User | null>(null);
  const [isDarkMode, setIsDarkMode] = useState(false);
  
  // Auth Form States
  const [userId, setUserId] = useState('');
  const [password, setPassword] = useState('');
  const [loginError, setLoginError] = useState('');
  
  // Registration States
  const [fullName, setFullName] = useState('');
  const [selectedCountry, setSelectedCountry] = useState(COUNTRIES.find(c => c.name === "Bangladesh")?.name || COUNTRIES[0].name);
  const [mobile, setMobile] = useState('');
  const [email, setEmail] = useState('');
  const [regPassword, setRegPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [registerSuccessId, setRegisterSuccessId] = useState('');
  
  // Forgot Password States
  const [forgotUserId, setForgotUserId] = useState('');
  const [forgotMobile, setForgotMobile] = useState('');
  const [forgotEmail, setForgotEmail] = useState('');
  const [forgotError, setForgotError] = useState('');
  const [forgotSuccessMsg, setForgotSuccessMsg] = useState('');
  
  // UI Feedback States
  const [regError, setRegError] = useState('');
  const [copyFeedback, setCopyFeedback] = useState('');
  const [showUserInfo, setShowUserInfo] = useState(false);

  // Change Password State
  const [oldPass, setOldPass] = useState('');
  const [newPass, setNewPass] = useState('');
  const [confirmNewPass, setConfirmNewPass] = useState('');
  const [cpUserId, setCpUserId] = useState('');
  const [cpMobile, setCpMobile] = useState('');
  const [cpError, setCpError] = useState('');
  const [cpSuccess, setCpSuccess] = useState(false);

  // Profile Edit States
  const [isEditingEmail, setIsEditingEmail] = useState(false);
  const [tempEmail, setTempEmail] = useState('');

  // Admin Entry Logic
  const [adminClicks, setAdminClicks] = useState(0);
  // Fix: Using ReturnType<typeof setTimeout> instead of NodeJS.Timeout for browser compatibility
  const adminTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    // Check if user is already logged in
    const currentUser = StorageService.getCurrentUser();
    if (currentUser) {
      setUser(currentUser);
      setScreen('HOME');
    }
    // Load theme
    setIsDarkMode(StorageService.getTheme() === 'dark');
  }, []);

  const toggleDarkMode = () => {
    const newMode = !isDarkMode;
    setIsDarkMode(newMode);
    StorageService.saveTheme(newMode ? 'dark' : 'light');
  };

  const handleAdminEntry = () => {
    setAdminClicks(prev => {
      const newCount = prev + 1;
      if (newCount === 1) {
        adminTimerRef.current = setTimeout(() => {
          setAdminClicks(0);
        }, 10000);
      }
      if (newCount >= 5) {
        if (adminTimerRef.current) clearTimeout(adminTimerRef.current);
        setScreen('ADMIN_LOGIN');
        return 0;
      }
      return newCount;
    });
  };

  const handleLogin = () => {
    setLoginError('');
    const foundUser = StorageService.findUser(userId);
    if (foundUser && foundUser.password === password) {
      StorageService.login(userId);
      setUser(foundUser);
      setScreen('HOME');
      setUserId('');
      setPassword('');
      setLoginError('');
    } else {
      setLoginError("Invalid User ID or Password");
    }
  };

  const handleRegister = () => {
    setRegError(''); // Reset error

    // 1. Check all fields
    if (!fullName || !selectedCountry || !mobile || !email || !regPassword || !confirmPassword) {
      setRegError("রেজিস্ট্রেশন করার জন্য সব ইনফরমেশন গুলো সঠিকভাবে পূরণ করতে হবে");
      return;
    }

    // 2. Validate Mobile (Must be exactly 11 digits)
    if (!/^\d{11}$/.test(mobile)) {
      setRegError("Mobile number must be exactly 11 digits.");
      return;
    }

    // 3. Validate Gmail
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
       setRegError("Please enter a valid email address.");
       return;
    }
    // Strict Gmail check based on "Valid Gmail" requirement
    if (!email.toLowerCase().endsWith('@gmail.com')) {
      setRegError("Please enter a valid Gmail address (ending with @gmail.com).");
      return;
    }

    // 4. Validate Password Length (Minimum 6 characters)
    if (regPassword.length < 6) {
      setRegError("পাসওয়ার্ড অবশ্যই কমপক্ষে ৬ সংখ্যার হতে হবে");
      return;
    }

    // 5. Validate Password Match
    if (regPassword !== confirmPassword) {
      setRegError("Passwords do not match. Please retype correctly.");
      return;
    }

    // 6. Check for duplicate mobile number (ENSURING UNIQUE NUMBER)
    const allUsers = StorageService.getUsers();
    if (allUsers.some(u => u.mobile === mobile)) {
      setRegError("এই মোবাইল নম্বরটি দিয়ে ইতিমধ্যে রেজিস্ট্রেশন করা হয়েছে। অনুগ্রহ করে লগইন করুন।");
      return;
    }

    // 7. Generate User ID
    const nameParts = fullName.trim().split(/\s+/);
    let baseName = "";
    if (nameParts.length >= 3) {
      baseName = nameParts[1];
    } else if (nameParts.length > 0) {
      baseName = nameParts[0];
    } else {
      baseName = "User";
    }

    let newId = "";
    let isUnique = false;

    // Safety loop for uniqueness
    while (!isUnique) {
      // Changed to 3 digits (100-999)
      const rand3 = Math.floor(100 + Math.random() * 900); 
      const alphabet = "abcdefghijklmnopqrstuvwxyz";
      const randChar = alphabet.charAt(Math.floor(Math.random() * alphabet.length));
      
      newId = `${baseName}${rand3}${randChar}`;
      
      // Check if ID exists (highly unlikely but good practice)
      if (!allUsers.some(u => u.id === newId)) {
        isUnique = true;
      }
    }
    
    const countryData = COUNTRIES.find(c => c.name === selectedCountry);

    const newUser: User = {
      id: newId,
      fullName,
      country: selectedCountry,
      countryCode: countryData ? countryData.code : '',
      mobile,
      email,
      password: regPassword,
      registeredAt: new Date().toISOString()
    };
    
    StorageService.saveUser(newUser);
    setRegisterSuccessId(newId);
    
    // Clear form
    setFullName('');
    setMobile('');
    setEmail('');
    setRegPassword('');
    setConfirmPassword('');
    setRegError('');
    setSelectedCountry(COUNTRIES.find(c => c.name === "Bangladesh")?.name || COUNTRIES[0].name);
  };

  const handleLogout = () => {
    StorageService.logout();
    setUser(null);
    setScreen('LOGIN');
    setShowUserInfo(false);
  };

  const handleChangePassword = () => {
    setCpError('');
    if (!user) return;
    
    // Validation
    if (!cpUserId || !cpMobile || !oldPass || !newPass || !confirmNewPass) {
      setCpError("সবগুলো ফিল্ড সঠিকভাবে পূরণ করুন");
      return;
    }

    if (cpUserId !== user.id) {
      setCpError("ইউজার আইডি সঠিক নয়");
      return;
    }

    if (cpMobile !== user.mobile) {
      setCpError("মোাবাইল নাম্বার সঠিক নয়");
      return;
    }

    if (user.password !== oldPass) {
      setCpError("বর্তমান পাসওয়ার্ড সঠিক নয়");
      return;
    }

    if (newPass.length < 6) {
      setCpError("নতুন পাসওয়ার্ড কমপক্ষে ৬ সংখ্যার হতে হবে");
      return;
    }

    if (newPass !== confirmNewPass) {
      setCpError("নতুন পাসওয়ার্ড দুটি মিলছে না");
      return;
    }

    StorageService.updateUserPassword(user.id, newPass);
    setCpSuccess(true);
    
    // Update local state user for session continuity
    const updatedUser = { ...user, password: newPass };
    setUser(updatedUser);
    
    // Reset states after a short delay or success view
    setOldPass('');
    setNewPass('');
    setConfirmNewPass('');
    setCpUserId('');
    setCpMobile('');
  };

  const handleCopyId = () => {
    if (user?.id) {
        navigator.clipboard.writeText(user.id);
        setCopyFeedback("Copied!");
        setTimeout(() => setCopyFeedback(''), 2000);
    } else if (registerSuccessId) {
        navigator.clipboard.writeText(registerSuccessId);
        setCopyFeedback("কপি হয়েছে");
        setTimeout(() => setCopyFeedback(''), 3000);
    }
  };

  const handleCopyWhatsapp = () => {
    navigator.clipboard.writeText("+8801400420407");
    setCopyFeedback("নাম্বার কপি হয়েছে");
    setTimeout(() => setCopyFeedback(''), 3000);
  };

  const handleResetPassword = () => {
    setForgotError('');
    setForgotSuccessMsg('');

    // Check if fields are empty
    if (!forgotUserId || !forgotMobile || !forgotEmail) {
      setForgotError("সব ইনফরমেশন সঠিকভাবে দিন");
      return;
    }

    const targetUser = StorageService.findUser(forgotUserId);
    
    // Validate User ID, Mobile, and Email
    if (!targetUser || targetUser.mobile !== forgotMobile || targetUser.email !== forgotEmail) {
        setForgotError("সব ইনফরমেশন সঠিকভাবে দিন");
        return;
    }

    // In a real app, this would send a notification to the admin dashboard.
    // For this prototype, we display the confirmation message requested by the user.
    setForgotSuccessMsg("নতুন পাসওয়ার্ড পেতে এডমিন প্যানেলের সাথে যোগাযোগ করুন Whatsapp +8801400420407");
    
    // Clear inputs after successful submission
    setForgotUserId('');
    setForgotMobile('');
    setForgotEmail('');
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && user) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64 = reader.result as string;
        const updatedUser = { ...user, profilePic: base64 };
        StorageService.updateUser(updatedUser);
        setUser(updatedUser);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleEmailUpdate = () => {
      if (!tempEmail || !tempEmail.includes('@') || !tempEmail.toLowerCase().endsWith('@gmail.com')) {
          alert("Invalid Gmail Address");
          return;
      }
      if (user) {
          const updatedUser = { ...user, email: tempEmail };
          StorageService.updateUser(updatedUser);
          setUser(updatedUser);
          setIsEditingEmail(false);
          setTempEmail('');
      }
  };

  // --- RENDERERS ---

  const renderCurrentScreen = () => {
    if (screen === 'LOGIN') {
      return (
        <Layout title="Login" hideBack isDarkMode={isDarkMode}>
          <div className="p-6 flex flex-col justify-center min-h-[80vh] space-y-6">
            <div className="text-center space-y-2">
              <div 
                onClick={handleAdminEntry}
                className="w-20 h-20 bg-brand-100 rounded-full flex items-center justify-center mx-auto text-brand-600 mb-4 animate-bounce cursor-pointer active:scale-95 transition-transform"
              >
                <Icons.Lock />
              </div>
              <h1 className={`text-2xl font-bold ${isDarkMode ? 'text-white' : 'text-gray-800'}`}>Digital NextGen Hub</h1>
              <p className="text-gray-500">Secure Transaction Portal</p>
            </div>
            
            <div className="space-y-4">
              <Input 
                placeholder="User ID" 
                value={userId} 
                onChange={e => { setUserId(e.target.value); setLoginError(''); }}
              />
              <Input 
                type="password" 
                placeholder="Password" 
                value={password} 
                onChange={e => { setPassword(e.target.value); setLoginError(''); }}
              />
              
              {loginError && (
                <div className="bg-red-50 border border-red-200 text-red-600 px-4 py-2 rounded-lg text-sm text-center animate-fade-in">
                  {loginError}
                </div>
              )}

              <Button onClick={handleLogin}>LOGIN</Button>
              
              <div className="flex justify-between text-sm mt-4">
                <button onClick={() => setScreen('FORGOT_PASSWORD')} className={`${isDarkMode ? 'text-gray-400' : 'text-gray-500'} hover:text-brand-600`}>Forgot Password?</button>
              </div>
            </div>

            <div className="mt-8 text-center border-t pt-6 border-gray-100 dark:border-white/10">
              <p className={`${isDarkMode ? 'text-gray-400' : 'text-gray-600'} mb-2`}>New User?</p>
              <Button variant="outline" onClick={() => setScreen('REGISTER')}>Register Now</Button>
            </div>

            <div className="mt-8 pt-4 text-center">
              <p className="text-xs text-gray-400">Apps Created By Md Jahirul Islam</p>
              <p className="text-[10px] text-gray-400">copyright 2026</p>
            </div>
          </div>
        </Layout>
      );
    }

    if (screen === 'FORGOT_PASSWORD') {
      return (
        <Layout title="Forgot Password" onBack={() => { setScreen('LOGIN'); setForgotError(''); setForgotSuccessMsg(''); }} isDarkMode={isDarkMode}>
          <div className="p-6 space-y-4">
            {!forgotSuccessMsg ? (
              <>
                <div className="text-center mb-6">
                  <div className="w-16 h-16 bg-brand-50 rounded-full flex items-center justify-center mx-auto text-brand-600 mb-2">
                    <Icons.Info size={32} />
                  </div>
                  <h2 className={`text-lg font-bold ${isDarkMode ? 'text-white' : 'text-gray-800'}`}>পাসওয়ার্ড পুনরুদ্ধার</h2>
                  <p className="text-xs text-gray-500">পূর্ববর্তী সকল তথ্য সঠিকভাবে প্রদান করুন</p>
                </div>

                <div className="space-y-4">
                  <div>
                    <label className="block text-[10px] font-black uppercase text-gray-400 mb-1 ml-1">User ID</label>
                    <Input 
                      placeholder="আপনার ইউজার আইডি দিন" 
                      value={forgotUserId} 
                      onChange={e => setForgotUserId(e.target.value)} 
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-black uppercase text-gray-400 mb-1 ml-1">Mobile Number</label>
                    <Input 
                      placeholder="আপনার মোবাইল নম্বর দিন" 
                      value={forgotMobile} 
                      onChange={e => setForgotMobile(e.target.value)} 
                      type="tel"
                      maxLength={11}
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-black uppercase text-gray-400 mb-1 ml-1">Registered Gmail</label>
                    <Input 
                      placeholder="আপনার রেজিস্টার্ড ইমেইল দিন" 
                      value={forgotEmail} 
                      onChange={e => setForgotEmail(e.target.value)} 
                      type="email"
                    />
                  </div>

                  {forgotError && (
                    <div className="bg-red-50 border border-red-200 text-red-600 px-4 py-3 rounded-xl text-xs text-center font-bold animate-fade-in">
                      {forgotError}
                    </div>
                  )}

                  <Button onClick={handleResetPassword} className="py-4 font-black uppercase tracking-widest">Submit Request</Button>
                </div>
              </>
            ) : (
              <div className="text-center space-y-6 py-10 animate-fade-in">
                <div className="w-20 h-20 bg-green-100 text-green-600 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Icons.CheckCircle size={48} />
                </div>
                <div className={`border p-6 rounded-3xl space-y-4 ${isDarkMode ? 'bg-green-900/20 border-green-800' : 'bg-green-50 border-green-200'}`}>
                  <h2 className="text-lg font-black text-green-800 dark:text-green-500">রিকোয়েস্ট সফল হয়েছে!</h2>
                  <p className={`text-sm font-bold leading-relaxed ${isDarkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                    নতুন পাসওয়ার্ড পেতে এডমিন প্যানেলের সাথে যোগাযোগ করুন 
                    <br />
                    <span className="text-brand-600 select-all font-black mt-2 inline-block">Whatsapp +8801400420407</span>
                  </p>
                  <button 
                    onClick={handleCopyWhatsapp}
                    className="bg-brand-600 text-white px-4 py-2 rounded-xl text-xs font-black uppercase tracking-widest flex items-center justify-center gap-2 mx-auto active:scale-95 transition-transform"
                  >
                    <Icons.Copy size={14} /> নাম্বার কপি করুন
                  </button>
                  {copyFeedback && <p className="text-[10px] text-green-600 font-black animate-slide-up">{copyFeedback}</p>}
                </div>
                <Button onClick={() => setScreen('LOGIN')} variant="outline" className="font-black uppercase tracking-widest">Go to Login</Button>
              </div>
            )}
          </div>
        </Layout>
      );
    }

    if (screen === 'REGISTER') {
      const currentCountryCode = COUNTRIES.find(c => c.name === selectedCountry)?.code || '';

      return (
        <Layout title="Registration" onBack={() => { setScreen('LOGIN'); setRegError(''); }} isDarkMode={isDarkMode}>
          <div className="p-6 space-y-4">
            {!registerSuccessId ? (
              <>
                <div>
                  <label className={`block text-sm font-medium mb-1 ${isDarkMode ? 'text-gray-300' : 'text-gray-700'}`}>Full Name</label>
                  <Input placeholder="Enter full name" value={fullName} onChange={e => setFullName(e.target.value)} />
                </div>

                <div>
                  <label className={`block text-sm font-medium mb-1 ${isDarkMode ? 'text-gray-300' : 'text-gray-700'}`}>Country</label>
                  <select 
                    className={`w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-500 transition-colors ${isDarkMode ? 'bg-gray-800 border-gray-700 text-white' : 'bg-white border-gray-300'}`}
                    value={selectedCountry}
                    onChange={(e) => setSelectedCountry(e.target.value)}
                  >
                    {COUNTRIES.map((c) => (
                      <option key={c.name} value={c.name} className={isDarkMode ? 'bg-gray-800' : ''}>
                        {c.name} ({c.code})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className={`block text-sm font-medium mb-1 ${isDarkMode ? 'text-gray-300' : 'text-gray-700'}`}>Mobile Number (11 digits)</label>
                  <div className="relative">
                    {currentCountryCode && (
                      <span className="absolute left-3 top-3 text-gray-500 text-sm pointer-events-none">{currentCountryCode}</span>
                    )}
                    <input 
                      className={`w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-500 focus:border-transparent transition-all text-sm ${isDarkMode ? 'bg-gray-800 border-gray-700 text-white' : 'bg-white border-gray-300'} ${currentCountryCode ? 'pl-14' : ''}`}
                      placeholder="01XXXXXXXXX"
                      value={mobile}
                      onChange={e => setMobile(e.target.value)}
                      type="tel"
                      maxLength={11}
                    />
                  </div>
                </div>

                <div>
                  <label className={`block text-sm font-medium mb-1 ${isDarkMode ? 'text-gray-300' : 'text-gray-700'}`}>Valid Gmail</label>
                  <Input type="email" placeholder="example@gmail.com" value={email} onChange={e => setEmail(e.target.value)} />
                </div>

                <div>
                  <label className={`block text-sm font-medium mb-1 ${isDarkMode ? 'text-gray-300' : 'text-gray-700'}`}>Set Password (Min 6 chars)</label>
                  <Input type="password" placeholder="Enter password" value={regPassword} onChange={e => setRegPassword(e.target.value)} />
                </div>

                <div>
                  <label className={`block text-sm font-medium mb-1 ${isDarkMode ? 'text-gray-300' : 'text-gray-700'}`}>Retype Password</label>
                  <Input type="password" placeholder="Confirm password" value={confirmPassword} onChange={e => setConfirmPassword(e.target.value)} />
                </div>

                {regError && (
                  <div className="bg-red-50 border border-red-200 text-red-600 px-4 py-3 rounded-lg text-sm text-center animate-fade-in font-bold">
                    {regError}
                  </div>
                )}

                <Button onClick={handleRegister}>Register</Button>
              </>
            ) : (
              <div className="text-center space-y-4 py-10">
                <div className="text-green-500 text-5xl mb-4">✓</div>
                <h2 className={`text-xl font-bold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>Registration Successful!</h2>
                <div className={`p-4 rounded-lg border ${isDarkMode ? 'bg-brand-900/20 border-brand-800' : 'bg-yellow-50 border-yellow-200'}`}>
                  <p className="text-sm text-gray-500 mb-1">Your User ID (Save this!)</p>
                  <div className="flex flex-col items-center justify-center gap-2">
                    <span className={`font-mono text-2xl font-bold break-all ${isDarkMode ? 'text-brand-400' : 'text-gray-800'}`}>{registerSuccessId}</span>
                    <button 
                      onClick={handleCopyId} 
                      className="text-brand-600 text-xs font-bold border px-2 py-1 rounded hover:bg-brand-50"
                    >
                      COPY
                    </button>
                    {copyFeedback && (
                      <span className="text-green-600 text-xs font-bold animate-fade-in">{copyFeedback}</span>
                    )}
                  </div>
                </div>
                <p className="text-red-500 text-sm font-semibold">এই User ID দিয়ে ভবিষ্যতে লগইন করতে হবে</p>
                <Button onClick={() => { setRegisterSuccessId(''); setScreen('LOGIN'); }}>Go to Login</Button>
              </div>
            )}
          </div>
        </Layout>
      );
    }

    if (screen === 'HOME' && user) {
      const menuItems = [
        { id: 'profile', label: 'My Profile', icon: <Icons.User />, action: () => setScreen('PROFILE') },
        { id: 'dashboard', label: 'Dashboard', icon: <Icons.TrendingUp />, action: () => setScreen('DASHBOARD_ENTRY') },
        { id: 'history', label: 'Dashboard History', icon: <Icons.History />, action: () => setScreen('HISTORY') },
        { id: 'daily', label: 'Daily Transaction', icon: <Icons.PieChart />, action: () => setScreen('DAILY_TX') },
        { id: 'monthly', label: 'Monthly Hisab', icon: <Icons.PieChart />, action: () => setScreen('MONTHLY_HISAB') },
        { id: 'total', label: 'Total All Hisab', icon: <Icons.PieChart />, action: () => setScreen('TOTAL_HISAB') },
        { id: 'game', label: 'Game Zone', icon: <Icons.Gamepad />, action: () => setScreen('GAME_ZONE') },
        { id: 'calc', label: 'Calculator', icon: <Icons.Calculator />, action: () => setScreen('CALCULATOR') },
        { id: 'prayer', label: 'Prayer Times', icon: <Icons.Sun />, action: () => setScreen('PRAYER_TIMES') },
        { id: 'bazar', label: 'Bazar Hisab', icon: <Icons.ShoppingBag />, action: () => setScreen('BAZAR_HISAB') },
        { id: 'academic', label: 'Academic Zone', icon: <Icons.GraduationCap />, action: () => setScreen('ACADEMIC_ZONE') },
        { id: 'islamic', label: 'Islamic Hub', icon: <Icons.Moon />, action: () => setScreen('ISLAMIC_HUB') },
      ];

      const HomeHeader = (
        <div className="flex justify-between items-center w-full relative">
          <div className="flex flex-col text-white">
            <h1 className="text-sm font-bold leading-tight">Digital NextGen Hub</h1>
            <p className="text-[10px] opacity-90 leading-tight">Welcome, {user.fullName}</p>
          </div>
          
          <div className="flex items-center gap-3">
            <div className="relative">
              <button 
                onClick={() => setShowUserInfo(!showUserInfo)} 
                className="bg-white/20 hover:bg-white/30 p-1.5 rounded-full transition"
              >
                <Icons.Info />
              </button>
              
              {showUserInfo && (
                <div className={`absolute right-0 top-10 p-3 rounded-xl shadow-xl z-50 w-48 border animate-fade-in text-xs ${isDarkMode ? 'bg-gray-800 border-gray-700 text-gray-100' : 'bg-white border-gray-100 text-gray-800'}`}>
                   <div className={`mb-2 pb-2 border-b ${isDarkMode ? 'border-white/10' : 'border-gray-100'}`}>
                     <span className="block text-gray-500 text-[10px]">User ID</span>
                     <span className="font-bold">{user.id}</span>
                   </div>
                   <div>
                     <span className="block text-gray-500 text-[10px]">Mobile</span>
                     <span className="font-bold">{user.mobile}</span>
                   </div>
                   <div className={`absolute -top-1 right-2 w-2 h-2 transform rotate-45 border-t border-l ${isDarkMode ? 'bg-gray-800 border-white/10' : 'bg-white border-gray-100'}`}></div>
                </div>
              )}
            </div>

            <div className="w-8 h-8 rounded-full overflow-hidden border-2 border-white/50 bg-white/20 flex items-center justify-center">
              {user.profilePic ? (
                <img src={user.profilePic} alt="Profile" className="w-full h-full object-cover" />
              ) : (
                <span className="text-xs font-bold text-white">{user.fullName.charAt(0)}</span>
              )}
            </div>
          </div>
        </div>
      );

      const HomeFooter = (
        <div className="flex items-center justify-between px-8 py-2 h-16 relative z-50">
          <button onClick={() => setScreen('HOME')} className="flex flex-col items-center justify-center group">
            <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-amber-400 via-brand-500 to-indigo-600 text-white flex items-center justify-center shadow-lg shadow-brand-200 group-active:scale-90 transition-all duration-300">
              <div className="transform scale-75"><Icons.Home /></div>
            </div>
            <span className="text-[9px] font-bold text-gray-500 mt-1 group-hover:text-brand-600 uppercase tracking-tighter">Home</span>
          </button>

          <div className="absolute left-1/2 -translate-x-1/2 -top-8">
             <div className={`p-1.5 rounded-2xl shadow-2xl border-2 transform active:scale-95 transition duration-300 ${isDarkMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-brand-100'}`}>
               <div className="bg-gradient-to-br from-brand-500 to-purple-600 p-1 rounded-xl">
                 <img 
                   src={`https://api.qrserver.com/v1/create-qr-code/?size=120x120&data=${encodeURIComponent(`ID:${user.id}\nName:${user.fullName}\nMobile:${user.mobile}`)}`} 
                   alt="Profile QR" 
                   className="w-14 h-14 object-contain rounded-lg bg-white"
                 />
               </div>
             </div>
          </div>

          <button onClick={handleLogout} className="flex flex-col items-center justify-center group">
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-red-400 to-red-600 text-white flex items-center justify-center shadow-lg shadow-red-200 group-active:scale-90 transition-all duration-300">
              <div className="transform scale-75"><Icons.LogOut /></div>
            </div>
            <span className="text-[9px] font-bold text-gray-500 mt-1 group-hover:text-red-600">Logout</span>
          </button>
        </div>
      );

      return (
        <Layout 
          customHeader={HomeHeader} 
          bottomNav={HomeFooter} 
          hideBack 
          isDarkMode={isDarkMode}
          className={isDarkMode ? 'bg-gradient-to-br from-slate-950 via-gray-900 to-slate-900' : 'bg-gradient-to-br from-indigo-50 via-purple-50 to-pink-50'}
        >
          <div className="p-4 pt-6">
            <div className="grid grid-cols-3 gap-3">
              {menuItems.map((item) => (
                <button 
                  key={item.id}
                  onClick={item.action}
                  className={`aspect-square backdrop-blur-sm rounded-xl shadow-sm border flex flex-col items-center justify-center p-2 hover:shadow-md transition active:scale-95 group ${isDarkMode ? 'bg-white/5 border-white/10 hover:bg-white/10' : 'bg-white/80 border-white/60 hover:bg-white'}`}
                >
                  <div className={`${isDarkMode ? 'text-brand-400' : 'text-brand-600'} mb-2 transform scale-125 group-hover:scale-110 transition-transform`}>
                    {item.icon}
                  </div>
                  <span className={`text-xs text-center font-medium leading-tight ${isDarkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                    {item.label}
                  </span>
                </button>
              ))}
            </div>
          </div>
        </Layout>
      );
    }

    if (screen === 'PROFILE' && user) {
      return (
        <Layout title="My Profile" onBack={() => { setScreen('HOME'); setIsEditingEmail(false); }} isDarkMode={isDarkMode}>
          <div className="p-6 flex flex-col items-center">
            <div className="relative group mb-4">
              <div className={`w-28 h-28 rounded-full flex items-center justify-center overflow-hidden shadow-xl border-4 ${isDarkMode ? 'bg-gray-800 border-gray-700' : 'bg-brand-100 border-white'}`}>
                {user.profilePic ? (
                  <img src={user.profilePic} alt="Profile" className="w-full h-full object-cover" />
                ) : (
                  <span className={`text-4xl font-bold ${isDarkMode ? 'text-brand-400' : 'text-brand-600'}`}>{user.fullName.charAt(0)}</span>
                )}
              </div>
              <label className="absolute bottom-1 right-1 bg-brand-600 hover:bg-brand-700 text-white p-2 rounded-full cursor-pointer shadow-lg transition transform hover:scale-110 active:scale-95">
                <Icons.Camera />
                <input type="file" className="hidden" accept="image/*" onChange={handleImageUpload} />
              </label>
            </div>
            
            <div className={`flex items-center gap-2 px-4 py-2 rounded-full shadow-inner mb-8 ${isDarkMode ? 'bg-white/5' : 'bg-gray-100'}`}>
              <span className={`font-mono font-medium text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>ID: {user.id}</span>
              <button 
                 onClick={handleCopyId}
                 className="text-gray-400 hover:text-brand-600 transition p-1"
                 title="Copy ID"
              >
                 <Icons.Copy />
              </button>
              {copyFeedback && <span className="text-xs text-green-600 font-bold animate-fade-in">{copyFeedback}</span>}
            </div>

            <div className={`w-full rounded-xl shadow-md border overflow-hidden mb-6 ${isDarkMode ? 'bg-white/5 border-white/10' : 'bg-white border-gray-50'}`}>
               <div className={`p-4 border-b transition flex justify-between items-center ${isDarkMode ? 'border-white/10 hover:bg-white/5' : 'border-gray-100 hover:bg-gray-50'}`}>
                  <div className="flex items-center gap-2">
                     <div className={`p-2 rounded-lg ${isDarkMode ? 'bg-brand-900/40 text-brand-400' : 'bg-brand-50 text-brand-600'}`}>
                        {isDarkMode ? <Icons.Moon size={18} /> : <Icons.Sun size={18} />}
                     </div>
                     <span className={`text-xs font-black uppercase tracking-widest ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>App Theme</span>
                  </div>
                  <button 
                     onClick={toggleDarkMode}
                     className={`w-12 h-6 rounded-full p-1 transition-colors duration-300 relative ${isDarkMode ? 'bg-brand-600' : 'bg-gray-300'}`}
                  >
                     <div className={`w-4 h-4 bg-white rounded-full shadow-sm transition-transform duration-300 transform ${isDarkMode ? 'translate-x-6' : 'translate-x-0'}`}></div>
                  </button>
               </div>

               <div className={`p-4 border-b transition flex justify-between items-center ${isDarkMode ? 'border-white/10 hover:bg-white/5' : 'border-gray-100 hover:bg-gray-50'}`}>
                  <span className="text-xs text-gray-500 font-semibold">User Full Name</span>
                  <span className={`text-sm font-medium text-right ${isDarkMode ? 'text-gray-200' : 'text-gray-800'}`}>{user.fullName}</span>
               </div>
               <div className={`p-4 border-b transition flex justify-between items-center ${isDarkMode ? 'border-white/10 hover:bg-white/5' : 'border-gray-100 hover:bg-gray-50'}`}>
                  <span className="text-xs text-gray-500 font-semibold">Mobile Number</span>
                  <span className={`text-sm font-medium text-right ${isDarkMode ? 'text-gray-200' : 'text-gray-800'}`}>{user.mobile}</span>
               </div>

               <div className={`p-4 border-b transition ${isDarkMode ? 'border-white/10 hover:bg-white/5' : 'border-gray-100 hover:bg-gray-50'}`}>
                  <div className="flex justify-between items-center">
                     <div className="flex items-center gap-1">
                        <span className="text-xs text-gray-500 font-semibold">Gmail</span>
                        {!isEditingEmail && (
                          <button onClick={() => { setIsEditingEmail(true); setTempEmail(user.email); }} className="text-brand-600 hover:text-brand-800 p-1">
                            <Icons.Edit />
                          </button>
                        )}
                     </div>
                     {!isEditingEmail && (
                        <span className={`text-sm font-medium truncate max-w-[60%] text-right ${isDarkMode ? 'text-gray-200' : 'text-gray-800'}`}>{user.email}</span>
                     )}
                  </div>
                  {isEditingEmail && (
                     <div className="flex gap-2 mt-2">
                       <Input 
                         value={tempEmail} 
                         onChange={e => setTempEmail(e.target.value)} 
                         placeholder="New Gmail" 
                         className="text-sm py-2"
                       />
                       <button onClick={handleEmailUpdate} className="bg-brand-600 text-white px-3 rounded-lg text-xs font-bold">Save</button>
                       <button onClick={() => setIsEditingEmail(false)} className="bg-gray-200 text-gray-600 px-3 rounded-lg text-xs font-bold">X</button>
                     </div>
                  )}
               </div>
               <div className={`p-4 border-b transition flex justify-between items-center ${isDarkMode ? 'border-white/10 hover:bg-white/5' : 'border-gray-100 hover:bg-gray-50'}`}>
                  <span className="text-xs text-gray-500 font-semibold">Country</span>
                  <span className={`text-sm font-medium text-right ${isDarkMode ? 'text-gray-200' : 'text-gray-800'}`}>{user.country}</span>
               </div>
               <div className={`p-4 border-b transition flex justify-between items-center ${isDarkMode ? 'border-white/10 hover:bg-white/5' : 'border-gray-100 hover:bg-gray-50'}`}>
                  <span className="text-xs text-gray-500 font-semibold">Joined Date</span>
                  <span className={`text-sm font-medium text-right ${isDarkMode ? 'text-gray-200' : 'text-gray-800'}`}>{new Date(user.registeredAt).toLocaleDateString()}</span>
               </div>
               <div className={`p-4 border-b transition flex justify-between items-center ${isDarkMode ? 'border-white/10 hover:bg-white/5' : 'border-gray-100 hover:bg-gray-50'}`}>
                  <span className="text-xs text-gray-500 font-semibold">Profile Type</span>
                  <div className={`text-[10px] px-2 py-1 rounded font-bold uppercase ${isDarkMode ? 'bg-blue-900/40 text-blue-400' : 'bg-blue-50 text-blue-600'}`}>
                    Personal
                  </div>
               </div>

               <div className={`p-4 border-b transition flex justify-between items-center bg-brand-50/20 ${isDarkMode ? 'border-white/10 hover:bg-white/5' : 'border-gray-100 hover:bg-gray-50'}`}>
                  <div className="flex items-center gap-2">
                     <span className="text-brand-600"><Icons.Lock size={18} /></span>
                     <span className="text-xs font-bold text-brand-700">Account Security</span>
                  </div>
                  <button 
                    onClick={() => { setCpSuccess(false); setCpError(''); setScreen('CHANGE_PASSWORD'); }}
                    className="bg-brand-600 text-white px-4 py-1.5 rounded-lg text-[10px] font-black uppercase tracking-widest active:scale-95 transition shadow-sm"
                  >
                    Change Password
                  </button>
               </div>

               <div className={`p-4 flex justify-between items-center ${isDarkMode ? 'bg-black/20' : 'bg-gray-50'}`}>
                  <div className="flex items-center gap-2">
                     <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></div>
                     <span className={`text-sm font-bold ${isDarkMode ? 'text-gray-300' : 'text-gray-700'}`}>Active</span>
                  </div>
                  <div className={`flex items-center gap-1 px-3 py-1 rounded-full shadow-sm border ${isDarkMode ? 'bg-gray-800 border-white/5 text-brand-400' : 'text-brand-600 bg-white border-brand-100'}`}>
                     <Icons.CheckCircle />
                     <span className="text-xs font-bold">Verified</span>
                  </div>
               </div>
            </div>
          </div>
        </Layout>
      );
    }

    if (screen === 'CHANGE_PASSWORD' && user) {
      return (
        <Layout title="পাসওয়ার্ড পরিবর্তন" onBack={() => { setScreen('PROFILE'); setCpError(''); setCpSuccess(false); }} isDarkMode={isDarkMode}>
          <div className="p-6 space-y-6">
            {!cpSuccess ? (
              <>
                <div className="bg-brand-50 p-4 rounded-2xl border border-brand-100 animate-fade-in">
                   <p className="text-[10px] font-black uppercase text-brand-600 mb-2">নিরাপত্তা যাচাইকরণ</p>
                   <p className="text-xs text-brand-800 font-bold leading-relaxed">পাসওয়ার্ড পরিবর্তন করতে আপনার ইউজার আইডি এবং মোবাইল নাম্বার সঠিকভাবে প্রদান করুন।</p>
                </div>

                <div className="space-y-4">
                  <div>
                     <label className="text-[9px] font-black uppercase text-gray-400 ml-1 mb-1 block">ইউজার আইডি</label>
                     <Input value={cpUserId} onChange={e => setCpUserId(e.target.value)} placeholder="আপনার ইউজার আইডি দিন" />
                  </div>
                  <div>
                     <label className="text-[9px] font-black uppercase text-gray-400 ml-1 mb-1 block">মোবাইল নম্বর</label>
                     <Input value={cpMobile} onChange={e => setCpMobile(e.target.value)} placeholder="রেজিস্টার্ড মোবাইল নম্বর" type="tel" maxLength={11} />
                  </div>
                  <div>
                     <label className="text-[9px] font-black uppercase text-gray-400 ml-1 mb-1 block">বর্তমান পাসওয়ার্ড</label>
                     <Input type="password" placeholder="বর্তমান পাসওয়ার্ড দিন" value={oldPass} onChange={e => setOldPass(e.target.value)} />
                  </div>
                  <div>
                     <label className="text-[9px] font-black uppercase text-gray-400 ml-1 mb-1 block">নতুন পাসওয়ার্ড</label>
                     <Input type="password" placeholder="নতুন পাসওয়ার্ড দিন" value={newPass} onChange={e => setNewPass(e.target.value)} />
                  </div>
                  <div>
                     <label className="text-[9px] font-black uppercase text-gray-400 ml-1 mb-1 block">পাসওয়ার্ড নিশ্চিত করুন</label>
                     <Input type="password" placeholder="আবার লিখুন" value={confirmNewPass} onChange={e => setConfirmNewPass(e.target.value)} />
                  </div>

                  {cpError && (
                    <div className="bg-red-50 border border-red-200 text-red-600 p-3 rounded-xl text-xs text-center font-bold animate-fade-in">
                      {cpError}
                    </div>
                  )}

                  <Button onClick={handleChangePassword} className="py-4 font-black uppercase tracking-widest shadow-xl">Update Password</Button>
                </div>
              </>
            ) : (
              <div className="text-center py-10 animate-fade-in space-y-6">
                 <div className="w-24 h-24 bg-green-100 text-green-600 rounded-full flex items-center justify-center mx-auto mb-4 border-4 border-white shadow-xl">
                    <Icons.CheckCircle size={48} />
                 </div>
                 <div className="bg-green-50 p-6 rounded-3xl border border-green-200 space-y-2">
                    <h2 className="text-xl font-black text-green-800">সফল হয়েছে!</h2>
                    <p className="text-sm text-gray-700 font-bold">আপনার পাসওয়ার্ড সফলভাবে পরিবর্তন করা হয়েছে।</p>
                 </div>
                 <Button onClick={() => setScreen('PROFILE')} variant="outline" className="font-black uppercase tracking-widest">Back to Profile</Button>
              </div>
            )}
          </div>
        </Layout>
      );
    }

    if (screen === 'ACADEMIC_ZONE') {
      return (
        <Layout title="Academic Zone" onBack={() => setScreen('HOME')} isDarkMode={isDarkMode}>
          <div className="p-4 space-y-6">
            <div className="bg-gradient-to-br from-indigo-600 to-brand-600 rounded-3xl p-8 text-white shadow-xl relative overflow-hidden animate-fade-in">
              <div className="absolute -right-8 -top-8 opacity-10">
                <Icons.GraduationCap size={150} />
              </div>
              <h2 className="text-2xl font-black uppercase tracking-tight mb-2">একাডেমিক জোন</h2>
              <p className="text-xs opacity-80 font-bold uppercase tracking-widest leading-relaxed">
                আপনার ল্যাব রিপোর্ট, ইনডেক্স এবং অ্যাসাইনমেন্ট কভার পেজ তৈরি করুন সহজে।
              </p>
            </div>

            <div className="grid grid-cols-1 gap-4">
              <button 
                onClick={() => setScreen('LAB_REPORT')}
                className="group bg-white p-6 rounded-3xl shadow-sm border border-brand-100 flex items-center gap-5 transition active:scale-95 hover:shadow-md animate-slide-up"
              >
                <div className="bg-brand-50 text-brand-600 p-4 rounded-2xl group-hover:rotate-6 transition">
                   <Icons.FileText size={28} />
                </div>
                <div className="text-left">
                  <h3 className="text-lg font-black text-gray-800 uppercase tracking-tight">Lab Report Entry</h3>
                  <p className="text-[10px] text-gray-500 font-bold uppercase tracking-widest">Create Professional Lab Covers</p>
                </div>
              </button>

              <button 
                onClick={() => setScreen('INDEX_CREATE')}
                className="group bg-white p-6 rounded-3xl shadow-sm border border-brand-100 flex items-center gap-5 transition active:scale-95 hover:shadow-md animate-slide-up"
                style={{ animationDelay: '0.1s' }}
              >
                <div className="bg-brand-50 text-brand-600 p-4 rounded-2xl group-hover:rotate-6 transition">
                   <Icons.Plus size={28} />
                </div>
                <div className="text-left">
                  <h3 className="text-lg font-black text-gray-800 uppercase tracking-tight">Index Create</h3>
                  <p className="text-[10px] text-gray-500 font-bold uppercase tracking-widest">Generate Table of Contents</p>
                </div>
              </button>

              <button 
                onClick={() => setScreen('ASSIGNMENT_COVER')}
                className="group bg-white p-6 rounded-3xl shadow-sm border border-brand-100 flex items-center gap-5 transition active:scale-95 hover:shadow-md animate-slide-up"
                style={{ animationDelay: '0.2s' }}
              >
                <div className="bg-brand-50 text-brand-600 p-4 rounded-2xl group-hover:rotate-6 transition">
                   <Icons.GraduationCap size={28} />
                </div>
                <div className="text-left">
                  <h3 className="text-lg font-black text-gray-800 uppercase tracking-tight">Assignment Cover</h3>
                  <p className="text-[10px] text-gray-500 font-bold uppercase tracking-widest">Formal Assignment Front Pages</p>
                </div>
              </button>

              <button 
                onClick={() => setScreen('NORMAL_CV')}
                className="group bg-white p-6 rounded-3xl shadow-sm border border-brand-100 flex items-center gap-5 transition active:scale-95 hover:shadow-md animate-slide-up"
                style={{ animationDelay: '0.3s' }}
              >
                <div className="bg-brand-50 text-indigo-600 p-4 rounded-2xl group-hover:rotate-6 transition">
                   <Icons.User size={28} />
                </div>
                <div className="text-left">
                  <h3 className="text-lg font-black text-gray-800 uppercase tracking-tight">Normal CV</h3>
                  <p className="text-[10px] text-gray-500 font-bold uppercase tracking-widest">Generate Professional Resume</p>
                </div>
              </button>

              {/* NEW SCIENTIST BUTTON ADDED AT THE END */}
              <button 
                onClick={() => setScreen('SCIENTIST_ZONE')}
                className="group bg-white p-6 rounded-3xl shadow-sm border border-brand-100 flex items-center gap-5 transition active:scale-95 hover:shadow-md animate-slide-up"
                style={{ animationDelay: '0.4s' }}
              >
                <div className="bg-indigo-50 text-indigo-700 p-4 rounded-2xl group-hover:rotate-6 transition">
                   <Icons.Brain size={28} />
                </div>
                <div className="text-left">
                  <h3 className="text-lg font-black text-gray-800 uppercase tracking-tight">Scientist History</h3>
                  <p className="text-[10px] text-gray-500 font-bold uppercase tracking-widest">100+ Famous Scientists & Discoveries</p>
                </div>
              </button>
            </div>
          </div>
        </Layout>
      );
    }

    if (screen === 'DASHBOARD_ENTRY' && user) return <Dashboard user={user} onBack={() => setScreen('HOME')} />;
    if (screen === 'HISTORY' && user) return <History user={user} mode="ALL" onBack={() => setScreen('HOME')} />;
    if (screen === 'DAILY_TX' && user) return <History user={user} mode="DAILY" onBack={() => setScreen('HOME')} />;
    if (screen === 'TOTAL_HISAB' && user) return <History user={user} mode="TOTAL" onBack={() => setScreen('HOME')} />;
    if (screen === 'MONTHLY_HISAB' && user) return <MonthlyHisab user={user} onBack={() => setScreen('HOME')} />;
    if (screen === 'GAME_ZONE') return <GameZone onBack={() => setScreen('HOME')} />;
    if (screen === 'CALCULATOR') return <Calculator onBack={() => setScreen('HOME')} />;
    if (screen === 'PRAYER_TIMES') return <PrayerTimes onBack={() => setScreen('HOME')} />;
    if (screen === 'BAZAR_HISAB' && user) return <BazarHisab user={user} onBack={() => setScreen('HOME')} />;
    if (screen === 'LAB_REPORT' && user) return <LabReport user={user} onBack={() => setScreen('ACADEMIC_ZONE')} />;
    if (screen === 'INDEX_CREATE') return <IndexCreate onBack={() => setScreen('ACADEMIC_ZONE')} />;
    if (screen === 'ASSIGNMENT_COVER' && user) return <AssignmentCover user={user} onBack={() => setScreen('ACADEMIC_ZONE')} />;
    if (screen === 'NORMAL_CV') return <NormalCV onBack={() => setScreen('ACADEMIC_ZONE')} />;
    if (screen === 'SCIENTIST_ZONE') return <ScientistZone onBack={() => setScreen('ACADEMIC_ZONE')} />;
    
    if (screen === 'ISLAMIC_HUB') return <IslamicHub onBack={() => setScreen('HOME')} onNavigate={setScreen} />;
    if (screen === 'HADITH_ZONE') return <HadithZone onBack={() => setScreen('ISLAMIC_HUB')} />;
    if (screen === 'SURAH_ZONE') return <SurahZone onBack={() => setScreen('ISLAMIC_HUB')} />;
    if (screen === 'ISLAMIC_ADVICE') return <IslamicAdvice onBack={() => setScreen('ISLAMIC_HUB')} />;
    if (screen === 'PROPHETS_ZONE') return <ProphetsZone onBack={() => setScreen('ISLAMIC_HUB')} />;
    if (screen === 'SAHABA_ZONE') return <SahabaZone onBack={() => setScreen('ISLAMIC_HUB')} />;

    // NEW ADMIN SCREENS
    if (screen === 'ADMIN_LOGIN' || screen === 'ADMIN_DASHBOARD') {
       return <AdminPanel currentScreen={screen} setScreen={setScreen} />;
    }

    return null;
  };

  const showGlobalHomeButton = user && screen !== 'HOME' && !['LOGIN', 'REGISTER', 'FORGOT_PASSWORD', 'ADMIN_LOGIN', 'ADMIN_DASHBOARD'].includes(screen);

  return (
    <>
      {renderCurrentScreen()}
      {showGlobalHomeButton && (
        <div className="fixed inset-0 pointer-events-none flex justify-center z-[9999]">
          <div className="w-full max-w-md relative h-full">
            <button 
              onClick={() => {
                setCpSuccess(false);
                setCpError('');
                setScreen('HOME');
              }}
              className="absolute bottom-8 left-6 pointer-events-auto w-14 h-14 bg-gradient-to-tr from-amber-400 via-brand-500 to-purple-600 text-white rounded-full shadow-2xl flex items-center justify-center active:scale-90 transition-all border-4 border-white hover:shadow-brand-300"
              title="Home"
            >
              <Icons.Home size={28} />
            </button>
          </div>
        </div>
      )}
    </>
  );
};

export default App;
