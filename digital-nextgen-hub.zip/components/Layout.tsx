
import React from 'react';
import { Icons } from '../constants';

interface LayoutProps {
  children: React.ReactNode;
  title?: string;
  onBack?: () => void;
  hideBack?: boolean;
  customHeader?: React.ReactNode;
  bottomNav?: React.ReactNode;
  className?: string;
  isDarkMode?: boolean;
}

export const Layout: React.FC<LayoutProps> = ({ children, title, onBack, hideBack, customHeader, bottomNav, className, isDarkMode }) => {
  return (
    <div className={`h-[100dvh] w-full flex justify-center overflow-hidden transition-colors duration-300 ${isDarkMode ? 'bg-black' : 'bg-gray-100'}`}>
      <div className={`w-full max-w-md shadow-xl h-full flex flex-col relative transition-colors duration-300 ${className ? className : (isDarkMode ? 'bg-gray-900' : 'bg-white')}`}>
        {/* Header */}
        <div className={`${isDarkMode ? 'bg-gradient-to-r from-gray-900 to-gray-800' : 'bg-gradient-to-r from-brand-600 to-brand-800'} text-white p-3 flex items-center shadow-md z-10 shrink-0 relative min-h-[56px] transition-colors`}>
          {customHeader ? (
            customHeader
          ) : (
            <>
              {!hideBack && onBack && (
                <button 
                  onClick={onBack} 
                  className="mr-3 p-1 rounded-full hover:bg-white/20 transition"
                >
                  <Icons.ArrowLeft />
                </button>
              )}
              <h1 className="text-lg font-bold flex-1 truncate">{title}</h1>
            </>
          )}
        </div>

        {/* Content */}
        <div className={`flex-1 overflow-y-auto no-scrollbar relative scroll-smooth transition-colors duration-300 ${isDarkMode ? 'text-gray-100' : 'text-gray-900'}`}>
          {children}
        </div>

        {/* Bottom Navigation */}
        {bottomNav && (
          <div className={`shrink-0 z-20 pb-safe transition-colors duration-300 ${isDarkMode ? 'bg-gray-800/90 backdrop-blur-md border-t border-white/5 shadow-[0_-4px_20px_-5px_rgba(0,0,0,0.3)]' : 'bg-white/90 backdrop-blur-md border-t border-white/50'}`}>
            {bottomNav}
          </div>
        )}
      </div>
    </div>
  );
};

export const Button: React.FC<React.ButtonHTMLAttributes<HTMLButtonElement> & { variant?: 'primary' | 'secondary' | 'outline' }> = ({ 
  className = '', 
  variant = 'primary', 
  ...props 
}) => {
  const baseClass = "w-full py-3 rounded-lg font-semibold transition-all duration-200 active:scale-95 shadow-sm text-sm";
  const variants = {
    primary: "bg-brand-600 text-white hover:bg-brand-700 shadow-brand-200",
    secondary: "bg-gray-800 text-white hover:bg-gray-900",
    outline: "border-2 border-brand-600 text-brand-600 hover:bg-brand-50"
  };

  return (
    <button className={`${baseClass} ${variants[variant]} ${className}`} {...props} />
  );
};

export const Input: React.FC<React.InputHTMLAttributes<HTMLInputElement>> = (props) => {
  return (
    <input 
      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-500 focus:border-transparent transition-all text-sm"
      {...props}
    />
  );
};
