
import React, { useState, useEffect } from 'react';
import { Layout, Button, Input } from '../components/Layout';
import { Icons } from '../constants';
import { StorageService } from '../services/storage';

interface IndexRow {
  id: string;
  expNo: string;
  expName: string;
  datePerf: string;
  dateSub: string;
  remarks: string;
}

export const IndexCreate: React.FC<{ onBack: () => void }> = ({ onBack }) => {
  const [studentName, setStudentName] = useState('');
  const [studentId, setStudentId] = useState('');
  const [rows, setRows] = useState<IndexRow[]>([{ 
    id: Date.now().toString(), 
    expNo: '', 
    expName: '', 
    datePerf: '', 
    dateSub: '', 
    remarks: '' 
  }]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [history, setHistory] = useState<Record<string, string[]>>({});

  useEffect(() => {
    const fields = ['studentName', 'studentId', 'expNo', 'expName'];
    const histData: Record<string, string[]> = {};
    fields.forEach(f => {
      histData[f] = StorageService.getAcademicHistory(f);
    });
    setHistory(histData);

    // Initial fill from history
    if (histData.studentName?.length) setStudentName(histData.studentName[histData.studentName.length - 1]);
    if (histData.studentId?.length) setStudentId(histData.studentId[histData.studentId.length - 1]);
  }, []);

  const addRow = () => {
    setRows([...rows, { 
      id: Date.now().toString(), 
      expNo: '', 
      expName: '', 
      datePerf: '', 
      dateSub: '', 
      remarks: '' 
    }]);
  };

  const removeRow = (id: string) => {
    if (rows.length > 1) {
      setRows(rows.filter(r => r.id !== id));
    }
  };

  const updateRow = (id: string, field: keyof IndexRow, value: string) => {
    setRows(rows.map(r => r.id === id ? { ...r, [field]: value } : r));
  };

  const handleDownload = async (type: 'pdf' | 'img') => {
    const element = document.getElementById('index-page-template');
    const jspdfLib = (window as any).jspdf;
    
    if (element && (window as any).html2canvas && jspdfLib) {
      try {
        setIsProcessing(true);
        
        // Save current data to history before clearing
        StorageService.saveAcademicEntry('studentName', studentName);
        StorageService.saveAcademicEntry('studentId', studentId);
        rows.forEach(r => {
          if (r.expNo) StorageService.saveAcademicEntry('expNo', r.expNo);
          if (r.expName) StorageService.saveAcademicEntry('expName', r.expName);
        });

        element.style.display = 'block';
        element.style.position = 'absolute';
        element.style.left = '-9999px';

        const canvas = await (window as any).html2canvas(element, { 
          useCORS: true, 
          scale: 4, 
          logging: false,
          backgroundColor: '#ffffff'
        });
        
        if (type === 'pdf') {
          const imgData = canvas.toDataURL('image/png', 1.0);
          const { jsPDF } = jspdfLib;
          const pdf = new jsPDF('p', 'mm', 'a4');
          const imgWidth = 210; 
          const canvasImgHeight = (canvas.height * imgWidth) / canvas.width;
          pdf.addImage(imgData, 'PNG', 0, 0, imgWidth, canvasImgHeight);
          pdf.save(`Academic_Index_${Date.now()}.pdf`);
        } else {
          const data = canvas.toDataURL('image/png');
          const link = document.createElement('a');
          link.href = data;
          link.download = `Academic_Index_${Date.now()}.png`;
          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link);
        }
        
        element.style.display = 'none';

        // AUTO REMOVE ALL ENTRIES AFTER DOWNLOAD
        setStudentName('');
        setStudentId('');
        setRows([{ 
          id: Date.now().toString(), 
          expNo: '', 
          expName: '', 
          datePerf: '', 
          dateSub: '', 
          remarks: '' 
        }]);

        alert(`${type.toUpperCase()} ডাউনলোড সম্পন্ন হয়েছে এবং তথ্যগুলো মুছে ফেলা হয়েছে।`);
      } catch (e) {
        console.error("Export Error:", e);
        alert("Generation Failed.");
      } finally {
        setIsProcessing(false);
      }
    }
  };

  return (
    <Layout title="ইনডেক্স ক্রিয়েট" onBack={onBack} className="bg-gray-50">
      <div className="p-4 space-y-6 pb-24 overflow-y-auto no-scrollbar">
        {isProcessing && (
          <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-[9999] flex flex-col items-center justify-center text-white p-6 text-center">
             <div className="w-12 h-12 border-4 border-white/20 border-t-white rounded-full animate-spin mb-4"></div>
             <p className="font-bold">Generating Page...</p>
          </div>
        )}

        <div className="bg-white p-5 rounded-2xl shadow-sm border border-emerald-100 space-y-4">
          <h3 className="text-[10px] font-black uppercase text-emerald-600 tracking-widest border-b pb-2">Header Information</h3>
          <div className="grid grid-cols-2 gap-3">
             <div className="relative">
                <label className="text-[9px] font-bold text-gray-400 uppercase ml-1">Student Name</label>
                <Input list="idx-name-hist" value={studentName} onChange={e => setStudentName(e.target.value)} placeholder="Full Name" />
                <datalist id="idx-name-hist">{history.studentName?.map((h, i) => <option key={i} value={h} />)}</datalist>
             </div>
             <div className="relative">
                <label className="text-[9px] font-bold text-gray-400 uppercase ml-1">Student ID</label>
                <Input list="idx-id-hist" value={studentId} onChange={e => setStudentId(e.target.value)} placeholder="ID No" />
                <datalist id="idx-id-hist">{history.studentId?.map((h, i) => <option key={i} value={h} />)}</datalist>
             </div>
          </div>
        </div>

        <div className="space-y-4">
           <div className="flex justify-between items-center">
              <h3 className="text-[10px] font-black uppercase text-gray-500 tracking-widest">Index Entries</h3>
              <button onClick={addRow} className="bg-emerald-100 text-emerald-700 p-2 rounded-xl flex items-center gap-1 text-xs font-black active:scale-95 transition">
                 <Icons.Plus size={16} /> Add Entry Row
              </button>
           </div>

           {rows.map((row, index) => (
             <div key={row.id} className="bg-white p-5 rounded-2xl shadow-sm border border-gray-100 space-y-3 relative group animate-slide-up" style={{ animationDelay: `${index * 0.05}s` }}>
                <div className="absolute -top-2 -left-2 w-6 h-6 bg-emerald-600 text-white text-[10px] font-black rounded-lg flex items-center justify-center shadow-md">
                   {index + 1}
                </div>
                
                <div className="grid grid-cols-4 gap-2">
                   <div className="col-span-1">
                      <label className="text-[9px] font-bold text-gray-400 uppercase">Exp. No</label>
                      <Input value={row.expNo} onChange={e => updateRow(row.id, 'expNo', e.target.value)} placeholder="01" className="py-2" />
                   </div>
                   <div className="col-span-3">
                      <label className="text-[9px] font-bold text-gray-400 uppercase">Experiment Name</label>
                      <Input value={row.expName} onChange={e => updateRow(row.id, 'expName', e.target.value)} placeholder="Name of Experiment" className="py-2" />
                   </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                   <div>
                      <label className="text-[9px] font-bold text-gray-400 uppercase">Date of Perf.</label>
                      <Input value={row.datePerf} onChange={e => updateRow(row.id, 'datePerf', e.target.value)} placeholder="DD/MM/YY" className="py-2" />
                   </div>
                   <div>
                      <label className="text-[9px] font-bold text-gray-400 uppercase">Date of Sub.</label>
                      <Input value={row.dateSub} onChange={e => updateRow(row.id, 'dateSub', e.target.value)} placeholder="DD/MM/YY" className="py-2" />
                   </div>
                </div>

                {rows.length > 1 && (
                  <button onClick={() => removeRow(row.id)} className="absolute -top-2 -right-2 bg-red-50 text-red-500 p-1.5 rounded-lg border border-red-100 opacity-0 group-hover:opacity-100 transition">
                     <Icons.Trash size={14} />
                  </button>
                )}
             </div>
           ))}
        </div>

        <div className="grid grid-cols-2 gap-3">
           <Button onClick={() => handleDownload('pdf')} variant="secondary" className="py-4 font-black uppercase text-[10px] tracking-widest flex items-center justify-center gap-2">
              <Icons.Download size={14} /> Download PDF
           </Button>
           <Button onClick={() => handleDownload('img')} variant="primary" className="py-4 font-black uppercase text-[10px] tracking-widest flex items-center justify-center gap-2">
              <Icons.Camera size={14} /> Download Image
           </Button>
        </div>

        {/* --- PRINT TEMPLATE --- */}
        <div id="index-page-template" style={{ display: 'none', fontFamily: '"Times New Roman", Times, serif', color: 'black' }} className="w-[794px] min-h-[1123px] bg-white p-[60px] relative">
           <h1 className="text-[32px] font-bold text-center underline mb-8">Index</h1>
           
           <div className="flex justify-between items-center text-[22px] mb-6 font-bold">
              <div className="flex-1">
                 Name: <span className="font-normal border-b border-black inline-block min-w-[300px] ml-2">{studentName}</span>
              </div>
              <div className="w-fit">
                 ID: <span className="font-normal border-b border-black inline-block min-w-[200px] ml-2">{studentId}</span>
              </div>
           </div>

           <table className="w-full border-collapse border-[1.5px] border-black">
              <thead>
                 <tr className="text-center text-[18px] font-bold">
                    <th className="border-[1.5px] border-black p-3 w-[80px]">Exp.<br/>No</th>
                    <th className="border-[1.5px] border-black p-3">Experiment name</th>
                    <th className="border-[1.5px] border-black p-3 w-[120px]">Date of<br/>Performance</th>
                    <th className="border-[1.5px] border-black p-3 w-[120px]">Date of<br/>Submission</th>
                    <th className="border-[1.5px] border-black p-3 w-[100px]">Remarks</th>
                 </tr>
              </thead>
              <tbody>
                 {/* Ensure at least 12 rows are drawn even if data is less to match manual look */}
                 {Array.from({ length: Math.max(rows.length, 12) }).map((_, idx) => {
                    const row = rows[idx];
                    return (
                      <tr key={idx} className="h-[55px] text-[16px]">
                         <td className="border-[1.5px] border-black p-2 text-center">{row?.expNo || ''}</td>
                         <td className="border-[1.5px] border-black p-2 font-bold px-4">{row?.expName || ''}</td>
                         <td className="border-[1.5px] border-black p-2 text-center">{row?.datePerf || ''}</td>
                         <td className="border-[1.5px] border-black p-2 text-center">{row?.dateSub || ''}</td>
                         <td className="border-[1.5px] border-black p-2 text-center">{row?.remarks || ''}</td>
                      </tr>
                    );
                 })}
              </tbody>
           </table>
        </div>
      </div>
    </Layout>
  );
};
