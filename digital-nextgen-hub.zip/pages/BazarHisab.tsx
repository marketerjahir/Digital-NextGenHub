
import React, { useState, useMemo } from 'react';
import { Layout, Button, Input } from '../components/Layout';
import { Icons } from '../constants';
import { User } from '../types';

interface BazarItem {
  id: string;
  name: string;
  qty: string;
  amount: number;
}

export const BazarHisab: React.FC<{ user: User, onBack: () => void }> = ({ user, onBack }) => {
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  // Initialized with user name but independent after first load
  const [marketUserName, setMarketUserName] = useState(user.fullName);
  const [mainBalance, setMainBalance] = useState<number>(0);
  const [items, setItems] = useState<BazarItem[]>([{ id: Date.now().toString(), name: '', qty: '', amount: 0 }]);
  const [isProcessing, setIsProcessing] = useState(false);

  const totalCost = useMemo(() => {
    return items.reduce((sum, item) => sum + (item.amount || 0), 0);
  }, [items]);

  const remainingBalance = useMemo(() => {
    return (mainBalance || 0) - totalCost;
  }, [mainBalance, totalCost]);

  const addRow = () => {
    setItems([...items, { id: Date.now().toString(), name: '', qty: '', amount: 0 }]);
  };

  const removeRow = (id: string) => {
    if (items.length > 1) {
      setItems(items.filter(item => item.id !== id));
    }
  };

  const updateItem = (id: string, field: keyof BazarItem, value: any) => {
    setItems(items.map(item => item.id === id ? { ...item, [field]: value } : item));
  };

  const clearForm = () => {
    setMainBalance(0);
    setItems([{ id: Date.now().toString(), name: '', qty: '', amount: 0 }]);
  };

  const handleGeneratePDF = async () => {
    const element = document.getElementById('bazar-report-capture');
    const jspdfLib = (window as any).jspdf;
    
    if (element && (window as any).html2canvas && jspdfLib) {
      try {
        setIsProcessing(true);
        element.style.display = 'block';
        element.style.position = 'absolute';
        element.style.left = '-9999px';

        const canvas = await (window as any).html2canvas(element, { 
          useCORS: true, 
          scale: 2,
          logging: false 
        });
        
        const imgData = canvas.toDataURL('image/png');
        const { jsPDF } = jspdfLib;
        
        const imgWidth = 210; 
        const canvasImgHeight = (canvas.height * imgWidth) / canvas.width;
        
        const pdf = new jsPDF('p', 'mm', 'a4');
        pdf.addImage(imgData, 'PNG', 0, 0, imgWidth, canvasImgHeight);
        
        pdf.save(`Bazar_Report_${date}.pdf`);
        element.style.display = 'none';

        clearForm();
        alert("PDF successfully downloaded! Form has been cleared.");
      } catch (e) {
        console.error("PDF Error:", e);
        alert("PDF Generation Failed.");
      } finally {
        setIsProcessing(false);
      }
    }
  };

  const handleGenerateImage = async () => {
    const element = document.getElementById('bazar-report-capture');
    if (element && (window as any).html2canvas) {
      try {
        setIsProcessing(true);
        element.style.display = 'block';
        element.style.position = 'absolute';
        element.style.left = '-9999px';

        const canvas = await (window as any).html2canvas(element, { useCORS: true, scale: 2 });
        const data = canvas.toDataURL('image/png');
        const link = document.createElement('a');
        link.href = data;
        link.download = `Bazar_Report_${date}.png`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        
        element.style.display = 'none';
        clearForm();
        alert("Image successfully downloaded! Form has been cleared.");
      } catch (e) {
        alert("Image generation failed");
      } finally {
        setIsProcessing(false);
      }
    }
  };

  return (
    <Layout title="বাজারের হিসাব" onBack={onBack} className="bg-gray-50">
      <div className="p-4 space-y-6 pb-24">
        {isProcessing && (
          <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-[9999] flex flex-col items-center justify-center text-white p-6 text-center">
             <div className="w-12 h-12 border-4 border-white/20 border-t-white rounded-full animate-spin mb-4"></div>
             <p className="font-bold">Processing Document...</p>
          </div>
        )}

        {/* Date & Name Header */}
        <div className="flex justify-between items-center bg-white p-4 rounded-2xl shadow-sm border border-brand-50 animate-fade-in gap-4">
           <div className="flex flex-col flex-1">
              <span className="text-[10px] font-black uppercase text-gray-400 tracking-widest mb-1">Market User Name (Editable)</span>
              <input 
                type="text"
                value={marketUserName}
                onChange={e => setMarketUserName(e.target.value)}
                placeholder="Enter Name"
                className="font-bold text-brand-700 text-sm focus:outline-none bg-brand-50/50 px-2 py-1.5 rounded border border-brand-100"
              />
           </div>
           <div className="flex flex-col text-right">
              <span className="text-[10px] font-black uppercase text-gray-400 tracking-widest mb-1">Market Date</span>
              <input 
                type="date" 
                value={date} 
                onChange={e => setDate(e.target.value)} 
                className="font-bold text-gray-700 text-sm focus:outline-none bg-gray-50 px-2 py-1.5 rounded border border-gray-100"
              />
           </div>
        </div>

        {/* Budget Section */}
        <div className="bg-gradient-to-br from-brand-600 to-brand-800 rounded-3xl p-6 text-white shadow-xl animate-slide-up">
           <p className="text-[10px] font-black uppercase tracking-widest opacity-70 mb-2">বাজার করার বাজেট</p>
           <div className="flex items-center gap-3">
              <span className="text-2xl font-black">৳</span>
              <input 
                type="number" 
                value={mainBalance || ''} 
                onChange={e => setMainBalance(Number(e.target.value))}
                placeholder="0.00"
                className="bg-transparent text-4xl font-black w-full focus:outline-none placeholder:text-white/30"
              />
           </div>
           
           <div className="grid grid-cols-2 gap-4 mt-6 pt-6 border-t border-white/10">
              <div>
                 <p className="text-[9px] font-bold uppercase opacity-60">মোট খরচ</p>
                 <p className="text-xl font-black">৳ {totalCost.toFixed(2)}</p>
              </div>
              <div className="text-right">
                 <p className="text-[9px] font-bold uppercase opacity-60">অবশিষ্ট টাকা</p>
                 <p className={`text-xl font-black ${remainingBalance < 0 ? 'text-red-300' : 'text-green-300'}`}>৳ {remainingBalance.toFixed(2)}</p>
              </div>
           </div>
        </div>

        {/* Items List */}
        <div className="space-y-4">
           <div className="px-1">
              <h3 className="text-xs font-black uppercase text-gray-500 tracking-widest">পণ্যের তালিকা</h3>
           </div>

           <div className="space-y-3">
              {items.map((item, index) => (
                 <div key={item.id} className="bg-white p-4 rounded-2xl shadow-sm border border-gray-100 flex gap-3 items-end animate-slide-up" style={{ animationDelay: `${index * 0.05}s` }}>
                    <div className="flex-1 space-y-3">
                       <div className="grid grid-cols-2 gap-3">
                          <div className="col-span-1">
                             <label className="text-[9px] font-bold text-gray-400 uppercase ml-1">পণ্যের নাম</label>
                             <Input 
                               value={item.name} 
                               onChange={e => updateItem(item.id, 'name', e.target.value)} 
                               placeholder="যেমন: চাল" 
                               className="py-2"
                             />
                          </div>
                          <div className="col-span-1">
                             <label className="text-[9px] font-bold text-gray-400 uppercase ml-1">পরিমাণ</label>
                             <Input 
                               value={item.qty} 
                               onChange={e => updateItem(item.id, 'qty', e.target.value)} 
                               placeholder="যেমন: ৫ কেজি" 
                               className="py-2"
                             />
                          </div>
                       </div>
                       <div>
                          <label className="text-[9px] font-bold text-gray-400 uppercase ml-1">দাম (৳)</label>
                          <Input 
                             type="number" 
                             value={item.amount || ''} 
                             onChange={e => updateItem(item.id, 'amount', Number(e.target.value))} 
                             placeholder="0.00" 
                             className="py-2 font-bold"
                          />
                       </div>
                    </div>
                    {items.length > 1 && (
                      <button onClick={() => removeRow(item.id)} className="bg-red-50 text-red-500 p-2 rounded-xl h-fit mb-0.5 active:scale-90 transition">
                         <Icons.Trash size={18} />
                      </button>
                    )}
                 </div>
              ))}
              
              <button 
                onClick={addRow} 
                className="w-full py-4 border-2 border-dashed border-brand-200 rounded-2xl text-brand-600 text-xs font-black flex items-center justify-center gap-2 hover:bg-brand-50 active:scale-95 transition-all mt-2 bg-white/50"
              >
                 <Icons.Plus size={16} /> পণ্য যোগ করুন
              </button>
           </div>
        </div>

        {/* Footer Buttons */}
        <div className="pt-4 flex flex-col gap-3">
           <div className="grid grid-cols-2 gap-3">
              <Button onClick={handleGeneratePDF} variant="primary" className="py-4 font-black uppercase tracking-widest text-[10px] flex items-center justify-center gap-2">
                 <Icons.Download size={14} /> Download PDF
              </Button>
              <Button onClick={handleGenerateImage} variant="secondary" className="py-4 font-black uppercase tracking-widest text-[10px] flex items-center justify-center gap-2">
                 <Icons.Camera size={14} /> Download Image
              </Button>
           </div>
           <Button onClick={clearForm} variant="outline" className="py-3 font-black uppercase tracking-widest text-xs">
              Clear All Fields
           </Button>
        </div>

        {/* --- PDF/IMAGE CAPTURE AREA (Hidden) --- */}
        <div id="bazar-report-capture" style={{ display: 'none' }} className="w-[800px] bg-white p-12 font-sans text-gray-800">
           <div className="text-center border-b-4 border-brand-600 pb-8 mb-8">
              {/* BRAND NAME SHRUNK TO VERY SMALL SIZE AS REQUESTED */}
              <h1 className="text-[12px] font-black text-brand-700 uppercase tracking-widest mb-1">Digital NextGen Hub</h1>
              <p className="text-2xl text-gray-400 font-bold uppercase tracking-[0.3em]">Daily Bazar Expenses Statement</p>
           </div>

           <div className="grid grid-cols-2 gap-8 mb-8">
              <div className="space-y-1">
                 <p className="text-xs text-brand-600 font-black uppercase tracking-widest">Report For</p>
                 <p className="text-2xl font-black">{marketUserName}</p>
                 <p className="text-sm text-gray-800 font-bold italic">Bazar Date: {date}</p>
              </div>
              <div className="text-right space-y-1">
                 <p className="text-sm text-gray-400 italic mt-6">Created At: {new Date().toLocaleString()}</p>
              </div>
           </div>

           <div className="bg-gray-50 rounded-3xl p-8 grid grid-cols-3 gap-6 mb-8 border border-gray-100">
              <div className="text-center border-r border-gray-200">
                 <p className="text-[10px] text-gray-400 font-black uppercase mb-1">Total Budget</p>
                 <p className="text-3xl font-black">৳ {mainBalance.toFixed(2)}</p>
              </div>
              <div className="text-center border-r border-gray-200">
                 <p className="text-[10px] text-gray-400 font-black uppercase mb-1">Total Spent</p>
                 <p className="text-3xl font-black text-red-600">৳ {totalCost.toFixed(2)}</p>
              </div>
              <div className="text-center">
                 <p className="text-[10px] text-gray-400 font-black uppercase mb-1">Remaining</p>
                 <p className="text-3xl font-black text-green-600">৳ {remainingBalance.toFixed(2)}</p>
              </div>
           </div>

           <table className="w-full border-collapse">
              <thead>
                 <tr className="bg-brand-600 text-white">
                    <th className="p-4 text-left font-black uppercase text-xs">Product Name</th>
                    <th className="p-4 text-center font-black uppercase text-xs">Quantity</th>
                    <th className="p-4 text-right font-black uppercase text-xs">Amount</th>
                 </tr>
              </thead>
              <tbody>
                 {items.map((item, idx) => (
                    <tr key={idx} className="border-b border-gray-50">
                       <td className="p-4 text-sm font-bold text-gray-700">{item.name || 'N/A'}</td>
                       <td className="p-4 text-sm text-center font-black text-gray-900">{item.qty || '-'}</td>
                       <td className="p-4 text-sm text-right font-black text-gray-900">৳ {item.amount.toFixed(2)}</td>
                    </tr>
                 ))}
                 <tr className="bg-gray-100 font-black">
                    <td colSpan={2} className="p-4 text-right uppercase text-xs">Grand Total Cost</td>
                    <td className="p-4 text-right text-brand-600">৳ {totalCost.toFixed(2)}</td>
                 </tr>
              </tbody>
           </table>

           <div className="mt-20 pt-10 border-t border-dashed border-gray-200 text-center">
              <p className="text-[10px] text-gray-300 font-black uppercase tracking-widest">Verified Official Record</p>
           </div>
        </div>
      </div>
    </Layout>
  );
};
