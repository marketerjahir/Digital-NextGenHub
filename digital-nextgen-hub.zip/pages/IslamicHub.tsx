
import React from 'react';
import { Layout } from '../components/Layout';
import { Icons } from '../constants';
import { Screen } from '../types';

interface IslamicHubProps {
  onBack: () => void;
  onNavigate: (screen: Screen) => void;
}

export const IslamicHub: React.FC<IslamicHubProps> = ({ onBack, onNavigate }) => {
  return (
    <Layout title="Islamic Hub" onBack={onBack} className="bg-emerald-50">
      <div className="p-4 space-y-6">
        <div className="bg-gradient-to-br from-emerald-600 to-teal-800 rounded-3xl p-8 text-white shadow-xl relative overflow-hidden animate-fade-in">
          <div className="absolute -right-8 -top-8 opacity-10">
            <Icons.Moon size={150} />
          </div>
          <h2 className="text-2xl font-black uppercase tracking-tight mb-2">ইসলামিক কর্নার</h2>
          <p className="text-xs opacity-80 font-bold uppercase tracking-widest leading-relaxed">
            কুরআন ও হাদিসের শিক্ষায় সমৃদ্ধ হোক আপনার প্রতিটি দিন।
          </p>
        </div>

        <div className="grid grid-cols-1 gap-4">
          <button 
            onClick={() => onNavigate('HADITH_ZONE')}
            className="group bg-white p-6 rounded-3xl shadow-sm border border-emerald-100 flex items-center gap-5 transition active:scale-95 hover:shadow-md animate-slide-up"
          >
            <div className="bg-emerald-100 text-emerald-600 p-4 rounded-2xl group-hover:rotate-6 transition">
               <Icons.FileText size={28} />
            </div>
            <div className="text-left">
              <h3 className="text-lg font-black text-emerald-800 uppercase tracking-tight">হাদিস সম্ভার</h3>
              <p className="text-[10px] text-gray-500 font-bold uppercase tracking-widest">Valid Hadith Collection</p>
            </div>
          </button>

          <button 
            onClick={() => onNavigate('SURAH_ZONE')}
            className="group bg-white p-6 rounded-3xl shadow-sm border border-emerald-100 flex items-center gap-5 transition active:scale-95 hover:shadow-md animate-slide-up"
            style={{ animationDelay: '0.1s' }}
          >
            <div className="bg-emerald-100 text-emerald-600 p-4 rounded-2xl group-hover:rotate-6 transition">
               <Icons.Music size={28} />
            </div>
            <div className="text-left">
              <h3 className="text-lg font-black text-emerald-800 uppercase tracking-tight">পবিত্র সূরাসমূহ</h3>
              <p className="text-[10px] text-gray-500 font-bold uppercase tracking-widest">Surah with Audio & Meaning</p>
            </div>
          </button>

          <button 
            onClick={() => onNavigate('ISLAMIC_ADVICE')}
            className="group bg-white p-6 rounded-3xl shadow-sm border border-emerald-100 flex items-center gap-5 transition active:scale-95 hover:shadow-md animate-slide-up"
            style={{ animationDelay: '0.2s' }}
          >
            <div className="bg-emerald-100 text-teal-600 p-4 rounded-2xl group-hover:rotate-6 transition">
               <Icons.Info size={28} />
            </div>
            <div className="text-left">
              <h3 className="text-lg font-black text-emerald-800 uppercase tracking-tight">আলেমদের উপদেশ</h3>
              <p className="text-[10px] text-gray-500 font-bold uppercase tracking-widest">Islamic Scholars Advice</p>
            </div>
          </button>

          <button 
            onClick={() => onNavigate('PROPHETS_ZONE')}
            className="group bg-white p-6 rounded-3xl shadow-sm border border-emerald-100 flex items-center gap-5 transition active:scale-95 hover:shadow-md animate-slide-up"
            style={{ animationDelay: '0.3s' }}
          >
            <div className="bg-emerald-100 text-emerald-700 p-4 rounded-2xl group-hover:rotate-6 transition">
               <Icons.User size={28} />
            </div>
            <div className="text-left">
              <h3 className="text-lg font-black text-emerald-800 uppercase tracking-tight">নবীদের জীবনী</h3>
              <p className="text-[10px] text-gray-500 font-bold uppercase tracking-widest">Biographies of Prophets</p>
            </div>
          </button>

          <button 
            onClick={() => onNavigate('SAHABA_ZONE')}
            className="group bg-white p-6 rounded-3xl shadow-sm border border-emerald-100 flex items-center gap-5 transition active:scale-95 hover:shadow-md animate-slide-up"
            style={{ animationDelay: '0.4s' }}
          >
            <div className="bg-emerald-100 text-teal-700 p-4 rounded-2xl group-hover:rotate-6 transition">
               <Icons.User size={28} />
            </div>
            <div className="text-left">
              <h3 className="text-lg font-black text-emerald-800 uppercase tracking-tight">সাহাবীদের জীবনী</h3>
              <p className="text-[10px] text-gray-500 font-bold uppercase tracking-widest">Stories of 150 Companions</p>
            </div>
          </button>
        </div>

        <div className="pt-12 text-center">
           <p className="text-[10px] text-emerald-300 font-black uppercase tracking-[0.4em]">Prophetic Guidance Core</p>
        </div>
      </div>
    </Layout>
  );
};
