
import React, { useState, useMemo } from 'react';
import { Layout } from '../components/Layout';
import { Icons } from '../constants';

interface Scientist {
  id: number;
  name: string;
  field: string;
  history: string;
  discoveries: string;
}

const scientistData: Scientist[] = [
  {
    id: 1,
    name: "আলবার্ট আইনস্টাইন (Albert Einstein)",
    field: "তাত্ত্বিক পদার্থবিজ্ঞান",
    history: "১৮৭৯ সালে জার্মানিতে জন্মগ্রহণ করেন। তিনি আধুনিক পদার্থবিজ্ঞানের অন্যতম প্রধান স্তম্ভ। ১৯২১ সালে পদার্থবিজ্ঞানে নোবেল পুরস্কার পান।",
    discoveries: "আপেক্ষিকতার তত্ত্ব (Theory of Relativity), আলোক তড়িৎ ক্রিয়া (Photoelectric effect), E=mc²।"
  },
  {
    id: 2,
    name: "আইজ্যাক নিউটন (Isaac Newton)",
    field: "গণিত ও পদার্থবিজ্ঞান",
    history: "১৬৪৩ সালে ইংল্যান্ডে জন্মগ্রহণ করেন। তিনি ধ্রুপদী বলবিজ্ঞান ও ক্যালকুলাসের ভিত্তি স্থাপন করেন।",
    discoveries: "মহাকর্ষ সূত্র, গতির তিনটি সূত্র, প্রতিফলক টেলিস্কোপ প্রবর্তন।"
  },
  {
    id: 3,
    name: "মেরি কুরি (Marie Curie)",
    field: "পদার্থবিজ্ঞান ও রসায়ন",
    history: "পোল্যান্ডে জন্মগ্রহণকারী এই বিজ্ঞানী দুইবার ভিন্ন ভিন্ন বিষয়ে নোবেল পুরস্কার পাওয়া একমাত্র নারী।",
    discoveries: "তেজস্ক্রিয়তা আবিষ্কার, পলোনিয়াম ও রেডিয়াম নামক মৌল পৃথকীকরণ।"
  },
  {
    id: 4,
    name: "নিকোলা টেসলা (Nikola Tesla)",
    field: "তড়িৎ প্রকৌশল",
    history: "সার্বিয়ান-আমেরিকান বিজ্ঞানী। আধুনিক বিদ্যুৎ সরবরাহ ব্যবস্থার অন্যতম কারিগর।",
    discoveries: "পর্যায়বৃত্ত বিদ্যুৎ (AC), টেসলা কয়েল, ইন্ডাকশন মোটর।"
  },
  {
    id: 5,
    name: "চার্লস ডারউইন (Charles Darwin)",
    field: "জীববিজ্ঞান",
    history: "বিবর্তনবাদের জনক হিসেবে পরিচিত ইংরেজ প্রকৃতিবিদ।",
    discoveries: "প্রাকৃতিক নির্বাচনের মাধ্যমে বিবর্তন তত্ত্ব।"
  },
  {
    id: 6,
    name: "লুই পাস্তুর (Louis Pasteur)",
    field: "অণুজীববিজ্ঞান",
    history: "ফরাসি রসায়নবিদ ও অণুজীববিজ্ঞানী। টিকা আবিষ্কারের মাধ্যমে অসংখ্য মানুষের জীবন রক্ষা করেছেন।",
    discoveries: "পাস্তুরাইজেশন পদ্ধতি, জলাতঙ্কের টিকা।"
  },
  {
    id: 7,
    name: "আলেকজান্ডার ফ্লেমিং (Alexander Fleming)",
    field: "চিকিৎসাবিজ্ঞান",
    history: "স্কটিশ বিজ্ঞানী যিনি অ্যান্টিবায়োটিকের পথপ্রদর্শক।",
    discoveries: "পেনিসিলিন আবিষ্কার।"
  },
  {
    id: 8,
    name: "গ্যালিলিও গ্যালিলি (Galileo Galilei)",
    field: "জ্যোতির্বিজ্ঞান",
    history: "আধুনিক জ্যোতির্বিজ্ঞানের জনক। টেলিস্কোপের উন্নত সংস্করণের মাধ্যমে মহাকাশ গবেষণায় বিপ্লব আনেন।",
    discoveries: "বৃহস্পতির উপগ্রহ পর্যবেক্ষণ, শুক্রের দশা নির্ণয়।"
  },
  {
    id: 9,
    name: "টমাস আলভা এডিসন (Thomas Edison)",
    field: "উদ্ভাবক",
    history: "ইতিহাসের অন্যতম সফল আমেরিকান উদ্ভাবক। ১০০০-এর বেশি পেটেন্টের অধিকারী।",
    discoveries: "বৈদ্যুতিক বাল্ব, ফোনোগ্রাফ, চলচ্চিত্র ক্যামেরা।"
  },
  {
    id: 10,
    name: "আলেকজান্ডার গ্রাহাম বেল (Alexander Graham Bell)",
    field: "প্রকৌশল",
    history: "যোগাযোগ প্রযুক্তিতে বিপ্লব সৃষ্টিকারী বিজ্ঞানী।",
    discoveries: "টেলিফোন আবিষ্কার।"
  },
  {
    id: 11,
    name: "স্টিভেন হকিং (Stephen Hawking)",
    field: "মহাকাশবিজ্ঞান",
    history: "বিখ্যাত ব্রিটিশ তাত্ত্বিক পদার্থবিজ্ঞানী। ব্ল্যাকহোল নিয়ে তাঁর গবেষণা বিশ্বখ্যাত।",
    discoveries: "হকিং রেডিয়েশন, মহাবিশ্বের উৎপত্তি সংক্রান্ত গবেষণা।"
  },
  {
    id: 12,
    name: "ম্যাক্স প্লাঙ্ক (Max Planck)",
    field: "পদার্থবিজ্ঞান",
    history: "কোয়ান্টাম বলবিজ্ঞানের জনক হিসেবে পরিচিত জার্মান পদার্থবিদ।",
    discoveries: "কোয়ান্টাম তত্ত্ব (Energy Quanta)।"
  },
  {
    id: 13,
    name: "রবার্ট হুক (Robert Hooke)",
    field: "পদার্থবিজ্ঞান ও জীববিজ্ঞান",
    history: "অণুবীক্ষণ যন্ত্রের মাধ্যমে কোষ পর্যবেক্ষণকারী প্রথম বিজ্ঞানী।",
    discoveries: "কোষ (Cell) নামকরণ, হুকের স্থিতিস্থাপকতা সূত্র।"
  },
  {
    id: 14,
    name: "জেমস ওয়াট (James Watt)",
    field: "প্রকৌশল",
    history: "বাষ্পীয় ইঞ্জিনকে উন্নত করার মাধ্যমে শিল্প বিপ্লবের সূচনা করেন।",
    discoveries: "উন্নত স্টিম ইঞ্জিন।"
  },
  {
    id: 15,
    name: "মাইকেল ফ্যারাডে (Michael Faraday)",
    field: "তড়িৎ রসায়ন",
    history: "বিদ্যুৎ ও চৌম্বকত্ব নিয়ে কাজ করা মহান ব্রিটিশ বিজ্ঞানী।",
    discoveries: "তড়িৎ-চৌম্বকীয় আবেশ (Electromagnetic Induction), ইলেকট্রোলাইসিস সূত্র।"
  },
  {
    id: 16,
    name: "গ্রেগর মেন্ডেল (Gregor Mendel)",
    field: "বংশগতিবিদ্যা",
    history: "আধুনিক বংশগতিবিদ্যার জনক। মটরশুঁটি গাছ নিয়ে পরীক্ষার জন্য বিখ্যাত।",
    discoveries: "বংশগতির সূত্রসমূহ (Laws of Inheritance)।"
  },
  {
    id: 17,
    name: "আরনেস্ট রাদারফোর্ড (Ernest Rutherford)",
    field: "পরমাণু পদার্থবিজ্ঞান",
    history: "পরমাণুর গঠন সংক্রান্ত গবেষণার জন্য নিউক্লিয়ার ফিজিক্সের জনক বলা হয়।",
    discoveries: "পরমাণুর কেন্দ্রীন (Nucleus) আবিষ্কার, আলফা ও বিটা রশ্মি।"
  },
  {
    id: 18,
    name: "নীলস বোর (Niels Bohr)",
    field: "পরমাণু পদার্থবিজ্ঞান",
    history: "পরমাণুর গঠন এবং কোয়ান্টাম তত্ত্ব নিয়ে কাজ করা ড্যানিশ বিজ্ঞানী।",
    discoveries: "বোর পরমাণু মডেল।"
  },
  {
    id: 19,
    name: "অ্যান্টি ল্যাভয়সিয়ের (Antoine Lavoisier)",
    field: "রসায়ন",
    history: "আধুনিক রসায়নের জনক হিসেবে পরিচিত ফরাসি বিজ্ঞানী।",
    discoveries: "ভরের নিত্যতা সূত্র, অক্সিজেন ও হাইড্রোজেনের নামকরণ।"
  },
  {
    id: 20,
    name: "জোহানেস কেপলার (Johannes Kepler)",
    field: "জ্যোতির্বিজ্ঞান",
    history: "গ্রহের গতিবিধি নিয়ে গাণিতিক ব্যাখ্যা দেওয়া জার্মান বিজ্ঞানী।",
    discoveries: "কেপলারের গ্রহীয় গতিসূত্র।"
  },
  {
    id: 21,
    name: "আরখিমেডিস (Archimedes)",
    field: "গণিত ও যন্ত্রকৌশল",
    history: "প্রাচীন গ্রীসের সর্বশ্রেষ্ঠ বিজ্ঞানী ও গণিতবিদ।",
    discoveries: "আরখিমেডিসের সূত্র (প্লবতা), লিভারের নীতি, পাই (Pi)-এর মান নির্ণয়।"
  },
  {
    id: 22,
    name: "উইলিয়াম হার্ভে (William Harvey)",
    field: "শারীরবৃত্ত",
    history: "রক্ত সঞ্চালন পদ্ধতি সঠিকভাবে বর্ণনা করা প্রথম চিকিৎসক।",
    discoveries: "হৃৎপিণ্ড ও রক্ত সঞ্চালন প্রক্রিয়া।"
  },
  {
    id: 23,
    name: "গুগলিয়েলমো মার্কোনি (Guglielmo Marconi)",
    field: "পদার্থবিজ্ঞান",
    history: "বেতার যোগাযোগের অন্যতম উদ্ভাবক ইতালীয় বিজ্ঞানী।",
    discoveries: "রেডিও বা বেতার যন্ত্র।"
  },
  {
    id: 24,
    name: "জেমস ক্লার্ক ম্যাক্সওয়েল (James Clerk Maxwell)",
    field: "পদার্থবিজ্ঞান",
    history: "তড়িৎ চৌম্বকীয় তত্ত্বের গাণিতিক রূপ প্রদানকারী স্কটিশ বিজ্ঞানী।",
    discoveries: "ম্যাক্সওয়েল সমীকরণসমূহ।"
  },
  {
    id: 25,
    name: "দিমিত্রি মেন্দেলিভ (Dmitri Mendeleev)",
    field: "রসায়ন",
    history: "রাসায়নিক মৌলগুলোকে পর্যায়বৃত্ত সারণিতে সাজানো রুশ বিজ্ঞানী।",
    discoveries: "পর্যায় সারণি (Periodic Table)।"
  },
  {
    id: 26,
    name: "জন ডাল্টন (John Dalton)",
    field: "রসায়ন ও পদার্থবিজ্ঞান",
    history: "আধুনিক পরমাণুবাদের প্রবক্তা ইংরেজ বিজ্ঞানী।",
    discoveries: "ডাল্টনের পরমাণুবাদ, বর্ণান্ধতা নিয়ে গবেষণা।"
  },
  {
    id: 27,
    name: "অ্যালান টুরিং (Alan Turing)",
    field: "কম্পিউটার বিজ্ঞান",
    history: "আধুনিক কম্পিউটার বিজ্ঞান ও কৃত্রিম বুদ্ধিমত্তার জনক।",
    discoveries: "টুরিং মেশিন, ইনিগমা কোড ব্রেকিং।"
  },
  {
    id: 28,
    name: "আলেকজান্ডার ভোল্টা (Alessandro Volta)",
    field: "তড়িৎ বিজ্ঞান",
    history: "প্রথম বৈদ্যুতিক ব্যাটারি উদ্ভাবনকারী ইতালীয় বিজ্ঞানী।",
    discoveries: "ভোল্টাইক পাইল (ব্যাটারি), মিথেন গ্যাস।"
  },
  {
    id: 29,
    name: "সি ভি রমন (C. V. Raman)",
    field: "পদার্থবিজ্ঞান",
    history: "ভারতীয় বিজ্ঞানী যিনি প্রথম এশীয় হিসেবে বিজ্ঞানে নোবেল পান।",
    discoveries: "রমন প্রভাব (Raman Effect) - আলোর বিচ্ছুরণ।"
  },
  {
    id: 30,
    name: "জগদীশ চন্দ্র বসু (Jagadish Chandra Bose)",
    field: "জীববিজ্ঞান ও পদার্থবিজ্ঞান",
    history: "বাঙালি বিজ্ঞানী যিনি প্রমাণ করেন উদ্ভিদের প্রাণ আছে।",
    discoveries: "ক্রেসকোগ্রাফ (উদ্ভিদের বৃদ্ধি পরিমাপক), বেতার তরঙ্গ নিয়ে প্রাথমিক গবেষণা।"
  },
  {
    id: 31,
    name: "ইবনে আল-হাইথাম (Ibn al-Haytham)",
    field: "আলোকবিজ্ঞান",
    history: "তিনি আধুনিক আলোকবিজ্ঞানের জনক হিসেবে পরিচিত। মুসলিম বিজ্ঞানী যিনি আলোর প্রতিফলন ও প্রতিসরণ নিয়ে মৌলিক কাজ করেছেন।",
    discoveries: "ক্যামেরা অবস্কিউরা, আলোকবিজ্ঞানের নীতিমালা।"
  },
  {
    id: 32,
    name: "আল-খোয়ারিজমি (Al-Khwarizmi)",
    field: "গণিত",
    history: "তিনি বীজগণিতের জনক হিসেবে খ্যাত। তাঁর নাম থেকেই 'অ্যালগরিদম' শব্দটি এসেছে।",
    discoveries: "বীজগণিত (Algebra), দশমিক পদ্ধতির প্রচার।"
  },
  {
    id: 33,
    name: "ইবনে সিনা (Avicenna)",
    field: "চিকিৎসাবিজ্ঞান",
    history: "মধ্যযুগের শ্রেষ্ঠ চিকিৎসাবিজ্ঞানী। তাঁর রচিত বই 'দ্য কানুন অব মেডিসিন' ইউরোপে শত শত বছর পাঠ্য ছিল।",
    discoveries: "আধুনিক চিকিৎসাবিজ্ঞানের ভিত্তি, সংক্রামক রোগের প্রকৃতি নির্ণয়।"
  },
  {
    id: 34,
    name: "আল-বিরুনি (Al-Biruni)",
    field: "বহুবিদ্যাবিশারদ",
    history: "মধ্যযুগের শ্রেষ্ঠ নৃতাত্ত্বিক ও ভূগোলবিদ। তিনি পৃথিবীর ব্যাসার্ধ নিখুঁতভাবে পরিমাপ করেছিলেন।",
    discoveries: "পৃথিবীর আহ্নিক গতি, ভূ-তাত্ত্বিক গঠন বিশ্লেষণ।"
  },
  {
    id: 35,
    name: "জাবির ইবনে হাইয়ান (Jabir ibn Hayyan)",
    field: "রসায়ন",
    history: "রসায়নের জনক হিসেবে পরিচিত। তিনি ল্যাবরেটরিতে বৈজ্ঞানিক পরীক্ষার প্রবর্তন করেন।",
    discoveries: "পাতন (Distillation), সালফিউরিক ও নাইট্রিক অ্যাসিড।"
  },
  {
    id: 36,
    name: "রোজালিন্ড ফ্র্যাঙ্কলিন (Rosalind Franklin)",
    field: "জীববিজ্ঞান",
    history: "ডিএনএ-এর গঠন আবিষ্কারে তাঁর এক্স-রে ডিফ্র্যাকশন ছবি ছিল অত্যন্ত গুরুত্বপূর্ণ।",
    discoveries: "ডিএনএ-এর ডাবল হেলিক্স কাঠামোর প্রমাণ।"
  },
  {
    id: 37,
    name: "অ্যাডা লাভলেস (Ada Lovelace)",
    field: "কম্পিউটার বিজ্ঞান",
    history: "বিশ্বের প্রথম কম্পিউটার প্রোগ্রামার হিসেবে স্বীকৃত ইংরেজ নারী গণিতবিদ।",
    discoveries: "অ্যানালিটিক্যাল ইঞ্জিনের জন্য প্রথম অ্যালগরিদম।"
  },
  {
    id: 38,
    name: "রিচার্ড ফেইনম্যান (Richard Feynman)",
    field: "পদার্থবিজ্ঞান",
    history: "আমেরিকান তাত্ত্বিক পদার্থবিদ। কোয়ান্টাম ইলেকট্রোডাইনামিকসের জন্য নোবেল পান।",
    discoveries: "ফেইনম্যান ডায়াগ্রাম, ন্যানো টেকনোলজির ধারণা।"
  },
  {
    id: 39,
    name: "ওয়ার্নার হাইজেনবার্গ (Werner Heisenberg)",
    field: "কোয়ান্টাম পদার্থবিজ্ঞান",
    history: "জার্মান পদার্থবিদ যিনি কোয়ান্টাম বলবিজ্ঞানের অন্যতম প্রবক্তা।",
    discoveries: "অনিশ্চয়তা নীতি (Uncertainty Principle)।"
  },
  {
    id: 40,
    name: "আরউইন শ্রোডিঙ্গার (Erwin Schrödinger)",
    field: "কোয়ান্টাম পদার্থবিজ্ঞান",
    history: "অস্ট্রীয় পদার্থবিদ যিনি তরঙ্গ বলবিজ্ঞানের ভিত্তি স্থাপন করেন।",
    discoveries: "শ্রোডিঙ্গার সমীকরণ, কোয়ান্টাম মেকানিক্স।"
  },
  {
    id: 41,
    name: "লাইনাস পলিং (Linus Pauling)",
    field: "রসায়ন",
    history: "একমাত্র ব্যক্তি যিনি দুইটি পৃথক ক্ষেত্রে এককভাবে নোবেল পুরস্কার পান।",
    discoveries: "রাসায়নিক বন্ধন (Chemical Bond), মলিকুলার বায়োলজি।"
  },
  {
    id: 42,
    name: "রবার্ট ওপেনহাইমার (Robert Oppenheimer)",
    field: "পারমাণবিক পদার্থবিজ্ঞান",
    history: "পারমাণবিক বোমার জনক হিসেবে পরিচিত আমেরিকান বিজ্ঞানী।",
    discoveries: "ম্যানহাটন প্রজেক্ট পরিচালনা।"
  },
  {
    id: 43,
    name: "কার্ল সাগান (Carl Sagan)",
    field: "জ্যোতির্বিজ্ঞান",
    history: "মহাকাশ বিজ্ঞানকে সাধারণ মানুষের কাছে জনপ্রিয় করার কারিগর।",
    discoveries: "শুক্র গ্রহের তাপমাত্রা বিশ্লেষণ, কসমস সিরিজ।"
  },
  {
    id: 44,
    name: "জেন গুডল (Jane Goodall)",
    field: "নৃতত্ত্ব ও জীববিজ্ঞান",
    history: "শিম্পাঞ্জিদের আচরণ গবেষণায় বিশ্বের শীর্ষস্থানীয় বিশেষজ্ঞ।",
    discoveries: "শিম্পাঞ্জিদের সামাজিক ও সরঞ্জাম ব্যবহারের ক্ষমতা আবিষ্কার।"
  },
  {
    id: 45,
    name: "রেচেল কারসন (Rachel Carson)",
    field: "পরিবেশ বিজ্ঞান",
    history: "তাঁর 'সাইলেন্ট স্প্রিং' বই পরিবেশবাদী আন্দোলনের সূচনা করে।",
    discoveries: "কীটনাশকের ক্ষতিকর প্রভাব সম্পর্কে সচেতনতা।"
  },
  {
    id: 46,
    name: "এস চন্দ্রশেখর (S. Chandrasekhar)",
    field: "জ্যোতিঃপদার্থবিজ্ঞান",
    history: "নক্ষত্রের বিবর্তন ও গঠন নিয়ে গবেষণার জন্য নোবেল পান।",
    discoveries: "চন্দ্রশেখর সীমা (Chandrasekhar Limit)।"
  },
  {
    id: 47,
    name: "সত্যেন্দ্রনাথ বসু (Satyendra Nath Bose)",
    field: "তাত্ত্বিক পদার্থবিজ্ঞান",
    history: "বিখ্যাত বাঙালি বিজ্ঞানী। তাঁর নামেই 'বোসন' কণার নামকরণ করা হয়েছে।",
    discoveries: "বসু-আইনস্টাইন পরিসংখ্যান (Bose-Einstein Statistics)।"
  },
  {
    id: 48,
    name: "হোমি জে ভাবা (Homi J. Bhabha)",
    field: "পারমাণবিক শক্তি",
    history: "ভারতের পারমাণবিক কর্মসূচির জনক হিসেবে পরিচিত।",
    discoveries: "কসমিক রেডিয়েশন গবেষণা।"
  },
  {
    id: 49,
    name: "বিক্রম সারাভাই (Vikram Sarabhai)",
    field: "মহাকাশ গবেষণা",
    history: "ভারতীয় মহাকাশ গবেষণার (ISRO) প্রধান স্বপ্নদ্রষ্টা।",
    discoveries: "মহাকাশ বিজ্ঞানের প্রাতিষ্ঠানিক উন্নয়ন।"
  },
  {
    id: 50,
    name: "শ্রীনিবাস রামানুজন (Srinivasa Ramanujan)",
    field: "গণিত",
    history: "ভারতীয় গণিত প্রতিভা যিনি স্বশিক্ষায় গণিতের জটিল সমাধান বের করেছেন।",
    discoveries: "অসীম ধারা, নাম্বার থিওরি।"
  },
  {
    id: 51,
    name: "পিথাগোরাস (Pythagoras)",
    field: "গণিত",
    history: "প্রাচীন গ্রীক গণিতবিদ। তাঁর নামে বিখ্যাত জ্যামিতিক উপপাদ্য রয়েছে।",
    discoveries: "পিথাগোরাসের উপপাদ্য (সমকোণী ত্রিভুজ)।"
  },
  {
    id: 52,
    name: "ইউক্লিড (Euclid)",
    field: "জ্যামিতি",
    history: "জ্যামিতির জনক হিসেবে পরিচিত প্রাচীন গ্রীক গণিতবিদ।",
    discoveries: "এলিমেন্টস (জ্যামিতির মৌলিক গ্রন্থ)।"
  },
  {
    id: 53,
    name: "হিপোক্রেটিস (Hippocrates)",
    field: "চিকিৎসাবিজ্ঞান",
    history: "চিকিৎসাবিজ্ঞানের জনক। চিকিৎসকদের শপথ (Hippocratic Oath) তাঁর নামেই।",
    discoveries: "রোগের বৈজ্ঞানিক কারণ বিশ্লেষণ।"
  },
  {
    id: 54,
    name: "অ্যারিস্টটল (Aristotle)",
    field: "দর্শন ও বিজ্ঞান",
    history: "প্রাচীন গ্রীসের সর্বশ্রেষ্ঠ দার্শনিক ও বহুবিদ্যাবিশারদ।",
    discoveries: "জীববিজ্ঞানের প্রাথমিক শ্রেণীবিন্যাস, যুক্তিবিদ্যা।"
  },
  {
    id: 55,
    name: "লিওনার্দো দা ভিঞ্চি (Leonardo da Vinci)",
    field: "বহুবিদ্যাবিশারদ",
    history: "রেনেসাঁ যুগের অন্যতম শ্রেষ্ঠ উদ্ভাবক ও শিল্পী।",
    discoveries: "উড়োজাহাজ ও হেলিকপ্টারের প্রাথমিক নকশা, মানবদেহের গঠন।"
  },
  {
    id: 56,
    name: "বেনজামিন ফ্র্যাঙ্কলিন (Benjamin Franklin)",
    field: "পদার্থবিজ্ঞান ও রাজনীতি",
    history: "বিদ্যুৎ নিয়ে গবেষণার জন্য বিখ্যাত আমেরিকান উদ্ভাবক।",
    discoveries: "বজ্রনিরোধক দণ্ড (Lightning Rod), বাইফোকাল লেন্স।"
  },
  {
    id: 57,
    name: "লুই ব্রেইল (Louis Braille)",
    field: "শিক্ষা ও উদ্ভাবন",
    history: "অন্ধ মানুষদের জন্য পড়ার পদ্ধতি ব্রেইল পদ্ধতির উদ্ভাবক।",
    discoveries: "ব্রেইল লিখন পদ্ধতি।"
  },
  {
    id: 58,
    name: "আলফ্রেড নোবেল (Alfred Nobel)",
    field: "রসায়ন ও উদ্ভাবক",
    history: "নোবেল পুরস্কারের প্রতিষ্ঠাতা এবং ডিনামাইটের উদ্ভাবক।",
    discoveries: "ডিনামাইট, বিভিন্ন বিস্ফোরক।"
  },
  {
    id: 59,
    name: "জর্জ ওয়াশিংটন কার্ভার (George W. Carver)",
    field: "কৃষি বিজ্ঞান",
    history: "কৃষি গবেষণায় বিপ্লব সৃষ্টিকারী আমেরিকান বিজ্ঞানী।",
    discoveries: "বাদাম ও মিষ্টি আলুর বহুমুখী ব্যবহার।"
  },
  {
    id: 60,
    name: "জোনাস সাল্ক (Jonas Salk)",
    field: "চিকিৎসাবিজ্ঞান",
    history: "পোলিও রোগের সফল প্রতিষেধক আবিষ্কার করেন।",
    discoveries: "পোলিও ভ্যাকসিন।"
  },
  {
    id: 61,
    name: "এডওয়ার্ড জেনার (Edward Jenner)",
    field: "চিকিৎসাবিজ্ঞান",
    history: "টিকা বা ভ্যাকসিনেশনের পথপ্রদর্শক হিসেবে পরিচিত।",
    discoveries: "গুটিবসন্তের (Smallpox) টিকা।"
  },
  {
    id: 62,
    name: "ফ্রান্সিস ক্রিক (Francis Crick)",
    field: "জীববিজ্ঞান",
    history: "ডিএনএ-এর গঠন আবিষ্কারের জন্য বিখ্যাত ব্রিটিশ বিজ্ঞানী।",
    discoveries: "ডিএনএ ডাবল হেলিক্স স্ট্রাকচার।"
  },
  {
    id: 63,
    name: "জেমস ওয়াটসন (James Watson)",
    field: "জীববিজ্ঞান",
    history: "ক্রিকের সাথে মিলে ডিএনএ রহস্য উন্মোচনকারী আমেরিকান বিজ্ঞানী।",
    discoveries: "মলিকুলার বায়োলজি উন্নয়ন।"
  },
  {
    id: 64,
    name: "মরিস উইলকিন্স (Maurice Wilkins)",
    field: "জীববিজ্ঞান",
    history: "ডিএনএ-এর এক্স-রে ডিফ্র্যাকশন নিয়ে কাজ করা নোবেলজয়ী বিজ্ঞানী।",
    discoveries: "ডিএনএ কাঠামোর পরীক্ষামূলক প্রমাণ।"
  },
  {
    id: 65,
    name: "ডরোথি হজকিন (Dorothy Hodgkin)",
    field: "রসায়ন",
    history: "এক্স-রে ক্রিস্টালোগ্রাফির মাধ্যমে প্রোটিন গঠন নির্ণয়ের পথিকৃৎ।",
    discoveries: "পেনিসিলিন ও ভিটামিন বি১২-এর গঠন নির্ণয়।"
  },
  {
    id: 66,
    name: "বারবারা ম্যাকক্লিনটক (Barbara McClintock)",
    field: "জেনেটিক্স",
    history: "ভুট্টা গাছের জিনের পরিবর্তনশীলতা নিয়ে গবেষণার জন্য নোবেল পান।",
    discoveries: "জাম্পিং জিন (Transposons)।"
  },
  {
    id: 67,
    name: "লিস মিটনার (Lise Meitner)",
    field: "নিউক্লিয়ার ফিজিক্স",
    history: "নিউক্লিয়ার ফিশন আবিষ্কারের অন্যতম প্রধান কারিগর।",
    discoveries: "নিউক্লিয়ার ফিশন (Nuclear Fission)।"
  },
  {
    id: 68,
    name: "চিয়েন-শিউং উ (Chien-Shiung Wu)",
    field: "পদার্থবিজ্ঞান",
    history: "প্রথম দিকের পারমাণবিক পদার্থবিজ্ঞানী হিসেবে খ্যাত চীনা-আমেরিকান নারী।",
    discoveries: "বিটা ক্ষয় এবং দুর্বল মিথস্ক্রিয়া।"
  },
  {
    id: 69,
    name: "এমি নোয়েথার (Emmy Noether)",
    field: "গণিত",
    history: "আইনস্টাইন যাকে সর্বকালের সেরা নারী গণিতবিদ বলেছেন।",
    discoveries: "নোয়েথার উপপাদ্য (ভৌত আইন ও প্রতিসাম্য)।"
  },
  {
    id: 70,
    name: "সোফি জার্মেইন (Sophie Germain)",
    field: "গণিত",
    history: "ফরাসি গণিতবিদ যিনি স্থিতিস্থাপকতা ও সংখ্যাতত্ত্বে কাজ করেছেন।",
    discoveries: "ফার্মাটের শেষ উপপাদ্য সংক্রান্ত গবেষণা।"
  },
  {
    id: 71,
    name: "ক্যাথরিন জনসন (Katherine Johnson)",
    field: "গণিত ও মহাকাশবিজ্ঞান",
    history: "নাসা-র সফল মহাকাশ অভিযানের গাণিতিক হিসাবকারী।",
    discoveries: "অ্যাপোলো মিশনের কক্ষপথ গণনা।"
  },
  {
    id: 72,
    name: "গ্রেগরি পেরেলম্যান (Grigori Perelman)",
    field: "গণিত",
    history: "যিনি গণিতের কঠিনতম 'পোয়েনকেয়ার কনজেকচার' সমাধান করেছেন।",
    discoveries: "পোয়েনকেয়ার কনজেকচার সমাধান।"
  },
  {
    id: 73,
    name: "গ্রেস হপার (Grace Hopper)",
    field: "কম্পিউটার বিজ্ঞান",
    history: "আধুনিক প্রোগ্রামিং ভাষার জননী এবং রিয়ার অ্যাডমিরাল।",
    discoveries: "প্রথম কম্পাইলার, কোবোল (COBOL) ভাষা।"
  },
  {
    id: 74,
    name: "মার্গারেট হ্যামিল্টন (Margaret Hamilton)",
    field: "সফটওয়্যার ইঞ্জিনিয়ারিং",
    history: "অ্যাপোলো মিশনের অন-বোর্ড ফ্লাইট সফটওয়্যার তৈরির প্রধান।",
    discoveries: "সফটওয়্যার ইঞ্জিনিয়ারিং টার্মটির প্রবর্তন।"
  },
  {
    id: 75,
    name: "হেডি লামার (Hedy Lamarr)",
    field: "উদ্ভাবক ও অভিনেত্রী",
    history: "যিনি আধুনিক ওয়াই-ফাই ও ব্লুটুথ প্রযুক্তির ভিত্তি স্থাপন করেন।",
    discoveries: "ফ্রিকোয়েন্সি হপিং (Frequency Hopping)।"
  },
  {
    id: 76,
    name: "ভেরা রুবিন (Vera Rubin)",
    field: "জ্যোতির্বিজ্ঞান",
    history: "যিনি মহাবিশ্বে 'ডার্ক ম্যাটার'-এর অস্তিত্ব প্রমাণ করেন।",
    discoveries: "ডার্ক ম্যাটার (Dark Matter)।"
  },
  {
    id: 77,
    name: "জোসেলিন বেল বার্নেল (Jocelyn Bell Burnell)",
    field: "জ্যোতির্বিজ্ঞান",
    history: "যিনি প্রথম পালসার (Pulsar) নক্ষত্র আবিষ্কার করেন।",
    discoveries: "পালসার আবিষ্কার।"
  },
  {
    id: 78,
    name: "স্যালি রাইড (Sally Ride)",
    field: "মহাকাশবিজ্ঞান",
    history: "মহাকাশে যাওয়া প্রথম আমেরিকান নারী।",
    discoveries: "মহাকাশ গবেষণা ও শিক্ষা উন্নয়ন।"
  },
  {
    id: 79,
    name: "নীল আর্মস্ট্রং (Neil Armstrong)",
    field: "মহাকাশচারী",
    history: "চাঁদে পা রাখা বিশ্বের প্রথম মানুষ।",
    discoveries: "চাঁদপৃষ্ঠে অবতরণ ও নমুনা সংগ্রহ।"
  },
  {
    id: 80,
    name: "ইউরি গ্যাগারিন (Yuri Gagarin)",
    field: "মহাকাশচারী",
    history: "মহাকাশে যাওয়া বিশ্বের প্রথম মানুষ (সোভিয়েত ইউনিয়ন)।",
    discoveries: "পৃথিবীর কক্ষপথ প্রদক্ষিণ।"
  },
  {
    id: 81,
    name: "এডউইন হাবল (Edwin Hubble)",
    field: "জ্যোতির্বিজ্ঞান",
    history: "যিনি প্রমাণ করেন মহাবিশ্ব প্রসারিত হচ্ছে।",
    discoveries: "হাবল সূত্র, ছায়াপথের শ্রেণীবিন্যাস।"
  },
  {
    id: 82,
    name: "কার্ল ফ্রেডরিক গাউস (Carl Friedrich Gauss)",
    field: "গণিত",
    history: "গণিতরাজ হিসেবে পরিচিত বিশ্বখ্যাত গণিতবিদ।",
    discoveries: "গাউসিয়ান ডিস্ট্রিবিউশন, সংখ্যাতত্ত্ব।"
  },
  {
    id: 83,
    name: "বার্নহার্ড রিমান (Bernhard Riemann)",
    field: "গণিত",
    history: "রিমান জ্যামিতির উদ্ভাবক যা আইনস্টাইনের আপেক্ষিকতায় কাজে লাগে।",
    discoveries: "রিমান হাইপোথিসিস।"
  },
  {
    id: 84,
    name: "লিওনার্ড ইউলার (Leonhard Euler)",
    field: "গণিত",
    history: "ইতিহাসের অন্যতম প্রোডাক্টিভ গণিতবিদ।",
    discoveries: "ইউলারের সংখ্যা (e), গ্রাফ থিওরি।"
  },
  {
    id: 85,
    name: "গটফ্রিড লিবনিজ (Gottfried Leibniz)",
    field: "গণিত ও দর্শন",
    history: "নিউটন-এর পাশাপাশি ক্যালকুলাসের স্বাধীন উদ্ভাবক।",
    discoveries: "ক্যালকুলাস নোটেশন, বাইনারি সিস্টেম।"
  },
  {
    id: 86,
    name: "ব্লেইজ প্যাস্কেল (Blaise Pascal)",
    field: "গণিত ও পদার্থবিজ্ঞান",
    history: "প্যাস্কেল ক্যালকুলেটর ও সম্ভাব্যতার তত্ত্বের জন্য বিখ্যাত।",
    discoveries: "প্যাস্কেলের সূত্র (চাপ), প্যাস্কেল ত্রিভুজ।"
  },
  {
    id: 87,
    name: "পিয়েরে দ্য ফার্মা (Pierre de Fermat)",
    field: "গণিত",
    history: "ফার্মাটের শেষ উপপাদ্যের জন্য বিশ্বখ্যাত।",
    discoveries: "ফার্মাটের সূত্র, ক্যালকুলাসের প্রাথমিক কাজ।"
  },
  {
    id: 88,
    name: "রেনে দেকার্তে (René Descartes)",
    field: "গণিত ও দর্শন",
    history: "আধুনিক জ্যামিতির প্রবক্তা (কার্টেসিয়ান জ্যামিতি)।",
    discoveries: "স্থানাঙ্ক জ্যামিতি (Coordinate Geometry)।"
  },
  {
    id: 89,
    name: "ক্রিশ্চিয়ান হাইগেনস (Christiaan Huygens)",
    field: "পদার্থবিজ্ঞান",
    history: "আলোর তরঙ্গ তত্ত্বের প্রবক্তা ডাচ বিজ্ঞানী।",
    discoveries: "শনির বলয় আবিষ্কার, ঘড়ির পেন্ডুলাম।"
  },
  {
    id: 90,
    name: "রবার্ট বয়েল (Robert Boyle)",
    field: "রসায়ন",
    history: "আধুনিক রসায়নের ভিত্তি স্থাপনকারী বিজ্ঞানী।",
    discoveries: "বয়েলের সূত্র (গ্যাসের চাপ ও আয়তন)।"
  },
  {
    id: 91,
    name: "জোসেফ প্রিস্টলি (Joseph Priestley)",
    field: "রসায়ন",
    history: "অক্সিজেন আবিষ্কারের অন্যতম কৃতিত্বপূর্ণ বিজ্ঞানী।",
    discoveries: "অক্সিজেন গ্যাস পৃথকীকরণ।"
  },
  {
    id: 92,
    name: "হামফ্রে ডেভি (Humphry Davy)",
    field: "রসায়ন",
    history: "যিনি ইলেকট্রোলাইসিস ব্যবহার করে অনেক মৌলিক পদার্থ আবিষ্কার করেন।",
    discoveries: "সোডিয়াম ও পটাশিয়াম পৃথকীকরণ।"
  },
  {
    id: 93,
    name: "জন বারডিন (John Bardeen)",
    field: "পদার্থবিজ্ঞান",
    history: "একমাত্র বিজ্ঞানী যিনি দুইবার পদার্থবিজ্ঞানে নোবেল পান।",
    discoveries: "ট্রানজিস্টর আবিষ্কার, অতিপরিবাহিতা (Superconductivity)।"
  },
  {
    id: 94,
    name: "উইলিয়াম শকলি (William Shockley)",
    field: "পদার্থবিজ্ঞান",
    history: "সিলিকন ভ্যালির অন্যতম ভিত্তি স্থাপনকারী ও ট্রানজিস্টর উদ্ভাবক।",
    discoveries: "সেমিকন্ডাক্টর ও ট্রানজিস্টর।"
  },
  {
    id: 95,
    name: "টিম বার্নার্স-লি (Tim Berners-Lee)",
    field: "কম্পিউটার বিজ্ঞান",
    history: "ওয়ার্ল্ড ওয়াইড ওয়েব (WWW)-এর উদ্ভাবক ব্রিটিশ বিজ্ঞানী।",
    discoveries: "HTTP, HTML এবং প্রথম ওয়েব ব্রাউজার।"
  },
  {
    id: 96,
    name: "ভিন্ট সার্ফ (Vint Cerf)",
    field: "কম্পিউটার বিজ্ঞান",
    history: "ইন্টারনেটের অন্যতম জনক হিসেবে পরিচিত।",
    discoveries: "TCP/IP প্রোটোকল।"
  },
  {
    id: 97,
    name: "স্টিভ জবস (Steve Jobs)",
    field: "উদ্ভাবক ও প্রযুক্তি",
    history: "অ্যাপল কম্পিউটারের প্রতিষ্ঠাতা এবং ব্যক্তিগত কম্পিউটিং বিপ্লবের নায়ক।",
    discoveries: "আইফোন, ম্যাকিনটোশ এবং আধুনিক ইন্টারফেস।"
  },
  {
    id: 98,
    name: "বিল গেটস (Bill Gates)",
    field: "সফটওয়্যার ও প্রযুক্তি",
    history: "মাইক্রোসফটের প্রতিষ্ঠাতা এবং বিশ্বের কম্পিউটার সফটওয়্যার জগতে বিপ্লব সৃষ্টিকারী।",
    discoveries: "উইন্ডোজ অপারেটিং সিস্টেম।"
  },
  {
    id: 99,
    name: "নিকোলাস অটো (Nikolaus Otto)",
    field: "যন্ত্রকৌশল",
    history: "অভ্যন্তরীণ দহন ইঞ্জিনের (Internal Combustion Engine) উদ্ভাবক।",
    discoveries: "অটো সাইকেল ইঞ্জিন।"
  },
  {
    id: 100,
    name: "রুডলফ ডিজেল (Rudolf Diesel)",
    field: "যন্ত্রকৌশল",
    history: "ডিজেল ইঞ্জিনের উদ্ভাবক জার্মান বিজ্ঞানী।",
    discoveries: "ডিজেল ইঞ্জিন প্রযুক্তি।"
  },
  {
    id: 101,
    name: "কার্ল বেঞ্জ (Karl Benz)",
    field: "যন্ত্রকৌশল",
    history: "আধুনিক গাড়ির প্রথম সফল উদ্ভাবক।",
    discoveries: "প্রথম পেট্রোল চালিত গাড়ি।"
  },
  {
    id: 102,
    name: "হেনরি ফোর্ড (Henry Ford)",
    field: "উদ্ভাবক ও শিল্প",
    history: "যিনি অ্যাসেম্বলি লাইনের মাধ্যমে গাড়ির উৎপাদন সহজ করেন।",
    discoveries: "ফোর্ড মডেল টি, ব্যাপক উৎপাদন পদ্ধতি।"
  }
];

export const ScientistZone: React.FC<{ onBack: () => void }> = ({ onBack }) => {
  const [search, setSearch] = useState('');
  const [selected, setSelected] = useState<Scientist | null>(null);

  const filtered = useMemo(() => {
    return scientistData.filter(s => 
      s.name.toLowerCase().includes(search.toLowerCase()) || 
      s.field.toLowerCase().includes(search.toLowerCase()) ||
      s.id.toString() === search.trim()
    );
  }, [search]);

  if (selected) {
    return (
      <Layout title={selected.name} onBack={() => setSelected(null)} className="bg-white">
        <div className="animate-fade-in p-6">
           <div className="bg-indigo-600 text-white p-8 rounded-[2.5rem] shadow-xl mb-8 relative overflow-hidden">
              <div className="absolute top-0 right-0 p-4 opacity-10">
                 <Icons.Brain size={120} />
              </div>
              <p className="text-[10px] font-black uppercase tracking-[0.3em] mb-2 opacity-80">Profile View</p>
              <h1 className="text-3xl font-black leading-tight mb-2">{selected.name}</h1>
              <span className="bg-white/20 px-3 py-1 rounded-full text-xs font-bold border border-white/20">{selected.field}</span>
           </div>

           <div className="space-y-8 pb-20">
              <section className="animate-slide-up">
                 <div className="flex items-center gap-3 mb-4">
                    <div className="w-1.5 h-6 bg-indigo-500 rounded-full"></div>
                    <h2 className="text-lg font-black text-indigo-900 uppercase tracking-tight">সংক্ষিপ্ত ইতিহাস</h2>
                 </div>
                 <p className="text-gray-700 leading-relaxed font-medium text-justify">{selected.history}</p>
              </section>

              <section className="animate-slide-up" style={{ animationDelay: '0.1s' }}>
                 <div className="flex items-center gap-3 mb-4">
                    <div className="w-1.5 h-6 bg-brand-500 rounded-full"></div>
                    <h2 className="text-lg font-black text-brand-900 uppercase tracking-tight">প্রধান আবিষ্কার ও অবদান</h2>
                 </div>
                 <div className="bg-brand-50 p-6 rounded-3xl border border-brand-100 shadow-sm">
                    <p className="text-brand-900 font-bold leading-relaxed">{selected.discoveries}</p>
                 </div>
              </section>
           </div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout title="Scientist History" onBack={onBack} className="bg-gray-50">
      <div className="sticky top-0 z-20 bg-gray-50 p-4 shadow-sm border-b border-gray-100">
        <div className="bg-white p-2 rounded-2xl shadow-inner border border-indigo-100 flex items-center gap-2">
           <div className="p-2 text-indigo-400">
              <Icons.Brain size={20} />
           </div>
           <input 
             placeholder="বিজ্ঞানীর নাম বা কাজের ক্ষেত্র..." 
             value={search} 
             onChange={e => setSearch(e.target.value)}
             className="w-full bg-transparent border-none focus:ring-0 text-indigo-900 font-bold placeholder:text-indigo-200 text-sm"
           />
        </div>
      </div>

      <div className="p-4 grid grid-cols-1 gap-4 pb-24">
        {filtered.length === 0 ? (
          <div className="text-center py-20 text-gray-400 font-bold">দুঃখিত, কোনো বিজ্ঞানীর তথ্য পাওয়া যায়নি।</div>
        ) : (
          filtered.map((s, idx) => (
            <button 
              key={s.id} 
              onClick={() => setSelected(s)}
              className="group bg-white p-5 rounded-3xl shadow-sm border border-gray-100 flex items-center justify-between transition-all active:scale-95 hover:shadow-md animate-slide-up"
              style={{ animationDelay: `${idx * 0.01}s` }}
            >
               <div className="flex items-center gap-4">
                  <div className="bg-indigo-50 text-indigo-600 w-12 h-12 rounded-2xl flex items-center justify-center group-hover:bg-indigo-600 group-hover:text-white transition-colors duration-300">
                     <span className="font-black text-xs">{s.id}</span>
                  </div>
                  <div className="text-left">
                     <h3 className="text-md font-black text-gray-800 uppercase tracking-tight leading-tight">{s.name}</h3>
                     <p className="text-[9px] text-indigo-500 font-bold uppercase tracking-widest mt-1">{s.field}</p>
                  </div>
               </div>
               <div className="text-gray-300 group-hover:text-indigo-600 transition-colors rotate-180">
                  <Icons.ArrowLeft size={18} />
               </div>
            </button>
          ))
        )}
      </div>

      <div className="fixed bottom-6 right-6 z-50">
         <div className="bg-indigo-600 text-white px-5 py-2 rounded-full shadow-lg font-black text-[10px] uppercase tracking-widest border-2 border-white">
            মোট বিজ্ঞানী: {scientistData.length}
         </div>
      </div>
    </Layout>
  );
};
