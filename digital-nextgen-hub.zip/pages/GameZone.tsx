
import React, { useState, useEffect, useRef } from 'react';
import { Layout, Button, Input } from '../components/Layout';
import { Icons } from '../constants';

interface GameZoneProps {
  onBack: () => void;
}

export const GameZone: React.FC<GameZoneProps> = ({ onBack }) => {
  const [activeGame, setActiveGame] = useState<string | null>(null);

  const games = [
    { id: 'tictactoe', title: 'Tic Tac Toe', icon: <Icons.Target />, color: 'from-orange-400 to-red-500', desc: 'Beat the CPU or friend' },
    { id: 'clicker', title: 'CPS Speed', icon: <Icons.Activity />, color: 'from-blue-400 to-indigo-600', desc: 'How fast can you tap?' },
    { id: 'math', title: 'Math Master', icon: <Icons.Brain />, color: 'from-green-400 to-emerald-600', desc: 'Sharpen your mind' },
    { id: 'memory', title: 'Memory Cards', icon: <Icons.Gamepad />, color: 'from-purple-400 to-pink-600', desc: 'Find all matching pairs' },
    { id: 'coin', title: 'Coin Flip 3D', icon: <Icons.Target />, color: 'from-yellow-400 to-orange-500', desc: 'Luck of the draw' },
    { id: 'guessing', title: 'Guess Number', icon: <Icons.Plus />, color: 'from-cyan-400 to-blue-500', desc: 'Predict the hidden value' },
    { id: 'reaction', title: 'Reflex Test', icon: <Icons.Clock />, color: 'from-rose-400 to-red-600', desc: 'Wait for the green light' },
    { id: 'dice', title: 'Dice Roller', icon: <Icons.Gamepad />, color: 'from-slate-400 to-slate-700', desc: 'Roll for your destiny' },
    // NEW CREATIVE GAMES
    { id: 'snake', title: 'Snake Classic', icon: <Icons.Activity />, color: 'from-emerald-500 to-teal-700', desc: 'Legacy slither challenge' },
    { id: 'colormaster', title: 'Color Master', icon: <Icons.Sun />, color: 'from-amber-400 to-yellow-600', desc: 'Text vs Color reflex' },
    { id: 'pattern', title: 'Pattern Memo', icon: <Icons.Brain />, color: 'from-indigo-500 to-purple-800', desc: 'Repeat the light sequence' },
    { id: 'whack', title: 'Whack-A-Target', icon: <Icons.Target />, color: 'from-red-500 to-rose-700', desc: 'Ultimate precision hit' },
  ];

  return (
    <Layout title="Premium Game Zone" onBack={activeGame ? () => setActiveGame(null) : onBack} className="bg-gray-50">
      {activeGame === null ? (
        <div className="p-4 space-y-4">
          <div className="bg-white p-4 rounded-2xl shadow-sm mb-2 border border-brand-100 animate-fade-in">
            <h2 className="text-xl font-black text-brand-600 uppercase tracking-tight">Level Up!</h2>
            <p className="text-xs text-gray-500">Pick a game to start your streak.</p>
          </div>
          <div className="grid grid-cols-2 gap-4 pb-10">
            {games.map((g, idx) => (
              <button 
                key={g.id} 
                onClick={() => setActiveGame(g.id)} 
                className={`bg-gradient-to-br ${g.color} h-40 rounded-3xl shadow-lg text-white p-4 flex flex-col justify-between hover:scale-105 transition transform active:scale-95 text-left relative overflow-hidden group animate-slide-up`}
                style={{ animationDelay: `${idx * 0.05}s` }}
              >
                <div className="absolute -right-4 -top-4 opacity-10 group-hover:scale-150 transition-transform duration-500">
                   {React.cloneElement(g.icon as React.ReactElement<any>, { size: 100 })}
                </div>
                <div className="bg-white/20 p-2 rounded-xl w-fit backdrop-blur-md">
                   {g.icon}
                </div>
                <div>
                  <h3 className="font-black text-lg uppercase leading-tight">{g.title}</h3>
                  <p className="text-[10px] opacity-80 font-bold uppercase tracking-wider">{g.desc}</p>
                </div>
              </button>
            ))}
          </div>
          <div className="pt-8 text-center">
             <p className="text-[10px] text-gray-400 font-bold uppercase tracking-[0.3em]">Digital NextGen Entertainment</p>
          </div>
        </div>
      ) : (
        <div className="p-4 h-full flex flex-col items-center justify-center animate-fade-in">
          {activeGame === 'tictactoe' && <TicTacToe />}
          {activeGame === 'clicker' && <ClickerGame />}
          {activeGame === 'math' && <MathQuiz />}
          {activeGame === 'memory' && <MemoryGame />}
          {activeGame === 'coin' && <CoinFlip />}
          {activeGame === 'guessing' && <NumberGuessing />}
          {activeGame === 'reaction' && <ReactionTest />}
          {activeGame === 'dice' && <DiceRoller />}
          {activeGame === 'snake' && <SnakeGame />}
          {activeGame === 'colormaster' && <ColorMaster />}
          {activeGame === 'pattern' && <PatternMemo />}
          {activeGame === 'whack' && <WhackATarget />}
        </div>
      )}
    </Layout>
  );
};

// --- Micro Games (Existing) ---

const TicTacToe = () => {
  const [board, setBoard] = useState(Array(9).fill(null));
  const [xIsNext, setXIsNext] = useState(true);
  const winner = calculateWinner(board);

  const handleClick = (i: number) => {
    if (winner || board[i]) return;
    const newBoard = [...board];
    newBoard[i] = xIsNext ? 'X' : 'O';
    setBoard(newBoard);
    setXIsNext(!xIsNext);
  };

  return (
    <div className="text-center w-full max-w-xs">
      <div className={`mb-6 p-4 rounded-2xl ${winner ? 'bg-green-100 text-green-700' : 'bg-brand-50 text-brand-700'} font-black uppercase tracking-widest`}>
        {winner ? `WINNER: ${winner} 🎉` : board.every(s => s) ? "Drawn Match 🤝" : `TURN: ${xIsNext ? 'X' : 'O'}`}
      </div>
      <div className="grid grid-cols-3 gap-3 bg-white p-4 rounded-3xl shadow-xl border border-gray-100">
        {board.map((sq, i) => (
          <button 
            key={i} 
            onClick={() => handleClick(i)} 
            className={`w-full aspect-square bg-gray-50 text-4xl font-black rounded-2xl flex items-center justify-center transition-all active:scale-90 ${sq === 'X' ? 'text-blue-600' : 'text-pink-600'}`}
          >
            {sq}
          </button>
        ))}
      </div>
      <Button className="mt-8 uppercase font-black tracking-widest" onClick={() => setBoard(Array(9).fill(null))}>Restart Game</Button>
    </div>
  );
};

const ClickerGame = () => {
  const [score, setScore] = useState(0);
  const [timeLeft, setTimeLeft] = useState(10);
  const [isPlaying, setIsPlaying] = useState(false);
  const [bestScore, setBestScore] = useState(0);

  useEffect(() => {
    if (isPlaying && timeLeft > 0) {
      const timer = setTimeout(() => setTimeLeft(timeLeft - 1), 1000);
      return () => clearTimeout(timer);
    } else if (timeLeft === 0) {
      setIsPlaying(false);
      if (score > bestScore) setBestScore(score);
    }
  }, [isPlaying, timeLeft, score, bestScore]);

  const startGame = () => {
    setScore(0);
    setTimeLeft(10);
    setIsPlaying(true);
  };

  return (
    <div className="text-center w-full space-y-6">
      <div className="flex justify-between items-center bg-white p-4 rounded-2xl shadow-sm">
        <div className="text-left">
           <p className="text-[10px] text-gray-400 font-bold uppercase">Time Remaining</p>
           <p className="text-2xl font-black text-brand-600">{timeLeft}s</p>
        </div>
        <div className="text-right">
           <p className="text-[10px] text-gray-400 font-bold uppercase">Best Score</p>
           <p className="text-2xl font-black text-gray-800">{bestScore}</p>
        </div>
      </div>
      
      <div className="py-10">
        <div className="text-6xl font-black text-gray-800 mb-2">{score}</div>
        <p className="text-xs text-gray-400 font-bold uppercase tracking-widest">Total Taps</p>
      </div>

      {isPlaying ? (
        <button 
          onClick={() => setScore(score + 1)} 
          className="w-48 h-48 bg-gradient-to-br from-brand-500 to-indigo-600 rounded-full text-white font-black text-3xl shadow-2xl active:scale-90 transition-transform mx-auto flex items-center justify-center border-8 border-white/20"
        >
          TAP!
        </button>
      ) : (
        <div className="space-y-4">
           {timeLeft === 0 && <p className="text-brand-600 font-bold">Game Over! Final CPS: {(score/10).toFixed(1)}</p>}
           <Button className="font-black uppercase tracking-widest py-4" onClick={startGame}>Start Test</Button>
        </div>
      )}
    </div>
  );
};

const MathQuiz = () => {
  const [q, setQ] = useState({ a: 0, b: 0, op: '+' });
  const [input, setInput] = useState('');
  const [msg, setMsg] = useState('');
  const [streak, setStreak] = useState(0);

  const generate = () => {
    setQ({
      a: Math.floor(Math.random() * 50),
      b: Math.floor(Math.random() * 50),
      op: Math.random() > 0.5 ? '+' : '-'
    });
    setInput('');
    setMsg('');
  };
  
  useEffect(generate, []);

  const check = () => {
    const res = q.op === '+' ? q.a + q.b : q.a - q.b;
    if (parseInt(input) === res) {
      setMsg('EXCELLENT! 🎉');
      setStreak(streak + 1);
      setTimeout(generate, 800);
    } else {
      setMsg('TRY AGAIN!');
      setStreak(0);
    }
  };

  return (
    <div className="text-center w-full space-y-8 max-w-xs">
      <div className="bg-brand-600 text-white p-4 rounded-2xl flex justify-between items-center shadow-lg">
         <span className="text-[10px] font-bold uppercase">Mathematics IQ</span>
         <span className="text-xs font-black">STREAK: {streak}</span>
      </div>
      <div className="py-12 bg-white rounded-3xl shadow-xl border border-gray-100">
        <div className="text-5xl font-black text-gray-800 tracking-tight">{q.a} {q.op} {q.b}</div>
        <div className="text-xl font-bold text-brand-600 mt-2">= ?</div>
      </div>
      <div className="space-y-4">
        <Input 
          type="number" 
          value={input} 
          onChange={e => setInput(e.target.value)} 
          placeholder="Answer" 
          className="text-center text-2xl font-black py-4"
          autoFocus
        />
        <Button onClick={check} className="font-black uppercase tracking-widest py-4">Verify Result</Button>
      </div>
      <p className={`h-6 font-black uppercase text-sm ${msg.includes('EXCELLENT') ? 'text-green-500' : 'text-red-500'}`}>{msg}</p>
    </div>
  );
};

const MemoryGame = () => {
  const icons = ['🔥', '💎', '🚀', '🌈', '🍕', '🎮', '💡', '🌟'];
  const [cards, setCards] = useState<any[]>([]);
  const [flipped, setFlipped] = useState<number[]>([]);
  const [matched, setMatched] = useState<number[]>([]);
  const [moves, setMoves] = useState(0);

  const init = () => {
    const deck = [...icons, ...icons]
      .sort(() => Math.random() - 0.5)
      .map((icon, idx) => ({ id: idx, icon }));
    setCards(deck);
    setFlipped([]);
    setMatched([]);
    setMoves(0);
  };

  useEffect(init, []);

  const flip = (idx: number) => {
    if (flipped.length === 2 || flipped.includes(idx) || matched.includes(idx)) return;
    const newFlipped = [...flipped, idx];
    setFlipped(newFlipped);

    if (newFlipped.length === 2) {
      setMoves(moves + 1);
      if (cards[newFlipped[0]].icon === cards[newFlipped[1]].icon) {
        setMatched([...matched, ...newFlipped]);
        setFlipped([]);
      } else {
        setTimeout(() => setFlipped([]), 1000);
      }
    }
  };

  return (
    <div className="text-center w-full space-y-6">
      <div className="flex justify-between items-center bg-white p-4 rounded-2xl shadow-sm">
        <span className="text-xs font-black uppercase text-gray-400">Moves: {moves}</span>
        <span className="text-xs font-black uppercase text-brand-600">{matched.length/2} / {icons.length} Pairs</span>
      </div>
      <div className="grid grid-cols-4 gap-2">
        {cards.map((c, i) => (
          <button 
            key={i} 
            onClick={() => flip(i)}
            className={`aspect-square rounded-xl text-2xl flex items-center justify-center transition-all transform duration-300 ${flipped.includes(i) || matched.includes(i) ? 'bg-white rotate-0 shadow-md' : 'bg-brand-600 rotate-180 shadow-lg'}`}
          >
            {(flipped.includes(i) || matched.includes(i)) ? c.icon : ''}
          </button>
        ))}
      </div>
      <Button onClick={init} className="uppercase font-black tracking-widest mt-4">Reset Board</Button>
    </div>
  );
};

const CoinFlip = () => {
  const [res, setRes] = useState<string | null>(null);
  const [animating, setAnimating] = useState(false);

  const flip = () => {
    setAnimating(true);
    setRes(null);
    setTimeout(() => {
      setRes(Math.random() > 0.5 ? 'HEADS' : 'TAILS');
      setAnimating(false);
    }, 800);
  };

  return (
    <div className="text-center w-full space-y-10">
      <div className={`w-48 h-48 rounded-full border-8 border-yellow-500/20 shadow-2xl flex items-center justify-center bg-gradient-to-br from-yellow-300 to-orange-500 mx-auto relative transform transition-all duration-700 ${animating ? 'animate-bounce' : ''}`}>
        <div className={`w-40 h-40 rounded-full border-4 border-white/30 flex items-center justify-center text-4xl font-black text-white ${animating ? 'blur-sm' : ''}`}>
           {res || '?'}
        </div>
      </div>
      <div className="space-y-4">
        {res && <div className="text-xl font-black text-gray-800 uppercase tracking-widest animate-fade-in">It's {res}!</div>}
        <Button onClick={flip} disabled={animating} className="font-black uppercase tracking-widest py-4">FLIP NOW</Button>
      </div>
    </div>
  );
};

const NumberGuessing = () => {
  const [target, setTarget] = useState(0);
  const [guess, setGuess] = useState('');
  const [feedback, setFeedback] = useState('Guess a number between 1 and 100');
  const [attempts, setAttempts] = useState(0);
  const [gameOver, setGameOver] = useState(false);

  useEffect(() => {
    setTarget(Math.floor(Math.random() * 100) + 1);
  }, []);

  const handleGuess = () => {
    const val = parseInt(guess);
    if (isNaN(val)) return;
    setAttempts(attempts + 1);
    if (val === target) {
      setFeedback(`Correct! It was ${target} 🎉`);
      setGameOver(true);
    } else if (val < target) {
      setFeedback('Too Low! Try Higher ⬆️');
    } else {
      setFeedback('Too High! Try Lower ⬇️');
    }
    setGuess('');
  };

  const restart = () => {
    setTarget(Math.floor(Math.random() * 100) + 1);
    setAttempts(0);
    setFeedback('Guess a number between 1 and 100');
    setGameOver(false);
    setGuess('');
  };

  return (
    <div className="text-center w-full space-y-6 max-w-xs">
       <div className="bg-cyan-600 text-white p-6 rounded-3xl shadow-lg">
          <p className="text-[10px] font-black uppercase tracking-widest opacity-80 mb-2">Attempts: {attempts}</p>
          <h2 className="text-xl font-bold leading-tight uppercase">{feedback}</h2>
       </div>
       <div className="space-y-4">
          <Input 
            type="number" 
            value={guess} 
            onChange={e => setGuess(e.target.value)} 
            placeholder="Enter your prediction" 
            disabled={gameOver}
            className="text-center text-xl font-bold"
          />
          {gameOver ? (
            <Button onClick={restart} className="bg-green-600 hover:bg-green-700 font-black uppercase tracking-widest py-4">Play Again</Button>
          ) : (
            <Button onClick={handleGuess} className="font-black uppercase tracking-widest py-4">Submit Prediction</Button>
          )}
       </div>
    </div>
  );
};

const ReactionTest = () => {
  const [state, setState] = useState<'idle' | 'waiting' | 'ready' | 'result'>('idle');
  const [startTime, setStartTime] = useState(0);
  const [time, setTime] = useState(0);
  const timerRef = useRef<any>(null);

  const start = () => {
    setState('waiting');
    const delay = 1000 + Math.random() * 3000;
    timerRef.current = setTimeout(() => {
      setState('ready');
      setStartTime(Date.now());
    }, delay);
  };

  const handleClick = () => {
    if (state === 'waiting') {
      clearTimeout(timerRef.current);
      alert("Too early! Don't jump the gun.");
      setState('idle');
    } else if (state === 'ready') {
      const reactionTime = Date.now() - startTime;
      setTime(reactionTime);
      setState('result');
    }
  };

  return (
    <div className="w-full h-full flex flex-col items-center justify-center space-y-8">
       <div 
         onClick={state === 'idle' || state === 'result' ? start : handleClick}
         className={`w-full h-64 rounded-3xl flex flex-col items-center justify-center text-white cursor-pointer shadow-xl transition-colors duration-200 ${
           state === 'idle' ? 'bg-blue-600' :
           state === 'waiting' ? 'bg-red-500' :
           state === 'ready' ? 'bg-green-500' :
           'bg-indigo-600'
         }`}
       >
          <h2 className="text-2xl font-black uppercase text-center px-4">
             {state === 'idle' ? 'Tap to Start' :
              state === 'waiting' ? 'Wait for Green...' :
              state === 'ready' ? 'TAP NOW!' :
              `${time} ms`}
          </h2>
          {state === 'result' && <p className="mt-2 text-xs font-bold opacity-80 uppercase">Tap to restart</p>}
       </div>
       <div className="text-center">
          <p className="text-xs text-gray-400 font-bold uppercase tracking-widest">Test your reflex speed</p>
       </div>
    </div>
  );
};

const DiceRoller = () => {
  const [dice, setDice] = useState(1);
  const [rolling, setRolling] = useState(false);

  const roll = () => {
    setRolling(true);
    setTimeout(() => {
      setDice(Math.floor(Math.random() * 6) + 1);
      setRolling(false);
    }, 600);
  };

  return (
    <div className="text-center w-full space-y-12">
       <div className={`w-32 h-32 bg-white rounded-3xl border-4 border-slate-200 shadow-2xl mx-auto flex items-center justify-center transform transition-transform duration-500 ${rolling ? 'rotate-[360deg] scale-90' : 'rotate-0 scale-100'}`}>
          <div className="grid grid-cols-3 gap-2 p-4 w-full h-full">
             {dice === 1 && <div className="col-start-2 row-start-2 w-4 h-4 bg-slate-800 rounded-full"></div>}
             {dice === 2 && <>
               <div className="col-start-1 row-start-1 w-4 h-4 bg-slate-800 rounded-full"></div>
               <div className="col-start-3 row-start-3 w-4 h-4 bg-slate-800 rounded-full"></div>
             </>}
             {dice === 3 && <>
               <div className="col-start-1 row-start-1 w-4 h-4 bg-slate-800 rounded-full"></div>
               <div className="col-start-2 row-start-2 w-4 h-4 bg-slate-800 rounded-full"></div>
               <div className="col-start-3 row-start-3 w-4 h-4 bg-slate-800 rounded-full"></div>
             </>}
             {dice === 4 && <>
               <div className="col-start-1 row-start-1 w-4 h-4 bg-slate-800 rounded-full"></div>
               <div className="col-start-3 row-start-1 w-4 h-4 bg-slate-800 rounded-full"></div>
               <div className="col-start-1 row-start-3 w-4 h-4 bg-slate-800 rounded-full"></div>
               <div className="col-start-3 row-start-3 w-4 h-4 bg-slate-800 rounded-full"></div>
             </>}
             {dice === 5 && <>
               <div className="col-start-1 row-start-1 w-4 h-4 bg-slate-800 rounded-full"></div>
               <div className="col-start-3 row-start-1 w-4 h-4 bg-slate-800 rounded-full"></div>
               <div className="col-start-2 row-start-2 w-4 h-4 bg-slate-800 rounded-full"></div>
               <div className="col-start-1 row-start-3 w-4 h-4 bg-slate-800 rounded-full"></div>
               <div className="col-start-3 row-start-3 w-4 h-4 bg-slate-800 rounded-full"></div>
             </>}
             {dice === 6 && <>
               <div className="col-start-1 row-start-1 w-4 h-4 bg-slate-800 rounded-full"></div>
               <div className="col-start-1 row-start-2 w-4 h-4 bg-slate-800 rounded-full"></div>
               <div className="col-start-1 row-start-3 w-4 h-4 bg-slate-800 rounded-full"></div>
               <div className="col-start-3 row-start-1 w-4 h-4 bg-slate-800 rounded-full"></div>
               <div className="col-start-3 row-start-2 w-4 h-4 bg-slate-800 rounded-full"></div>
               <div className="col-start-3 row-start-3 w-4 h-4 bg-slate-800 rounded-full"></div>
             </>}
          </div>
       </div>
       <div className="space-y-4">
          <p className="text-2xl font-black text-slate-700 uppercase tracking-widest">Result: {rolling ? '...' : dice}</p>
          <Button onClick={roll} disabled={rolling} className="bg-slate-700 hover:bg-slate-800 font-black uppercase tracking-widest py-4">Roll the Dice</Button>
       </div>
    </div>
  );
};

// --- NEW CREATIVE GAMES IMPLEMENTATION ---

const SnakeGame = () => {
  const GRID_SIZE = 12;
  const [snake, setSnake] = useState([{ x: 6, y: 6 }]);
  const [food, setFood] = useState({ x: 3, y: 3 });
  const [dir, setDir] = useState({ x: 0, y: -1 });
  const [score, setScore] = useState(0);
  const [gameOver, setGameOver] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  
  const timerRef = useRef<any>(null);

  const moveSnake = () => {
    const head = { x: snake[0].x + dir.x, y: snake[0].y + dir.y };
    
    // Check collisions
    if (head.x < 0 || head.x >= GRID_SIZE || head.y < 0 || head.y >= GRID_SIZE || snake.some(s => s.x === head.x && s.y === head.y)) {
      setGameOver(true);
      setIsPlaying(false);
      return;
    }

    const newSnake = [head, ...snake];
    if (head.x === food.x && head.y === food.y) {
      setScore(score + 10);
      setFood({
        x: Math.floor(Math.random() * GRID_SIZE),
        y: Math.floor(Math.random() * GRID_SIZE)
      });
    } else {
      newSnake.pop();
    }
    setSnake(newSnake);
  };

  useEffect(() => {
    if (isPlaying) {
      timerRef.current = setInterval(moveSnake, 250);
    } else {
      clearInterval(timerRef.current);
    }
    return () => clearInterval(timerRef.current);
  }, [isPlaying, snake, dir]);

  const reset = () => {
    setSnake([{ x: 6, y: 6 }]);
    setDir({ x: 0, y: -1 });
    setScore(0);
    setGameOver(false);
    setIsPlaying(true);
  };

  return (
    <div className="w-full max-w-xs space-y-6">
      <div className="bg-emerald-600 p-4 rounded-2xl flex justify-between text-white font-black uppercase text-xs shadow-lg">
        <span>Snake Quest</span>
        <span>Score: {score}</span>
      </div>
      
      <div className="grid grid-cols-12 gap-1 bg-white p-3 rounded-2xl shadow-xl border border-emerald-100 aspect-square">
        {Array.from({ length: GRID_SIZE * GRID_SIZE }).map((_, i) => {
          const x = i % GRID_SIZE;
          const y = Math.floor(i / GRID_SIZE);
          const isSnake = snake.some(s => s.x === x && s.y === y);
          const isFood = food.x === x && food.y === y;
          return (
            <div 
              key={i} 
              className={`rounded-sm transition-colors ${
                isSnake ? 'bg-emerald-500 scale-105 shadow-sm' : 
                isFood ? 'bg-red-500 animate-pulse' : 
                'bg-gray-50'
              }`}
            />
          );
        })}
      </div>

      <div className="grid grid-cols-3 gap-2 max-w-[150px] mx-auto">
        <div />
        <button onClick={() => dir.y === 0 && setDir({ x: 0, y: -1 })} className="bg-gray-200 p-4 rounded-xl active:bg-emerald-500 active:text-white transition shadow-sm"><Icons.Plus size={20} /></button>
        <div />
        <button onClick={() => dir.x === 0 && setDir({ x: -1, y: 0 })} className="bg-gray-200 p-4 rounded-xl active:bg-emerald-500 active:text-white transition shadow-sm"><Icons.ArrowLeft size={20} /></button>
        <button onClick={() => dir.y === 0 && setDir({ x: 0, y: 1 })} className="bg-gray-200 p-4 rounded-xl active:bg-emerald-500 active:text-white transition shadow-sm rotate-180"><Icons.Plus size={20} /></button>
        <button onClick={() => dir.x === 0 && setDir({ x: 1, y: 0 })} className="bg-gray-200 p-4 rounded-xl active:bg-emerald-500 active:text-white transition shadow-sm rotate-180"><Icons.ArrowLeft size={20} /></button>
      </div>

      {!isPlaying && (
        <Button onClick={reset} className="font-black uppercase tracking-widest mt-4">
          {gameOver ? 'Game Over - Restart' : 'Start Slithering'}
        </Button>
      )}
    </div>
  );
};

const ColorMaster = () => {
  const COLORS = [
    { name: 'Red', hex: '#ef4444' },
    { name: 'Blue', hex: '#3b82f6' },
    { name: 'Green', hex: '#22c55e' },
    { name: 'Yellow', hex: '#eab308' },
    { name: 'Pink', hex: '#ec4899' },
    { name: 'Black', hex: '#000000' }
  ];

  const [score, setScore] = useState(0);
  const [timeLeft, setTimeLeft] = useState(15);
  const [isPlaying, setIsPlaying] = useState(false);
  const [current, setCurrent] = useState({ textIdx: 0, colorIdx: 0 });
  const [gameOver, setGameOver] = useState(false);

  const generate = () => {
    setCurrent({
      textIdx: Math.floor(Math.random() * COLORS.length),
      colorIdx: Math.floor(Math.random() * COLORS.length)
    });
  };

  useEffect(() => {
    if (isPlaying && timeLeft > 0) {
      const timer = setTimeout(() => setTimeLeft(timeLeft - 1), 1000);
      return () => clearTimeout(timer);
    } else if (timeLeft === 0) {
      setIsPlaying(false);
      setGameOver(true);
    }
  }, [isPlaying, timeLeft]);

  const handleChoice = (isMatch: boolean) => {
    const actualMatch = current.textIdx === current.colorIdx;
    if (isMatch === actualMatch) {
      setScore(score + 1);
      generate();
    } else {
      setTimeLeft(Math.max(0, timeLeft - 2)); // Penalty
      generate();
    }
  };

  const start = () => {
    setScore(0);
    setTimeLeft(15);
    setGameOver(false);
    setIsPlaying(true);
    generate();
  };

  return (
    <div className="w-full max-w-xs text-center space-y-10">
      <div className="flex justify-between items-center bg-amber-50 p-4 rounded-2xl border border-amber-200">
         <span className="text-xs font-black text-amber-700 uppercase">Score: {score}</span>
         <span className="text-xs font-black text-red-600 uppercase">Time: {timeLeft}s</span>
      </div>

      <div className="py-12 bg-white rounded-3xl shadow-xl border border-gray-100 min-h-[150px] flex items-center justify-center">
        {isPlaying ? (
          <h2 
            className="text-6xl font-black uppercase tracking-tighter"
            style={{ color: COLORS[current.colorIdx].hex }}
          >
            {COLORS[current.textIdx].name}
          </h2>
        ) : (
          <p className="text-gray-400 font-bold italic">{gameOver ? 'Time Out!' : 'Match Text with Ink Color'}</p>
        )}
      </div>

      {isPlaying ? (
        <div className="grid grid-cols-2 gap-4">
           <button onClick={() => handleChoice(true)} className="bg-green-500 text-white py-6 rounded-2xl font-black text-lg active:scale-95 shadow-lg">MATCH</button>
           <button onClick={() => handleChoice(false)} className="bg-red-500 text-white py-6 rounded-2xl font-black text-lg active:scale-95 shadow-lg">NO MATCH</button>
        </div>
      ) : (
        <Button onClick={start} className="bg-amber-600 hover:bg-amber-700 font-black uppercase tracking-widest py-4">
           {gameOver ? 'Try Again' : 'Enter Arena'}
        </Button>
      )}
    </div>
  );
};

const PatternMemo = () => {
  const [pattern, setPattern] = useState<number[]>([]);
  const [userInput, setUserInput] = useState<number[]>([]);
  const [isShowing, setIsShowing] = useState(false);
  const [activeBtn, setActiveBtn] = useState<number | null>(null);
  const [level, setLevel] = useState(0);

  const startLevel = () => {
    const nextPattern = [...pattern, Math.floor(Math.random() * 4)];
    setPattern(nextPattern);
    setUserInput([]);
    showPattern(nextPattern);
    setLevel(nextPattern.length);
  };

  const showPattern = async (p: number[]) => {
    setIsShowing(true);
    for (let i = 0; i < p.length; i++) {
      await new Promise(r => setTimeout(r, 400));
      setActiveBtn(p[i]);
      await new Promise(r => setTimeout(r, 400));
      setActiveBtn(null);
    }
    setIsShowing(false);
  };

  const handlePress = (idx: number) => {
    if (isShowing || pattern.length === 0) return;
    const newUserInput = [...userInput, idx];
    setUserInput(newUserInput);

    if (idx !== pattern[newUserInput.length - 1]) {
      alert("Wrong Pattern! Resetting...");
      setPattern([]);
      setLevel(0);
      return;
    }

    if (newUserInput.length === pattern.length) {
      setTimeout(startLevel, 800);
    }
  };

  return (
    <div className="w-full max-w-xs space-y-10 text-center">
      <div className="bg-indigo-600 text-white p-5 rounded-2xl shadow-xl flex justify-between items-center">
         <span className="font-black uppercase text-[10px] tracking-widest">Memory Level</span>
         <span className="text-xl font-black">{level}</span>
      </div>

      <div className="grid grid-cols-2 gap-4 aspect-square bg-white p-4 rounded-[40px] shadow-2xl border border-indigo-100">
         {[0,1,2,3].map(i => {
           const colors = ['bg-red-400', 'bg-blue-400', 'bg-yellow-400', 'bg-green-400'];
           const activeColors = ['bg-red-600 shadow-red-200', 'bg-blue-600 shadow-blue-200', 'bg-yellow-600 shadow-yellow-200', 'bg-green-600 shadow-green-200'];
           return (
             <button 
               key={i} 
               onClick={() => handlePress(i)}
               disabled={isShowing}
               className={`w-full h-full rounded-3xl transition-all duration-150 transform active:scale-90 ${activeBtn === i ? `${activeColors[i]} scale-105 shadow-xl` : `${colors[i]} opacity-40`}`}
             />
           );
         })}
      </div>

      {pattern.length === 0 && (
        <Button onClick={startLevel} className="bg-indigo-600 font-black uppercase tracking-widest py-4">Start Sequence</Button>
      )}
      <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest">{isShowing ? 'Watch Carefully...' : 'Repeat the Lights!'}</p>
    </div>
  );
};

const WhackATarget = () => {
  const [score, setScore] = useState(0);
  const [activeHole, setActiveHole] = useState<number | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [timeLeft, setTimeLeft] = useState(20);

  const timerRef = useRef<any>(null);

  const start = () => {
    setScore(0);
    setTimeLeft(20);
    setIsPlaying(true);
    randomPop();
  };

  const randomPop = () => {
    setActiveHole(Math.floor(Math.random() * 9));
    const speed = Math.max(400, 1000 - (score * 10));
    timerRef.current = setTimeout(randomPop, speed);
  };

  useEffect(() => {
    if (isPlaying && timeLeft > 0) {
      const clock = setTimeout(() => setTimeLeft(timeLeft - 1), 1000);
      return () => clearTimeout(clock);
    } else if (timeLeft === 0) {
      setIsPlaying(false);
      clearTimeout(timerRef.current);
      setActiveHole(null);
    }
  }, [isPlaying, timeLeft]);

  const hit = (idx: number) => {
    if (idx === activeHole) {
      setScore(score + 1);
      setActiveHole(null);
    }
  };

  return (
    <div className="w-full max-w-xs space-y-6 text-center">
       <div className="flex justify-between items-center bg-rose-50 p-4 rounded-2xl border border-rose-200 font-black">
          <span className="text-rose-600 uppercase text-xs">Hits: {score}</span>
          <span className="text-gray-600 uppercase text-xs">Left: {timeLeft}s</span>
       </div>

       <div className="grid grid-cols-3 gap-3 bg-gray-200 p-4 rounded-3xl shadow-inner aspect-square">
          {Array.from({ length: 9 }).map((_, i) => (
            <div key={i} className="relative aspect-square bg-gray-300 rounded-full border-4 border-gray-400 shadow-inner overflow-hidden">
               <button 
                 onClick={() => hit(i)}
                 className={`absolute inset-0 transition-transform duration-100 transform ${activeHole === i ? 'translate-y-0' : 'translate-y-full'}`}
               >
                  <div className="w-full h-full bg-gradient-to-t from-rose-700 to-rose-400 flex items-center justify-center text-3xl">
                     🎯
                  </div>
               </button>
            </div>
          ))}
       </div>

       {!isPlaying && (
         <Button onClick={start} className="bg-rose-600 font-black uppercase tracking-widest py-4 shadow-xl">
            {timeLeft === 0 ? 'Restart Mission' : 'Begin Blitz'}
         </Button>
       )}
    </div>
  );
};

function calculateWinner(squares: any[]) {
  const lines = [[0, 1, 2],[3, 4, 5],[6, 7, 8],[0, 3, 6],[1, 4, 7],[2, 5, 8],[0, 4, 8],[2, 4, 6]];
  for (let i = 0; i < lines.length; i++) {
    const [a, b, c] = lines[i];
    if (squares[a] && squares[a] === squares[b] && squares[a] === squares[c]) {
      return squares[a];
    }
  }
  return null;
}
