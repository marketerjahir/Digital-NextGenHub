
import React, { useState, useEffect } from 'react';
import { Layout } from '../components/Layout';
import { Icons } from '../constants';

export const PrayerTimes: React.FC<{ onBack: () => void }> = ({ onBack }) => {
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  // Simplified prayer time calculation for Dhaka, Bangladesh (approximate)
  // In a production app, a full library like adhan.js would be used.
  // Here we use realistic base offsets that shift slightly based on day of year.
  const calculatePrayerTimes = (date: Date) => {
    const dayOfYear = Math.floor((date.getTime() - new Date(date.getFullYear(), 0, 0).getTime()) / 1000 / 60 / 60 / 24);
    
    // Seasonal shift simulation (sinusoidal)
    const shift = 15 * Math.sin((2 * Math.PI * (dayOfYear - 80)) / 365);
    
    const baseTimes = {
      Fajr: { h: 4, m: 45 },
      Dhuhr: { h: 12, m: 10 },
      Asr: { h: 15, m: 35 },
      Maghrib: { h: 18, m: 15 },
      Isha: { h: 19, m: 35 }
    };

    return Object.entries(baseTimes).map(([name, time]) => {
      let totalMinutes = time.h * 60 + time.m + Math.round(shift);
      
      // Maghrib/Isha shift slightly differently in summer/winter
      if (name === 'Maghrib' || name === 'Isha') totalMinutes += Math.round(shift * 1.5);
      if (name === 'Fajr') totalMinutes -= Math.round(shift * 1.2);

      const h = Math.floor(totalMinutes / 60);
      const m = totalMinutes % 60;
      
      const timeDate = new Date(date);
      timeDate.setHours(h, m, 0);
      
      return {
        name,
        time: timeDate.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', hour12: true }),
        raw: timeDate,
        bengali: getBengaliName(name)
      };
    });
  };

  const getBengaliName = (name: string) => {
    const names: Record<string, string> = {
      Fajr: 'ফজর',
      Dhuhr: 'যোহর',
      Asr: 'আসর',
      Maghrib: 'মাগরিব',
      Isha: 'এশা'
    };
    return names[name];
  };

  const prayerTimes = calculatePrayerTimes(currentTime);
  
  const nextPrayer = prayerTimes.find(p => p.raw > currentTime) || prayerTimes[0];

  const bengaliDate = currentTime.toLocaleDateString('bn-BD', {
    day: 'numeric',
    month: 'long',
    year: 'numeric'
  });

  const englishDate = currentTime.toLocaleDateString('en-US', {
    day: 'numeric',
    month: 'long',
    year: 'numeric'
  });

  return (
    <Layout title="নামাজের সময়সূচী" onBack={onBack} className="bg-gray-50">
      <div className="p-4 space-y-6">
        {/* Top Header Card */}
        <div className="bg-gradient-to-br from-brand-600 to-brand-800 rounded-3xl p-6 text-white shadow-xl relative overflow-hidden animate-fade-in">
          <div className="absolute -right-8 -top-8 opacity-10">
            <Icons.Sun size={120} />
          </div>
          <p className="text-[10px] font-black uppercase tracking-[0.2em] opacity-80 mb-1">Today's Schedule</p>
          <h2 className="text-xl font-bold mb-0.5">{bengaliDate}</h2>
          <p className="text-xs opacity-70 font-medium">{englishDate}</p>
          
          <div className="mt-6 flex items-center gap-3 bg-white/10 p-3 rounded-2xl border border-white/10">
             <div className="bg-white/20 p-2 rounded-xl">
                <Icons.Clock size={20} />
             </div>
             <div>
                <p className="text-[9px] font-bold uppercase tracking-widest opacity-60">Upcoming Prayer</p>
                <p className="text-sm font-black">{nextPrayer.bengali} • {nextPrayer.time}</p>
             </div>
          </div>
        </div>

        {/* Prayer List */}
        <div className="space-y-3">
          {prayerTimes.map((p, idx) => {
            const isNext = p.name === nextPrayer.name;
            return (
              <div 
                key={p.name}
                style={{ animationDelay: `${idx * 0.1}s` }}
                className={`flex items-center justify-between p-5 rounded-3xl transition-all duration-300 animate-slide-up ${
                  isNext 
                  ? 'bg-white shadow-lg border-2 border-brand-500 scale-[1.02]' 
                  : 'bg-white/60 border border-gray-100'
                }`}
              >
                <div className="flex items-center gap-4">
                  <div className={`p-3 rounded-2xl ${isNext ? 'bg-brand-100 text-brand-600' : 'bg-gray-100 text-gray-400'}`}>
                    {p.name === 'Fajr' && <Icons.Sun size={20} />}
                    {p.name === 'Dhuhr' && <Icons.Sun size={20} />}
                    {p.name === 'Asr' && <Icons.Sun size={20} />}
                    {p.name === 'Maghrib' && <Icons.Clock size={20} />}
                    {p.name === 'Isha' && <Icons.Lock size={20} />}
                  </div>
                  <div>
                    <h3 className={`text-lg font-black ${isNext ? 'text-brand-700' : 'text-gray-800'}`}>{p.bengali}</h3>
                    <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest">{p.name}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className={`text-xl font-black ${isNext ? 'text-brand-600' : 'text-gray-700'}`}>{p.time}</p>
                  {isNext && <span className="text-[9px] bg-brand-600 text-white px-2 py-0.5 rounded-full font-bold uppercase">Next</span>}
                </div>
              </div>
            );
          })}
        </div>

        <div className="pt-4 text-center">
          <p className="text-[10px] text-gray-400 font-bold uppercase tracking-[0.3em]">Location: Dhaka, Bangladesh</p>
          <p className="text-[8px] text-gray-300 mt-2 italic">Prayer times are calculated dynamically based on regional solar cycles.</p>
        </div>
      </div>
    </Layout>
  );
};
