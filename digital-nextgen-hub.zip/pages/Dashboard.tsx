
import React, { useState, useEffect, useRef } from 'react';
import { Layout, Button, Input } from '../components/Layout';
import { TransactionType, Transaction, User } from '../types';
import { StorageService } from '../services/storage';
import { Icons } from '../constants';

interface DashboardProps {
  user: User;
  onBack: () => void;
}

export const Dashboard: React.FC<DashboardProps> = ({ user, onBack }) => {
  const [txType, setTxType] = useState<TransactionType>(TransactionType.CASH_IN);
  const [mobile, setMobile] = useState(user.mobile);
  const [name, setName] = useState('');
  const [amount, setAmount] = useState('');
  const [charge, setCharge] = useState('');
  const [note, setNote] = useState('');
  const [savedTx, setSavedTx] = useState<Transaction | null>(null);
  const [successMsg, setSuccessMsg] = useState('');
  
  // Mobile suggestions
  const [recentNumbers, setRecentNumbers] = useState<string[]>([]);

  // Auto-set Date/Time
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    // Load recent numbers
    setRecentNumbers(StorageService.getRecentNumbers());
    return () => clearInterval(timer);
  }, []);

  // Use local date for consistency across the app
  const getLocalDateStr = () => {
    const now = new Date();
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const day = String(now.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  };

  const handleSave = () => {
    if (!mobile || !name || !amount || !charge || !note) {
      alert("Please fill all fields!");
      return;
    }

    if (mobile.length !== 11) {
      alert("Mobile number must be 11 digits");
      return;
    }

    const newTx: Transaction = {
      id: "TRX" + Date.now().toString(),
      userId: user.id,
      type: txType,
      mobileNumber: mobile,
      customerName: name,
      amount: parseFloat(amount),
      charge: parseFloat(charge),
      note: note,
      timestamp: new Date().toISOString(),
      dateStr: getLocalDateStr()
    };

    StorageService.saveTransaction(newTx);
    StorageService.saveRecentNumber(mobile);
    setRecentNumbers(StorageService.getRecentNumbers());

    setSavedTx(newTx);
    setSuccessMsg('Saved Successfully!');
    
    // Clear form
    setName('');
    setAmount('');
    setCharge('');
    setNote('');
  };

  const handleDownloadPDF = async () => {
    const element = document.getElementById('receipt-visual');
    if (element && (window as any).html2canvas && (window as any).jspdf) {
        try {
            const canvas = await (window as any).html2canvas(element, { 
                useCORS: true, 
                scale: 2,
                backgroundColor: null, 
            });
            const imgData = canvas.toDataURL('image/png');
            
            const { jsPDF } = (window as any).jspdf;
            const pdf = new jsPDF('p', 'mm', 'a4');
            const pdfWidth = pdf.internal.pageSize.getWidth();
            
            // Calculate height to maintain aspect ratio
            const imgProps = pdf.getImageProperties(imgData);
            const imgWidth = pdfWidth - 40; // 20mm margin on each side
            const imgHeight = (imgProps.height * imgWidth) / imgProps.width;
            
            // Add image to PDF centered horizontally
            pdf.addImage(imgData, 'PNG', 20, 20, imgWidth, imgHeight);
            pdf.save(`Receipt_${savedTx?.id}.pdf`);
        } catch (error) {
            console.error("PDF generation failed", error);
            alert("Could not generate PDF.");
        }
    } else {
        alert("PDF library not loaded. Please refresh the page.");
    }
  };

  const handleDownloadImage = async () => {
    const element = document.getElementById('receipt-visual');
    if (element && (window as any).html2canvas) {
        try {
            const canvas = await (window as any).html2canvas(element, { 
                useCORS: true, 
                scale: 2,
                backgroundColor: null, // Transparent bg if needed, or white default
            });
            const data = canvas.toDataURL('image/png');
            const link = document.createElement('a');
            link.href = data;
            link.download = `Receipt_${savedTx?.id}.png`;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        } catch (error) {
            console.error("Image generation failed", error);
            alert("Could not generate image. Please try PDF download.");
        }
    } else {
        alert("Image generation library not loaded. Please refresh.");
    }
  };

  if (savedTx) {
    const txDate = new Date(savedTx.timestamp);
    const dateStr = savedTx.dateStr; // Use local date stored in tx
    const timeStr = txDate.toLocaleTimeString('en-US', { hour12: true });

    return (
      <Layout title="Transaction Receipt" onBack={() => { setSavedTx(null); setSuccessMsg(''); }}>
        <div className="p-4 flex flex-col items-center animate-fade-in" id="receipt-area">
          
          {/* Actual Receipt Visual - This part gets captured */}
          <div id="receipt-visual" className="w-full max-w-[360px] mx-auto bg-white overflow-hidden shadow-2xl rounded-none font-sans relative">
            
            {/* Header */}
            <div className="bg-pink-600 h-40 relative flex flex-col items-center justify-center text-white pb-6">
               {/* Background Curves (Simple CSS substitute) */}
               <div className="absolute top-0 left-0 w-24 h-24 bg-white/10 rounded-full -translate-x-1/2 -translate-y-1/2"></div>
               <div className="absolute bottom-0 right-0 w-32 h-32 bg-white/10 rounded-full translate-x-1/3 translate-y-1/3"></div>

               {/* Icon */}
               <div className="mb-2">
                 <div className="border-2 border-white/40 rounded-full p-1">
                   <div className="bg-transparent rounded-full">
                     <Icons.SuccessCheck />
                   </div>
                 </div>
               </div>

               <h2 className="text-xl font-bold tracking-wide">TRX Successful (Official Receipt)</h2>
               <p className="text-sm font-medium opacity-90">Digital NextGen Hub</p>
            </div>

            {/* Body */}
            <div className="px-8 py-6 bg-white relative -mt-4 rounded-t-3xl">
              
              {/* Type & Amount */}
              <div className="text-center mb-6">
                <h3 className="text-gray-500 font-bold uppercase tracking-wider text-sm mb-1">{savedTx.type.toUpperCase()}</h3>
                <div className="text-pink-600 text-5xl font-bold font-sans">
                  <span className="text-3xl font-bold mr-1">৳</span>{savedTx.amount + savedTx.charge}
                </div>
              </div>

              {/* Dashed Separator */}
              <div className="border-b-2 border-dashed border-gray-200 mb-6"></div>

              {/* Details List */}
              <div className="space-y-4 text-sm">
                
                <div className="flex justify-between items-start">
                  <span className="text-gray-500 font-medium">Date and Time</span>
                  <div className="text-right">
                    <div className="font-bold text-gray-800">{timeStr}</div>
                    <div className="text-xs text-gray-400">{dateStr}</div>
                  </div>
                </div>

                <div className="flex justify-between items-center">
                  <span className="text-gray-500 font-medium">Trx ID</span>
                  <span className="bg-gray-100 text-gray-700 px-2 py-1 rounded text-xs font-mono">{savedTx.id}</span>
                </div>

                <div className="flex justify-between items-center">
                  <span className="text-gray-500 font-medium">Sent To</span>
                  <span className="font-bold text-gray-900">{savedTx.mobileNumber}</span>
                </div>

                <div className="flex justify-between items-center">
                  <span className="text-gray-500 font-medium">Recipient</span>
                  <span className="font-bold text-gray-900">{savedTx.customerName}</span>
                </div>

                <div className="flex justify-between items-center">
                  <span className="text-gray-500 font-medium">Amount</span>
                  <span className="font-bold text-gray-900">৳ {savedTx.amount}</span>
                </div>

                <div className="flex justify-between items-center">
                  <span className="text-gray-500 font-medium">Charge</span>
                  <span className="font-bold text-gray-900">৳ {savedTx.charge}</span>
                </div>

                <div className="flex justify-between items-center">
                  <span className="text-gray-500 font-medium">Note</span>
                  <span className="font-bold text-gray-900">{savedTx.note}</span>
                </div>

              </div>

              {/* Signature Section Updated: Removed Name and Line */}
              <div className="mt-12 text-center">
                <p className="text-[10px] text-gray-400 font-bold tracking-widest uppercase">VERIFIED BY APPS AUTHORITIES</p>
              </div>

            </div>
            
            {/* Bottom Color Strip */}
            <div className="h-2 w-full bg-gray-50"></div>
          </div>

          <div className="w-full max-w-[360px] mt-6 space-y-3 no-print">
            <Button onClick={handleDownloadPDF} variant="secondary">
              Download PDF
            </Button>
            <Button onClick={handleDownloadImage}>
              Download Image
            </Button>
            <Button onClick={() => setSavedTx(null)} variant="outline">
              New Transaction
            </Button>
          </div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout title="Entry Dashboard" onBack={onBack}>
      <div className="p-4 space-y-4">
        {/* Top Info */}
        <div className="bg-white p-4 rounded-xl shadow-sm border border-brand-100 mb-2">
          <div className="flex justify-between text-sm text-gray-600">
            <span>{currentTime.toLocaleDateString()}</span>
            <span>{currentTime.toLocaleTimeString()}</span>
          </div>
          <div className="mt-2">
            <h2 className="text-lg font-bold text-brand-700 animate-pulse">
              Welcome, {user.fullName}
            </h2>
          </div>
        </div>

        {/* Transaction Type Selection */}
        <div className="grid grid-cols-2 gap-2">
          {Object.values(TransactionType).filter(t => t !== TransactionType.SEND_MONEY).map((t) => (
            <button
              key={t}
              onClick={() => setTxType(t)}
              className={`p-3 rounded-lg text-sm font-semibold border transition-all ${
                txType === t 
                  ? 'bg-brand-600 text-white border-brand-600 shadow-md transform scale-105' 
                  : 'bg-white text-gray-700 border-gray-200 hover:bg-gray-50'
              }`}
            >
              {t}
            </button>
          ))}
        </div>

        {/* Form */}
        <div className="bg-white p-5 rounded-xl shadow-md space-y-4 animate-slide-up">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Mobile Number (11 Digit)</label>
            <input 
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-500 focus:border-transparent transition-all text-sm"
              type="tel" 
              value={mobile} 
              onChange={(e) => setMobile(e.target.value)}
              placeholder="01XXXXXXXXX"
              maxLength={11}
              list="mobile-history"
            />
            <datalist id="mobile-history">
              {recentNumbers.map((num, idx) => (
                <option key={idx} value={num} />
              ))}
            </datalist>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Customer Name</label>
            <Input 
              type="text" 
              value={name} 
              onChange={(e) => setName(e.target.value)}
              placeholder="Enter name"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Amount</label>
              <Input 
                type="number" 
                value={amount} 
                onChange={(e) => setAmount(e.target.value)}
                placeholder="0.00"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Charge</label>
              <Input 
                type="number" 
                value={charge} 
                onChange={(e) => setCharge(e.target.value)}
                placeholder="0.00"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Note</label>
            <Input 
              type="text" 
              value={note} 
              onChange={(e) => setNote(e.target.value)}
              placeholder="Ref / Reason"
            />
          </div>

          <Button onClick={handleSave} className="mt-4">
            Save & Generate Receipt
          </Button>
        </div>
      </div>
    </Layout>
  );
};
