
import React, { useState, useEffect } from 'react';
import { Layout, Button, Input } from '../components/Layout';
import { Icons } from '../constants';
import { StorageService } from '../services/storage';
import { User } from '../types';

export const LabReport: React.FC<{ user: User, onBack: () => void }> = ({ user, onBack }) => {
  const [formData, setFormData] = useState({
    university: '',
    address: '',
    department: '',
    courseTitle: '',
    courseCode: '',
    teacherName: '',
    designation: '',
    expNo: '',
    expName: '',
    datePerf: '',
    dateSub: '',
    studentName: user.fullName, // Auto-populated from user profile
    studentId: '',
    batch: '',
    semester: ''
  });

  const [logo, setLogo] = useState<string | null>(null);
  const [history, setHistory] = useState<Record<string, string[]>>({});
  const [isProcessing, setIsProcessing] = useState(false);

  useEffect(() => {
    const fields = ['university', 'address', 'department', 'courseTitle', 'courseCode', 'teacherName', 'designation', 'expNo', 'expName', 'studentId', 'batch', 'semester'];
    const histData: Record<string, string[]> = {};
    fields.forEach(f => {
      const fieldHistory = StorageService.getAcademicHistory(f);
      histData[f] = fieldHistory;
    });

    // Auto-fill from last history for persistence
    setFormData(prev => ({
      ...prev,
      university: histData.university?.[histData.university.length - 1] || 'Uttara University',
      address: histData.address?.[histData.address.length - 1] || 'Holding 77, Beribadh Road, Turag, Uttara, Dhaka 1230, Bangladesh.',
      department: histData.department?.[histData.department.length - 1] || 'Civil Engineering',
      studentName: user.fullName // Force the registered name
    }));

    setHistory(histData);
    setLogo(StorageService.getAcademicLogo());
  }, [user.fullName]);

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64 = reader.result as string;
        setLogo(base64);
        StorageService.saveAcademicLogo(base64);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleDownloadPDF = async () => {
    const element = document.getElementById('lab-report-template');
    const jspdfLib = (window as any).jspdf;
    
    if (element && (window as any).html2canvas && jspdfLib) {
      try {
        setIsProcessing(true);
        // Save current entries to history
        Object.entries(formData).forEach(([key, value]) => {
          // Don't save studentName to history anymore as it's locked to profile
          if (key !== 'studentName') {
            StorageService.saveAcademicEntry(key, value as string);
          }
        });

        // Update local history state
        const fields = Object.keys(formData);
        const histData: Record<string, string[]> = {};
        fields.forEach(f => {
          histData[f] = StorageService.getAcademicHistory(f);
        });
        setHistory(histData);

        element.style.display = 'block';
        element.style.position = 'absolute';
        element.style.left = '-9999px';

        const canvas = await (window as any).html2canvas(element, { 
          useCORS: true, 
          scale: 4, 
          logging: false,
          allowTaint: true,
          backgroundColor: '#ffffff'
        });
        
        const imgData = canvas.toDataURL('image/png', 1.0);
        const { jsPDF } = jspdfLib;
        
        const pdf = new jsPDF('p', 'mm', 'a4');
        const imgWidth = 210; 
        const canvasImgHeight = (canvas.height * imgWidth) / canvas.width;
        
        pdf.addImage(imgData, 'PNG', 0, 0, imgWidth, canvasImgHeight, undefined, 'FAST');
        pdf.save(`Lab_Report_${formData.expNo || 'Cover'}.pdf`);
        
        element.style.display = 'none';
      } catch (e) {
        console.error("PDF Error:", e);
        alert("PDF Generation Failed.");
      } finally {
        setIsProcessing(false);
      }
    }
  };

  return (
    <Layout title="Lab Report Entry" onBack={onBack} className="bg-gray-50">
      <div className="p-4 space-y-6 pb-24 no-scrollbar overflow-y-auto">
        {isProcessing && (
          <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-[9999] flex flex-col items-center justify-center text-white p-6 text-center">
             <div className="w-12 h-12 border-4 border-white/20 border-t-white rounded-full animate-spin mb-4"></div>
             <p className="font-bold">Generating Professional PDF...</p>
          </div>
        )}

        <div className="space-y-4">
          {/* ... Settings groups same as before ... */}
          <div className="bg-white p-5 rounded-2xl shadow-sm border border-brand-100">
            <h3 className="text-[10px] font-black uppercase text-brand-600 tracking-widest mb-4">University & Dept Settings</h3>
            <div className="space-y-3">
              <div className="flex items-center gap-4 mb-2">
                 <div className="w-16 h-16 bg-gray-100 rounded-lg flex items-center justify-center border-2 border-dashed border-gray-300 overflow-hidden shrink-0 text-gray-400">
                    {logo ? (
                      <img src={logo} alt="Logo" className="w-full h-full object-contain" />
                    ) : (
                      <Icons.Camera size={24} />
                    )}
                 </div>
                 <div className="flex-1">
                    <label className="block w-full bg-brand-50 text-brand-700 px-4 py-2 rounded-lg text-xs font-bold text-center border border-brand-100 cursor-pointer active:scale-95 transition">
                       {logo ? 'Change Logo' : 'Upload Logo'}
                       <input type="file" className="hidden" accept="image/*" onChange={handleLogoUpload} />
                    </label>
                    {logo && (
                      <button onClick={() => { setLogo(null); StorageService.saveAcademicLogo(null); }} className="block w-full text-center text-[10px] text-red-500 font-bold mt-2 underline">Remove Logo</button>
                    )}
                 </div>
              </div>
              <div className="relative">
                <Input list="list-lab-university" value={formData.university} onChange={e => handleInputChange('university', e.target.value)} placeholder="University Name" />
                <datalist id="list-lab-university">{history.university?.map((item, idx) => <option key={idx} value={item} />)}</datalist>
              </div>
              <div className="relative">
                <Input list="list-lab-address" value={formData.address} onChange={e => handleInputChange('address', e.target.value)} placeholder="Full Address" />
                <datalist id="list-lab-address">{history.address?.map((item, idx) => <option key={idx} value={item} />)}</datalist>
              </div>
              <div className="relative">
                <Input list="list-lab-department" value={formData.department} onChange={e => handleInputChange('department', e.target.value)} placeholder="Department Name (e.g. Civil Engineering)" />
                <datalist id="list-lab-department">{history.department?.map((item, idx) => <option key={idx} value={item} />)}</datalist>
              </div>
            </div>
          </div>

          <div className="bg-white p-5 rounded-2xl shadow-sm border border-brand-100">
            <h3 className="text-[10px] font-black uppercase text-brand-600 tracking-widest mb-4">Course Info</h3>
            <div className="space-y-3">
              <div className="relative">
                <Input list="list-lab-courseCode" value={formData.courseCode} onChange={e => handleInputChange('courseCode', e.target.value)} placeholder="Course Code (e.g. CE 0732 1006)" />
                <datalist id="list-lab-courseCode">{history.courseCode?.map((item, idx) => <option key={idx} value={item} />)}</datalist>
              </div>
              <div className="relative">
                <Input list="list-lab-courseTitle" value={formData.courseTitle} onChange={e => handleInputChange('courseTitle', e.target.value)} placeholder="Course Title" />
                <datalist id="list-lab-courseTitle">{history.courseTitle?.map((item, idx) => <option key={idx} value={item} />)}</datalist>
              </div>
            </div>
          </div>

          <div className="bg-white p-5 rounded-2xl shadow-sm border border-brand-100">
            <h3 className="text-[10px] font-black uppercase text-brand-600 tracking-widest mb-4">Instructor Info</h3>
            <div className="space-y-3">
              <div className="relative">
                <Input list="list-lab-teacherName" value={formData.teacherName} onChange={e => handleInputChange('teacherName', e.target.value)} placeholder="Course Teacher's Name" />
                <datalist id="list-lab-teacherName">{history.teacherName?.map((item, idx) => <option key={idx} value={item} />)}</datalist>
              </div>
              <div className="relative">
                <Input list="list-lab-designation" value={formData.designation} onChange={e => handleInputChange('designation', e.target.value)} placeholder="Designation" />
                <datalist id="list-lab-designation">{history.designation?.map((item, idx) => <option key={idx} value={item} />)}</datalist>
              </div>
            </div>
          </div>

          <div className="bg-white p-5 rounded-2xl shadow-sm border border-brand-100">
            <h3 className="text-[10px] font-black uppercase text-brand-600 tracking-widest mb-4">Experiment Details</h3>
            <div className="space-y-3">
              <div className="relative">
                <Input list="list-lab-expNo" value={formData.expNo} onChange={e => handleInputChange('expNo', e.target.value)} placeholder="Experiment No." />
                <datalist id="list-lab-expNo">{history.expNo?.map((item, idx) => <option key={idx} value={item} />)}</datalist>
              </div>
              <div className="relative">
                <Input list="list-lab-expName" value={formData.expName} onChange={e => handleInputChange('expName', e.target.value)} placeholder="Experiment Name" />
                <datalist id="list-lab-expName">{history.expName?.map((item, idx) => <option key={idx} value={item} />)}</datalist>
              </div>
            </div>
          </div>

          <div className="bg-white p-5 rounded-2xl shadow-sm border border-brand-100">
            <h3 className="text-[10px] font-black uppercase text-brand-600 tracking-widest mb-4">Timeline</h3>
            <div className="space-y-3">
              <Input type="text" value={formData.datePerf} onChange={e => handleInputChange('datePerf', e.target.value)} placeholder="Date of Performance" />
              <Input type="text" value={formData.dateSub} onChange={e => handleInputChange('dateSub', e.target.value)} placeholder="Date of Submission" />
            </div>
          </div>

          <div className="bg-white p-5 rounded-2xl shadow-sm border border-brand-100">
            <h3 className="text-[10px] font-black uppercase text-brand-600 tracking-widest mb-4">Student Identity</h3>
            <div className="space-y-3">
              <div className="relative">
                <label className="text-[9px] font-bold text-gray-400 uppercase ml-1">Student Name (Locked to Profile)</label>
                <Input 
                  value={formData.studentName} 
                  readOnly 
                  className="bg-gray-100 cursor-not-allowed font-bold text-gray-600"
                  placeholder="Name" 
                />
              </div>
              <div className="relative">
                <Input list="list-lab-studentId" value={formData.studentId} onChange={e => handleInputChange('studentId', e.target.value)} placeholder="ID" />
                <datalist id="list-lab-studentId">{history.studentId?.map((item, idx) => <option key={idx} value={item} />)}</datalist>
              </div>
              <div className="relative">
                <Input list="list-lab-batch" value={formData.batch} onChange={e => handleInputChange('batch', e.target.value)} placeholder="Batch" />
                <datalist id="list-lab-batch">{history.batch?.map((item, idx) => <option key={idx} value={item} />)}</datalist>
              </div>
              <div className="relative">
                <Input list="list-lab-semester" value={formData.semester} onChange={e => handleInputChange('semester', e.target.value)} placeholder="Semester" />
                <datalist id="list-lab-semester">{history.semester?.map((item, idx) => <option key={idx} value={item} />)}</datalist>
              </div>
            </div>
          </div>
        </div>

        <Button onClick={handleDownloadPDF} className="py-4 font-black uppercase tracking-widest text-xs flex items-center justify-center gap-2">
           <Icons.Download size={18} /> Download High Quality PDF
        </Button>

        {/* --- PROFESSIONAL PRINT TEMPLATE --- */}
        <div id="lab-report-template" style={{ display: 'none', fontFamily: '"Times New Roman", Times, serif' }} className="w-[794px] min-h-[1123px] bg-white p-[30px] relative text-black leading-tight">
           <div className="absolute top-[25px] left-[25px] right-[25px] bottom-[25px] border-[1.5px] border-black">
              <div className="absolute top-[4px] left-[4px] right-[4px] bottom-[4px] border-[1.5px] border-black p-[50px] h-full flex flex-col">
                
                <div className={`flex items-start w-full mt-4 relative ${logo ? '' : 'flex-col items-center text-center'}`}>
                   {logo && (
                     <div className="w-[155px] shrink-0 mr-8">
                        <img src={logo} alt="Logo" className="w-full h-auto max-h-[160px] object-contain" />
                     </div>
                   )}
                   <div className={`flex-1 ${logo ? 'pr-[155px] text-center' : 'w-full'}`}>
                      <h1 className="text-[28px] font-bold leading-tight uppercase tracking-wider">Department of {formData.department || '...'}</h1>
                      <h2 className="text-[38px] font-bold leading-tight mt-1">{formData.university || '...'}</h2>
                      <p className="text-[17px] font-bold mt-2 max-w-[500px] mx-auto opacity-95">{formData.address || '...'}</p>
                   </div>
                </div>

                <div className="mt-24 text-center">
                   <p className="text-[26px] font-bold">Course Code: {formData.courseCode}</p>
                   <p className="text-[26px] font-bold mt-2">Course Title: {formData.courseTitle}</p>
                </div>

                <div className="mt-28 space-y-12 pl-4">
                   <div className="text-[22px] font-bold">
                      <div className="grid grid-cols-[300px_30px_1fr] items-start">
                         <span>Course Teacher’s Name</span>
                         <span>:</span>
                         <span className="font-normal">{formData.teacherName}</span>
                         
                         <span className="mt-2">Designation</span>
                         <span className="mt-2">:</span>
                         <span className="mt-2 font-normal">{formData.designation}</span>
                      </div>
                   </div>

                   <div className="text-[22px] font-bold">
                      <div className="grid grid-cols-[300px_30px_1fr] items-start">
                         <span>Experiment No.</span>
                         <span>:</span>
                         <span className="font-normal">{formData.expNo}</span>
                         
                         <span className="mt-2">Experiment Name</span>
                         <span className="mt-2">:</span>
                         <span className="mt-2 font-normal">{formData.expName}</span>
                      </div>
                   </div>

                   <div className="text-[22px] font-bold">
                      <div className="grid grid-cols-[300px_30px_1fr] items-start">
                         <span>Date of Performance</span>
                         <span>:</span>
                         <span className="font-normal">{formData.datePerf}</span>
                         
                         <span className="mt-2">Date of Submission</span>
                         <span className="mt-2">:</span>
                         <span className="mt-2 font-normal">{formData.dateSub}</span>
                      </div>
                   </div>
                </div>

                <div className="mt-auto pb-10 flex justify-between items-end">
                   <div className="text-center">
                      <div className="w-[200px] border-t border-black border-dotted mb-3"></div>
                      <p className="text-[22px] font-bold">(Signature)</p>
                   </div>

                   <div className="text-[22px] font-bold w-[360px] space-y-2">
                      <div className="grid grid-cols-[100px_30px_1fr]">
                         <span>Name</span>
                         <span>:</span>
                         <span className="font-normal truncate">{formData.studentName}</span>

                         <span>ID</span>
                         <span>:</span>
                         <span className="font-normal">{formData.studentId}</span>

                         <span>Batch</span>
                         <span>:</span>
                         <span className="font-normal">{formData.batch}</span>

                         <span>Semester</span>
                         <span>:</span>
                         <span className="font-normal">{formData.semester}</span>
                      </div>
                   </div>
                </div>

              </div>
           </div>
        </div>
      </div>
    </Layout>
  );
};
