
import React, { useState, useRef, useMemo } from 'react';
import { Layout } from '../components/Layout';
import { Icons } from '../constants';

interface Surah {
  id: number;
  name: string;
  arabicName: string;
  verses: number;
  arabicText?: string;
  bengaliMeaning?: string;
}

export const SurahZone: React.FC<{ onBack: () => void }> = ({ onBack }) => {
  const [playingId, setPlayingId] = useState<string | null>(null); // Format: 'id-type'
  const [search, setSearch] = useState('');
  const [expandedId, setExpandedId] = useState<number | null>(null);
  const [showTextId, setShowTextId] = useState<number | null>(null);
  const [isAudioLoading, setIsAudioLoading] = useState(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  // Expanded Surah Data with actual Arabic text and Bengali meanings
  const allSurahs: Surah[] = useMemo(() => {
    const names = [
      "Al-Fatiha", "Al-Baqarah", "Ali 'Imran", "An-Nisa", "Al-Ma'idah", "Al-An'am", "Al-A'raf", "Al-Anfal", "At-Tawbah", "Yunus",
      "Hud", "Yusuf", "Ar-Ra'd", "Ibrahim", "Al-Hijr", "An-Nahl", "Al-Isra", "Al-Kahf", "Maryam", "Ta-Ha",
      "Al-Anbiya", "Al-Hajj", "Al-Mu'minun", "An-Nur", "Al-Furqan", "Ash-Shu'ara", "An-Naml", "Al-Qasas", "Al-'Ankabut", "Ar-Rum",
      "Luqman", "As-Sajdah", "Al-Ahzab", "Saba", "Fatir", "Ya-Sin", "As-Saffat", "Sad", "Az-Zumar", "Ghafir",
      "Fussilat", "Ash-Shura", "Az-Zukhruf", "Ad-Dukhan", "Al-Jathiyah", "Al-Ahqaf", "Muhammad", "Al-Fath", "Al-Hujurat", "Qaf",
      "Adh-Dhariyat", "At-Tur", "An-Najm", "Al-Qamar", "Ar-Rahman", "Al-Waqi'ah", "Al-Hadid", "Al-Mujadilah", "Al-Hashr", "Al-Mumtahanah",
      "As-Saff", "Al-Jumu'ah", "Al-Munafiqun", "At-Taghabun", "At-Talaq", "At-Tahrim", "Al-Mulk", "Al-Qalam", "Al-Haqqah", "Al-Ma'arij",
      "Nuh", "Al-Jinn", "Al-Muzzammil", "Al-Muddaththir", "Al-Qiyamah", "Al-Insan", "Al-Mursalat", "An-Naba", "An-Nazi'at", "'Abasa",
      "At-Takwir", "Al-Infitar", "Al-Mutaffifin", "Al-Inshiqaq", "Al-Buruj", "At-Tariq", "Al-A'la", "Al-Ghashiyah", "Al-Fajr", "Al-Balad",
      "Ash-Shams", "Al-Layl", "Ad-Duha", "Ash-Sharh", "At-Tin", "Al-'Alaq", "Al-Qadr", "Al-Bayyinah", "Az-Zalzalah", "Al-'Adiyat",
      "Al-Qari'ah", "At-Takathur", "Al-'Asr", "Al-Humazah", "Al-Fil", "Quraysh", "Al-Ma'un", "Al-Kawthar", "Al-Kafirun", "An-Nasr",
      "Al-Masad", "Al-Ikhlas", "Al-Falaq", "An-Nas"
    ];

    const specificData: Record<number, Partial<Surah>> = {
      1: { 
        arabicText: "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ ﴿١﴾ الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ ﴿٢﴾ الرَّحْمَٰنِ الرَّحِيمِ ﴿٣﴾ مَالِكِ يَوْمِ الدِّينِ ﴿٤﴾ إِيَّاكَ نَعْبُدُ وَإِيَّاكَ نَسْتَعِينُ ﴿٥﴾ اهْدِنَا الصِّرَاطَ الْمُسْتَقِيمَ ﴿٦﴾ صِرَاطَ الَّذِينَ أَنْعَمْتَ عَلَيْهِمْ غَيْرِ الْمَغْضُوبِ عَلَيْهِمْ وَلَا الضَّالِّينَ ﴿٧﴾", 
        bengaliMeaning: "১. শুরু করছি আল্লাহর নামে যিনি পরম করুণাময়, অতি দয়ালু। ২. যাবতীয় প্রশংসা আল্লাহর জন্য, যিনি বিশ্বজগতের প্রতিপালক। ৩. যিনি পরম করুণাময়, অতি দয়ালু। ৪. বিচার দিবসের অধিপতি। ৫. আমরা একমাত্র আপনারই ইবাদত করি এবং একমাত্র আপনারই নিকট সাহায্য চাই। ৬. আমাদের সরল পথ প্রদর্শন করুন। ৭. তাদের পথ, যাদের আপনি নেয়ামত দান করেছেন। তাদের পথ নয় যারা অভিশপ্ত ও পথভ্রষ্ট।" 
      },
      93: {
        arabicText: "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ. وَالضُّحَىٰ ﴿١﴾ وَاللَّيْلِ إِذَا سَجَىٰ ﴿٢﴾ مَا وَدَّعَكَ رَبُّكَ وَمَا قَلَىٰ ﴿٣﴾ وَلَلْآخِرَةُ خَيْرٌ لَّكَ مِنَ الْأُولَىٰ ﴿٤﴾ وَلَسَوْفَ يُعْطِيكَ رَبُّكَ فَتَرْضَىٰ ﴿٥﴾ أَلَمْ يَجِدْكَ يَتِيمًا فَآوَىٰ ﴿٦﴾ وَوَجَدَكَ ضَالًّا فَهَدَىٰ ﴿٧﴾ وَوَجَدَكَ عَائِلًا فَأَغْنَىٰ ﴿٨﴾ فَأَمَّا الْيَتِيمَ فَلَا تَقْهَرْ ﴿٩﴾ وَأَمَّا السَّائِلَ فَلَا تَنْهَرْ ﴿١٠﴾ وَأَمَّا بِنِعْمَةِ رَبِّكَ فَحَدِّثْ ﴿١١﴾",
        bengaliMeaning: "১. পূর্বাহ্নের শপথ, ২. এবং রাত্রির শপথ যখন তা নিঝুম হয়, ৩. আপনার পালনকর্তা আপনাকে ত্যাগ করেননি এবং আপনার প্রতি বিরূপ হননি। ৪. আপনার জন্য পরকাল ইহকাল অপেক্ষা শ্রেয়। ৫. আপনার পালনকর্তা শীঘ্রই আপনাকে দান করবেন, অতঃপর আপনি সন্তুষ্ট হবেন। ৬. তিনি কি আপনাকে এতিম রূপে পাননি? অতঃপর আশ্রয় দেননি? ৭. তিনি আপনাকে পথহারা পাননি? অতঃপর পথপ্রদর্শন করেননি? ৮. তিনি আপনাকে নিঃস্ব পাননি? অতঃপর অভাবমুক্ত করেননি? ৯. সুতরাং এতিমের প্রতি কঠোর হবেন না, ১০. সাহায্যপ্রার্থীকে ধমক দেবেন না, ১১. এবং আপনার পালনকর্তার নেয়ামতের কথা প্রচার করুন।"
      },
      94: {
        arabicText: "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ. أَلَمْ نَشْرَحْ لَكَ صَدْرَكَ ﴿١﴾ وَوَضَعْنَا عَنكَ وِزْرَكَ ﴿٢﴾ الَّذِي أَنقَضَ ظَهْرَكَ ﴿٣﴾ وَرَفَعْنَا لَكَ ذِكْرَكَ ﴿٤﴾ فَإِنَّ مَعَ الْعُسْرِ يُسْرًا ﴿٥﴾ إِنَّ مَعَ الْعُسْرِ يُسْرًا ﴿٦﴾ فَإِذَا فَرَغْتَ فَانصَبْ ﴿٧﴾ وَإِلَىٰ رَبِّكَ فَارْغَب ﴿٨﴾",
        bengaliMeaning: "১. আমি কি আপনার বক্ষ প্রশস্ত করে দেইনি? ২. এবং আমি আপনার ভার লাঘব করে দিয়েছি, ৩. যা আপনার পিঠ নুইয়ে দিয়েছিল। ৪. এবং আমি আপনার স্মরণকে সমুন্নত করেছি। ৫. নিশ্চয় কষ্টের সাথেই স্বস্তি রয়েছে। ৬. নিশ্চয় কষ্টের সাথেই স্বস্তি রয়েছে। ৭. অতএব আপনি যখন অবসর পান, তখন এবাদতের পরিশ্রমে আত্মনিয়োগ করুন। ৮. এবং আপনার পালনকর্তার প্রতি মনোনিবেশ করুন।"
      },
      95: {
        arabicText: "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ. وَالتِّينِ وَالزَّيْتُونِ ﴿١﴾ وَطُورِ سِينِينَ ﴿٢﴾ وَهَٰذَا الْبَلَدِ الْأَمِينِ ﴿٣﴾ لَقَدْ خَلَقْنَا الْإِنسَانَ فِي أَحْسَنِ تَقْوِيمٍ ﴿٤﴾ ثُمَّ رَدَدْنَاهُ أَسْفَلَ سَافِلِينَ ﴿٥﴾ إِلَّا الَّذِينَ آمَنُوا وَعَمِلُوا الصَّالِحَاتِ فَلَهُمْ أَجْرٌ غَيْرُ مَمْنُونٍ ﴿٦﴾ فَمَا يُكَذِّبُكَ بَعْدُ بِالدِّينِ ﴿٧﴾ أَلَيْسَ اللَّهُ بِأَحْكَمِ الْحَاكِمِينَ ﴿٨﴾",
        bengaliMeaning: "১. ডুমুর ও জলপাইয়ের শপথ, ২. সিনাই পর্বতের শপথ, ৩. এবং এই নিরাপদ নগরীর (মক্কা) শপথ। ৪. অবশ্যই আমি মানুষকে অতি সুন্দর গঠনে সৃষ্টি করেছি। ৫. অতঃপর তাকে ফিরিয়ে দিয়েছি নীচ থেকে নীচে। ৬. কিন্তু তাদের ব্যতীত যারা ঈমান এনেছে ও সৎকর্ম করেছে, তাদের জন্য রয়েছে নিরবচ্ছিন্ন পুরস্কার। ৭. অতএব কিসে আপনাকে বিচার দিবস সম্পর্কে মিথ্যা প্রতিপন্ন করছে? ৮. আল্লাহ কি বিচারকদের মধ্যে শ্রেষ্ঠতম বিচারক নন?"
      },
      97: {
        arabicText: "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ. إِنَّا أَنزَلْنَاهُ فِي لَيْلَةِ الْقَدْرِ ﴿١﴾ وَمَا أَدْرَاكَ مَا لَيْلَةُ الْقَدْرِ ﴿٢﴾ لَيْلَةُ الْقَدْرِ خَيْرٌ مِّنْ أَلْفِ شَهْرٍ ﴿٣﴾ تَنَزَّلُ الْمَلَائِكَةُ وَالرُّوحُ فِيهَا بِإِذْنِ رَبِّهِم مِّن كُلِّ أَمْرٍ ﴿٤﴾ سَلَامٌ هِيَ حَتَّىٰ مَطْلَعِ الْفَجْرِ ﴿٥﴾",
        bengaliMeaning: "১. নিশ্চয়ই আমি এটি কদরের রাতে অবতীর্ণ করেছি। ২. আর কদরের রাত সম্পর্কে আপনি কী জানেন? ৩. কদরের রাত হাজার মাস অপেক্ষা শ্রেষ্ঠ। ৪. ফেরেশতাগণ ও রূহ (জিবরাইল) সেই রাতে তাদের পালনকর্তার নির্দেশে সব বিষয় নিয়ে অবতরণ করেন। ৫. সেই রাত ফজর উদয় হওয়া পর্যন্ত শান্তিময়।"
      },
      101: {
        arabicText: "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ. الْقَارِعَةُ ﴿١﴾ مَا الْقَارِعَةُ ﴿٢﴾ وَمَا أَدْرَاكَ مَا الْقَارِعَةُ ﴿٣﴾ يَوْمَ يَكُونُ النَّاسُ كَالْفَرَاشِ الْمَبْثُوثِ ﴿٤﴾ وَتَكُونُ الْجِبَالُ كَالْعِهْنِ الْمَنفُوشِ ﴿٥﴾ فَأَمَّا مَن ثَقُلَتْ مَوَازِينُهُ ﴿٦﴾ فَهُوَ فِي عِيشَةٍ رَّاضِيَةٍ ﴿٧﴾ وَأَمَّا مَنْ خَفَّتْ مَوَازِينُهُ ﴿٨﴾ فَأُمُّهُ هَاوِيَةٌ ﴿٩﴾ وَمَا أَدْرَاكَ مَا هِيَهْ ﴿١٠﴾ نَارٌ حَامِيَةٌ ﴿١١﴾",
        bengaliMeaning: "১. মহাপ্রলয়। ২. মহাপ্রলয় কী? ৩. মহাপ্রলয় সম্পর্কে আপনি কী জানেন? ৪. সেই দিন মানুষ হবে বিক্ষিপ্ত পতঙ্গের মতো। ৫. এবং পাহাড়গুলো হবে ধুনিত রঙিন পশমের মতো। ৬. অতঃপর যার আমলনামা ভারী হবে, ৭. সে সুখী জীবনে থাকবে। ৮. আর যার আমলনামা হালকা হবে, ৯. তার ঠিকানা হবে ‘হাওয়িয়া’। ১০. আপনি কি জানেন তা কী? ১১. তা প্রজ্বলিত অগ্নি।"
      },
      102: {
        arabicText: "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ. أَلْهَاكُمُ التَّكَاثُرُ ﴿١﴾ حَتَّىٰ زُرْتُمُ الْمَقَابِرَ ﴿٢﴾ كَلَّا سَوْفَ تَعْلَمُونَ ﴿٣﴾ ثُمَّ كَلَّا سَوْفَ تَعْلَمُونَ ﴿٤﴾ كَلَّا لَوْ تَعْلَمُونَ عِلْمَ الْيَقِينِ ﴿٥﴾ لَتَرَوُنَّ الْجَحِيمَ ﴿٦﴾ ثُمَّ لَتَرَوُنَّهَا عَيْنَ الْيَقِينِ ﴿٧﴾ ثُمَّ لَتُسْأَلُنَّ يَوْمَئِذٍ عَنِ النَّعِيمِ ﴿٨﴾",
        bengaliMeaning: "১. প্রাচুর্যের প্রতিযোগিতা তোমাদেরকে গাফেল করে রেখেছে, ২. যতক্ষণ না তোমরা কবরে উপস্থিত হচ্ছ। ৩. কখনই না, শীঘ্রই তোমরা জানতে পারবে। ৪. অতঃপর কখনই না, শীঘ্রই তোমরা জানতে পারবে। ৫. কখনই না, যদি তোমরা ধ্রুব সত্যের জ্ঞানে জানতে। ৬. তোমরা অবশ্যই জাহান্নাম দেখবে। ৭. পুনরায় তোমরা তা চাক্ষুষ দেখবে। ৮. অতঃপর সেই দিন তোমাদেরকে দেয়া নেয়ামত সম্পর্কে অবশ্যই জিজ্ঞাসাবাদ করা হবে।"
      },
      103: {
        arabicText: "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ. وَالْعَصْرِ ﴿١﴾ إِنَّ الْإِنسَانَ لَفِي خُسْرٍ ﴿٢﴾ إِلَّا الَّذِينَ آمَنُوا وَعَمِلُوا الصَّالِحَاتِ وَتَوَاصَوْا بِالْحَقِّ وَتَوَاصَوْا بِالصَّبْرِ ﴿٣﴾",
        bengaliMeaning: "১. কালের শপথ, ২. নিশ্চয়ই মানুষ ক্ষতিগ্রস্ততার মধ্যে নিহিত। ৩. তবে তারা নয়, যারা ঈমান এনেছে ও সৎকাজ করেছে এবং পরস্পরকে সত্যের উপদেশ দিয়েছে ও ধৈর্যের উপদেশ দিয়েছে।"
      },
      104: {
        arabicText: "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ. وَيْلٌ لِّكُلِّ هُمَزَةٍ لُّمَزَةٍ ﴿١﴾ الَّذِي جَمَعَ مَالًا وَعَدَّدَهُ ﴿٢﴾ يَحْسَبُ أَنَّ مَالَهُ أَخْلَدَهُ ﴿٣﴾ كَلَّا لَيُنبَذَنَّ فِي الْحُطَمَةِ ﴿٤﴾ وَمَا أَدْرَاكَ مَا الْحُطَمَةُ ﴿٥﴾ نَارُ اللَّهِ الْمُوقَدَةُ ﴿٦﴾ الَّتِي تَطَّلِعُ عَلَى الْأَفْئِدَةِ ﴿٧﴾ إِنَّهَا عَلَيْهِم مُّؤْصَدَةٌ ﴿٨﴾ فِي عَمَدٍ مُّمَدَّدَةٍ ﴿٩﴾",
        bengaliMeaning: "১. দুর্ভোগ প্রত্যেকের জন্য, যে পিছনে ও সামনে লোকের নিন্দা করে, ২. যে সম্পদ জমা করে ও তা বারবার গণনা করে। ৩. সে মনে করে যে, তার সম্পদ তাকে অমর করে রাখবে। ৪. কখনই না, সে অবশ্যই নিক্ষিপ্ত হবে ‘হুতামায়’। ৫. আপনি কী জানেন হুতামা কী? ৬. তা হলো আল্লাহর প্রজ্বলিত আগুন, ৭. যা অন্তরসমূহ পর্যন্ত পৌঁছে যাবে। ৮. নিশ্চয়ই তা তাদেরকে বেষ্টন করে রাখবে, ৯. উঁচু উঁচু স্তম্ভসমূহে।"
      },
      105: {
        arabicText: "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ. أَلَمْ تَرَ كَيْفَ فَعَلَ رَبُّكَ بِأَصْحَابِ الْفِيلِ ﴿١﴾ أَلَمْ يَجْعَلْ كَيْدَهُمْ فِي تَضْلِيلٍ ﴿٢﴾ وَأَرْسَلَ عَلَيْهِمْ طَيْرًا أَبَابِيلَ ﴿٣﴾ تَرْمِيهِم بِحِجَارَةٍ مِّن سِجِّيلٍ ﴿٤﴾ فَجَعَلَهُمْ كَعَصْفٍ مَّأْكُولٍ ﴿٥﴾",
        bengaliMeaning: "১. আপনি কি দেখেননি আপনার পালনকর্তা হস্তিবাহিনীর সাথে কি রূপ ব্যবহার করেছেন? ২. তিনি কি তাদের চক্রান্ত নস্যাৎ করে দেননি? ৩. তিনি তাদের উপর ঝাঁকে ঝাঁকে পাখী প্রেরণ করেছেন, ৪. যারা তাদের উপর পাথরের কংকর নিক্ষেপ করছিল। ৫. অতঃপর তিনি তাদেরকে ভক্ষিত তৃণসদৃশ করে দিলেন।"
      },
      106: {
        arabicText: "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ. لِإِيلافِ قُرَيْشٍ ﴿١﴾ إِيلافِهِمْ رِحْلَةَ الشِّتَاءِ وَالصَّيْفِ ﴿٢﴾ فَلْيَعْبُدُوا رَبَّ هَذَا الْبَيْتِ ﴿٣﴾ الَّذِي أَطْعَمَهُم مِّن جُوعٍ وَآمَنَهُم مِّনْ خَوْفٍ ﴿٤﴾",
        bengaliMeaning: "১. কোরাইশদের আসক্তির কারণে, ২. আসক্তি তাদের শীত ও গ্রীষ্মকালীন সফরের। ৩. অতএব তারা যেন এই গৃহের পালনকর্তার এবাদত করে, ৪. যিনি তাদেরকে ক্ষুধা থেকে অন্ন দিয়েছেন এবং ভয় থেকে মুক্তি দিয়েছেন।"
      },
      107: {
        arabicText: "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ. أَرَأَيْتَ الَّذِي يُكَذِّبُ بِالدِّينِ ﴿١﴾ فَদَلِكَ الَّذِي يَدُعُّ الْيَتِيمَ ﴿٢﴾ وَلا يَحُضُّ عَلَى طَعَامِ الْمِسْكِينِ ﴿٣﴾ فَوَيْلٌ لِّلْمُصَلِّينَ ﴿٤﴾ الَّذِينَ هُمْ عَن صَلاتِهِمْ سَاهُونَ ﴿٥﴾ الَّذِينَ هُمْ يُرَاؤُونَ ﴿٦﴾ وَيَمْنَعُونَ الْمَاعُونَ ﴿٧﴾",
        bengaliMeaning: "১. আপনি কি দেখেছেন তাকে, যে বিচার দিবসকে অস্বীকার করে? ২. সেই তো সেই ব্যক্তি, যে এতিমকে গলা ধাক্কা দেয়, ৩. এবং মিসকিনকে অন্নদানে উৎসাহিত করে না। ৪. অতএব দুর্ভোগ সেই সব নামাজীদের জন্য, ৫. যারা তাদের নামাজ সম্পর্কে উদাসীন; ৬. যারা লোক দেখানোর জন্য তা করে, ৭. এবং নিত্য প্রয়োজনীয় ছোটখাট সাহায্য দানে বিরত থাকে।"
      },
      108: {
        arabicText: "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ. إِنَّا أَعْطَيْنَاكَ الْكَوْثَرَ ﴿١﴾ فَصَلِّ لِرَبِّكَ وَانْحَرْ ﴿٢﴾ إِنَّ শَانِئَكَ هُوَ الْأَبْتَرُ ﴿٣﴾",
        bengaliMeaning: "১. নিশ্চয়ই আমি আপনাকে কাউসার দান করেছি। ২. অতএব আপনার প্রতিপালকের উদ্দেশ্যে নামায পড়ুন এবং কোরবানি করুন। ৩. নিশ্চয়ই আপনার প্রতি বিদ্বেষ পোষণকারীই নির্বংশ।"
      },
      109: {
        arabicText: "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ. قُلْ يَا أَيُّهَا الْكَافِرُونَ ﴿١﴾ لا أَعْبُدُ مَا تَعْبُدُونَ ﴿٢﴾ وَلا أَنتُمْ عَابِدُونَ مَا أَعْبُدُ ﴿٣﴾ وَلا أَنَا عَابِدٌ مَّا عَبَدتُّمْ ﴿٤﴾ وَلا أَنتُمْ عَابِدُونَ مَا أَعْبُدُ ﴿٥﴾ لَكُمْ دِينُكُمْ وَلِيَ دِينِ ﴿٦﴾",
        bengaliMeaning: "১. বলুন, হে কাফেরকুল! ২. আমি এবাদত করি না তোমরা যার এবাদত কর। ৩. এবং তোমরাও এবাদতকারী নও আমি যার এবাদত করি। ৪. এবং আমি এবাদতকারী নই তোমরা যার এবাদত করে আসছ। ৫. এবং তোমরা এবাদতকারী নও আমি যার এবাদত করি। ৬. তোমাদের জন্য তোমাদের ধর্ম এবং আমার জন্য আমার ধর্ম।"
      },
      110: {
        arabicText: "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ. إِذَا جَاءَ نَصْرُ اللَّهِ وَالْفَتْحُ ﴿١﴾ وَرَأَيْتَ النَّاسَ يَدْخُلُونَ فِي دِينِ اللَّهِ أَفْواجًا ﴿٢﴾ فَسَبِّحْ بِحَمْدِ رَبِّكَ وَاسْتَغْفِرْهُ إِنَّهُ كَانَ تَوَّابًا ﴿٣﴾",
        bengaliMeaning: "১. যখন আসবে আল্লাহর সাহায্য ও বিজয়, ২. এবং আপনি মানুষকে দলে দলে আল্লাহর দ্বীনে প্রবেশ করতে দেখবেন, ৩. তখন আপনি আপনার পালনকর্তার পবিত্রতা বর্ণনা করুন এবং তাঁর কাছে ক্ষমা প্রার্থনা করুন। নিশ্চয়ই তিনি তওবা কবুলকারী।"
      },
      111: {
        arabicText: "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ. تَبَّتْ يَدَا أَبِي لَهَبٍ وَتَبَّ ﴿١﴾ مَا أَغْنَى عَنْهُ مَالُهُ وَمَا كَسَبَ ﴿٢﴾ سَيَصْلَى نَارًا ذَاتَ لَهَبٍ ﴿٣﴾ وَامْرَأَتُهُ حَمَّالَةَ الْحَطَبِ ﴿٤﴾ فِي جِيدِهَا حَبْلٌ مِّن مَّسَدٍ ﴿٥﴾",
        bengaliMeaning: "১. আবু লাহাবের হস্তদ্বয় ধ্বংস হোক এবং ধ্বংস হোক সে নিজেও। ২. তার ধন-সম্পদ ও তার উপার্জন তার কোনো কাজে আসেনি। ৩. শীঘ্রই সে লেলিহান অগ্নিতে প্রবেশ করবে, ৪. এবং তার স্ত্রীও-যে ইন্ধন বহনকারিনী, ৫. তার গলদেশে খর্জুরপত্রের পাকানো রশি।"
      },
      112: { 
        arabicText: "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ. قُلْ هُوَ اللَّهُ أَحَدٌ ﴿١﴾ اللَّهُ الصَّمَدُ ﴿٢﴾ لَمْ يَلِدْ وَلَمْ يُولَدْ ﴿٣﴾ وَلَمْ يَكُن لَّهُ كُفُوًا أَحَدٌ ﴿٤﴾", 
        bengaliMeaning: "১. বলুন, তিনি আল্লাহ, এক। ২. আল্লাহ অমুখাপেক্ষী। ৩. তিনি কাউকে জন্ম দেননি এবং কেউ তাকে জন্ম দেয়নি। ৪. এবং তার সমতুল্য কেউ নেই।" 
      },
      113: {
        arabicText: "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ. قُلْ أَعُوذُ بِرَبِّ الْفَلَقِ ﴿١﴾ مِن شَرِّ مَا خَلَقَ ﴿٢﴾ وَمِن شَرِّ غَاسِقٍ إِذَا وَقَبَ ﴿٣﴾ وَمِن شَرِّ النَّفَّاثَاتِ فِي الْعُقَدِ ﴿٤﴾ وَمِن شَرِّ حَاسِدٍ إِذَا حَسَدَ ﴿٥﴾",
        bengaliMeaning: "১. বলুন, আমি আশ্রয় চাচ্ছি ঊষালোকের প্রতিপালকের, ২. তিনি যা সৃষ্টি করেছেন তার অনিষ্ট হতে, ৩. এবং অন্ধকার রাত্রির অনিষ্ট হতে যখন তা সমাগত হয়, ৪. এবং গ্রন্থিতে ফুৎকারদানকারী নারী জাদুকরদের অনিষ্ট হতে, ৫. এবং হিংসুকের অনিষ্ট হতে যখন সে হিংসা করে।"
      },
      114: {
        arabicText: "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ. قُلْ أَعُوذُ بِرَبِّ النَّاسِ ﴿١﴾ مَلِكِ النَّاسِ ﴿٢﴾ إِلَٰهِ النَّاسِ ﴿٣﴾ مِن شَرِّ الْوَسْوَاسِ الْخَنَّاسِ ﴿٤﴾ الَّذِي يُوَسْوِسُ فِي صُدُورِ النَّاسِ ﴿٥﴾ مِنَ الْجِنَّةِ وَالنَّاسِ ﴿٦﴾",
        bengaliMeaning: "১. বলুন, আমি আশ্রয় চাচ্ছি মানুষের প্রতিপালকের, ২. মানুষের অধিপতির, ৩. মানুষের উপাস্যের, ৪. কুমন্ত্রণাদাতা আত্মগোপনকারীর অনিষ্ট হতে, ৫. যে মানুষের অন্তরে কুমন্ত্রণা দেয়, ৬. জিনের মধ্য হতে অথবা মানুষের মধ্য হতে।"
      }
    };

    return Array.from({ length: 114 }, (_, i) => {
      const id = i + 1;
      return {
        id,
        name: names[i],
        arabicName: "পবিত্র সূরা",
        verses: 0,
        ...specificData[id]
      };
    });
  }, []);

  const filteredSurahs = useMemo(() => {
    return allSurahs.filter(s => 
      s.name.toLowerCase().includes(search.toLowerCase()) || 
      s.id.toString() === search.trim()
    );
  }, [allSurahs, search]);

  const handleAudioPlay = (id: number) => {
    const playKey = `${id}-rec`;
    const surahIdStr = String(id).padStart(3, '0');
    const url = `https://server8.mp3quran.net/afs/${surahIdStr}.mp3`;

    if (playingId === playKey) {
      audioRef.current?.pause();
      setPlayingId(null);
    } else {
      if (audioRef.current) {
        setIsAudioLoading(true);
        audioRef.current.src = url;
        audioRef.current.play().then(() => {
          setIsAudioLoading(false);
          setPlayingId(playKey);
        }).catch(e => {
          setIsAudioLoading(false);
          console.error("Audio Playback Error", e);
          alert("দুঃখিত, এই সূরার অডিওটি বর্তমানে লোড করা যাচ্ছে না।");
          setPlayingId(null);
        });
      }
    }
  };

  const toggleExpand = (id: number) => {
    setExpandedId(expandedId === id ? null : id);
    if (expandedId !== id) setShowTextId(null);
  };

  const toggleText = (id: number) => {
    setShowTextId(showTextId === id ? null : id);
  };

  return (
    <Layout title="পবিত্র সূরাসমূহ" onBack={onBack} className="bg-emerald-50">
      <div className="sticky top-0 z-20 bg-emerald-50 p-4 shadow-sm border-b border-emerald-100">
        <div className="bg-white p-2 rounded-2xl shadow-inner border border-emerald-100 flex items-center gap-2">
           <div className="p-2 text-emerald-400">
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg>
           </div>
           <input 
             placeholder="সূরার নাম দিয়ে খুঁজুন..." 
             value={search} 
             onChange={e => setSearch(e.target.value)}
             className="w-full bg-transparent border-none focus:ring-0 text-emerald-800 font-bold placeholder:text-emerald-200 text-sm"
           />
        </div>
      </div>

      <div className="p-4 space-y-4 pb-24">
        <audio ref={audioRef} onEnded={() => setPlayingId(null)} className="hidden" />

        {filteredSurahs.length === 0 ? (
          <div className="text-center py-20 text-emerald-800 font-bold">কোন সূরা খুঁজে পাওয়া যায়নি।</div>
        ) : (
          filteredSurahs.map((s, idx) => (
            <div 
              key={s.id} 
              className={`bg-white rounded-3xl shadow-sm border border-emerald-100 overflow-hidden transition-all duration-300 animate-slide-up ${expandedId === s.id ? 'ring-2 ring-emerald-500 shadow-xl' : ''}`}
              style={{ animationDelay: `${idx * 0.02}s` }}
            >
              <button 
                onClick={() => toggleExpand(s.id)}
                className="w-full p-4 flex justify-between items-center text-left active:bg-emerald-50 transition-colors"
              >
                 <div className="flex items-center gap-4">
                    <div className="w-10 h-10 bg-emerald-600 text-white rounded-xl flex items-center justify-center font-black shadow-md">
                       {s.id}
                    </div>
                    <div>
                       <h3 className="text-emerald-900 font-black uppercase tracking-tight">{s.name}</h3>
                       <p className="text-[10px] text-emerald-400 font-bold uppercase tracking-widest">পবিত্র কুরআনুল কারীম</p>
                    </div>
                 </div>
                 <div className="text-right flex items-center gap-3">
                    <span className="text-2xl font-arabic font-bold text-emerald-800 opacity-60">
                        {s.id === 1 ? 'الفاتحة' : (s.id === 112 ? 'الإخلاص' : (s.id === 113 ? 'الفلق' : (s.id === 114 ? 'الناس' : 'সূরা')))}
                    </span>
                 </div>
              </button>

              {expandedId === s.id && (
                <div className="p-6 pt-2 bg-emerald-50/20 animate-fade-in border-t border-emerald-50">
                   <div className="grid grid-cols-2 gap-3 mb-4">
                      <button 
                        onClick={() => handleAudioPlay(s.id)}
                        disabled={isAudioLoading && playingId !== `${s.id}-rec`}
                        className={`flex items-center justify-center gap-2 py-3.5 rounded-2xl font-black text-[10px] uppercase tracking-widest transition-all ${
                          playingId === `${s.id}-rec` 
                          ? 'bg-emerald-600 text-white shadow-lg animate-pulse' 
                          : 'bg-emerald-100 text-emerald-700 hover:bg-emerald-200'
                        }`}
                      >
                        {isAudioLoading && playingId === `${s.id}-rec` ? (
                          <div className="w-3 h-3 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                        ) : (playingId === `${s.id}-rec` ? <Icons.Pause size={14} /> : <Icons.Play size={14} />)}
                        তেলাওয়াত শুনুন
                      </button>
                      <button 
                        onClick={() => toggleText(s.id)}
                        className={`flex items-center justify-center gap-2 py-3.5 rounded-2xl font-black text-[10px] uppercase tracking-widest transition-all ${
                          showTextId === s.id 
                          ? 'bg-teal-700 text-white shadow-lg' 
                          : 'bg-teal-50 text-teal-700 hover:bg-teal-100'
                        }`}
                      >
                        <Icons.FileText size={14} />
                        আরবি ও অনুবাদ
                      </button>
                   </div>

                   {showTextId === s.id && (
                      <div className="animate-fade-in">
                         {s.arabicText ? (
                            <div className="p-5 bg-white rounded-2xl border border-emerald-100 shadow-inner">
                               <p className="text-3xl leading-[2.4] font-arabic text-emerald-900 text-right mb-6" dir="rtl">{s.arabicText}</p>
                               <div className="border-t border-dashed border-emerald-100 pt-5">
                                  <p className="text-md font-bold text-emerald-800 leading-relaxed text-justify">{s.bengaliMeaning}</p>
                                </div>
                            </div>
                         ) : (
                            <div className="py-8 px-6 text-center bg-white rounded-2xl border border-emerald-100 italic text-gray-400 text-sm">
                               {/* Special prompt for more Surahs to come if not hardcoded */}
                               <div className="space-y-4">
                                  <p className="text-emerald-700 font-bold">এই সূরার অনুবাদটি শীঘ্রই আপডেট করা হবে।</p>
                                  <p className="text-[10px] opacity-75">পবিত্র কুরআনুল কারীমের সকল সূরার পূর্ণাঙ্গ টেক্সট যুক্ত করার কাজ চলমান রয়েছে।</p>
                               </div>
                            </div>
                         )}
                      </div>
                   )}
                </div>
              )}
            </div>
          ))
        )}
      </div>

      {playingId && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 bg-emerald-900 text-white px-6 py-3 rounded-full shadow-2xl flex items-center gap-3 z-50 border border-emerald-500/30 animate-slide-up">
           <div className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></div>
           <span className="text-[10px] font-black uppercase tracking-widest">তেলাওয়াত চলছে...</span>
           <button onClick={() => { audioRef.current?.pause(); setPlayingId(null); }} className="bg-white/10 hover:bg-white/20 p-1.5 rounded-full transition ml-2">
              <Icons.LogOut size={14} />
           </button>
        </div>
      )}
    </Layout>
  );
};
