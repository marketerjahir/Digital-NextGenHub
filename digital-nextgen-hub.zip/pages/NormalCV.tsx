
import React, { useState } from 'react';
import { Layout, Button, Input } from '../components/Layout';
import { Icons } from '../constants';

interface Experience {
  id: string;
  title: string;
  company: string;
  dateRange: string;
  description: string[];
}

interface Education {
  id: string;
  degree: string;
  institution: string;
  dateRange: string;
}

export const NormalCV: React.FC<{ onBack: () => void }> = ({ onBack }) => {
  const [formData, setFormData] = useState({
    fullName: 'RAHIM AHMED',
    title: 'Marketing Specialist',
    phone: '+880 1712 345678',
    email: 'rahim.ahmed@email.com',
    location: 'Dhaka, Bangladesh',
    profileSummary: 'Dynamic marketing professional with over 5 years of experience in developing and executing successful marketing campaigns. Skilled in digital marketing, market research, and brand management.',
    skills: ['Digital Marketing', 'Social Media Management', 'Market Analysis', 'Content Creation'],
    languages: ['Bengali (Native)', 'English (Fluent)'],
    certifications: ['Google Analytics Certification', 'Social Media Marketing Certificate']
  });

  const [experiences, setExperiences] = useState<Experience[]>([
    {
      id: '1',
      title: 'Senior Marketing Executive',
      company: 'XYZ Company, Dhaka',
      dateRange: 'Jun 2018 - Present',
      description: [
        'Developed and managed multi-channel marketing campaigns.',
        'Conducted market research and competitor analysis.',
        'Increased brand awareness and lead generation.'
      ]
    },
    {
      id: '2',
      title: 'Marketing Officer',
      company: 'ABC Ltd., Dhaka',
      dateRange: 'Jan 2015 - May 2018',
      description: [
        'Assisted in the execution of digital marketing strategies.',
        'Managed social media accounts and content creation.',
        'Coordinated promotional events.'
      ]
    }
  ]);

  const [education, setEducation] = useState<Education[]>([
    { id: '1', degree: 'Master of Business Administration (MBA)', institution: 'University of Dhaka', dateRange: '2016 - 2018' },
    { id: '2', degree: 'Bachelor of Business Administration (BBA)', institution: 'North South University', dateRange: '2011 - 2015' }
  ]);

  const [photo, setPhoto] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);

  const handleInputChange = (field: string, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => setPhoto(reader.result as string);
      reader.readAsDataURL(file);
    }
  };

  const addExperience = () => {
    setExperiences([...experiences, { id: Date.now().toString(), title: '', company: '', dateRange: '', description: [''] }]);
  };

  const updateExperience = (id: string, field: keyof Experience, value: any) => {
    setExperiences(experiences.map(exp => exp.id === id ? { ...exp, [field]: value } : exp));
  };

  const addEducation = () => {
    setEducation([...education, { id: Date.now().toString(), degree: '', institution: '', dateRange: '' }]);
  };

  const updateEducation = (id: string, field: keyof Education, value: any) => {
    setEducation(education.map(edu => edu.id === id ? { ...edu, [field]: value } : edu));
  };

  const handleDownload = async (type: 'pdf' | 'img') => {
    const element = document.getElementById('cv-template-visual');
    const jspdfLib = (window as any).jspdf;
    
    if (element && (window as any).html2canvas && jspdfLib) {
      try {
        setIsProcessing(true);
        element.style.display = 'block';
        element.style.position = 'absolute';
        element.style.left = '-9999px';

        const canvas = await (window as any).html2canvas(element, { 
          useCORS: true, 
          scale: 3, 
          logging: false,
          backgroundColor: '#ffffff'
        });
        
        const imgData = canvas.toDataURL('image/png', 1.0);
        
        if (type === 'pdf') {
          const { jsPDF } = jspdfLib;
          const pdf = new jsPDF('p', 'mm', 'a4');
          const imgWidth = 210; 
          const canvasImgHeight = (canvas.height * imgWidth) / canvas.width;
          pdf.addImage(imgData, 'PNG', 0, 0, imgWidth, canvasImgHeight);
          pdf.save(`CV_${formData.fullName.replace(/\s/g, '_')}.pdf`);
        } else {
          const link = document.createElement('a');
          link.href = imgData;
          link.download = `CV_${formData.fullName.replace(/\s/g, '_')}.png`;
          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link);
        }
        
        element.style.display = 'none';
      } catch (e) {
        console.error(e);
        alert("Failed to generate CV.");
      } finally {
        setIsProcessing(false);
      }
    }
  };

  return (
    <Layout title="Professional Normal CV" onBack={onBack} className="bg-gray-50">
      <div className="p-4 space-y-6 pb-24 overflow-y-auto no-scrollbar">
        {isProcessing && (
          <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-[9999] flex flex-col items-center justify-center text-white p-6 text-center">
             <div className="w-12 h-12 border-4 border-white/20 border-t-white rounded-full animate-spin mb-4"></div>
             <p className="font-bold">Generating Professional CV...</p>
          </div>
        )}

        {/* --- FORM SECTION --- */}
        <div className="space-y-4">
          <div className="bg-white p-5 rounded-2xl shadow-sm border border-brand-100">
            <h3 className="text-xs font-black uppercase text-brand-600 tracking-widest mb-4">Basic Info & Photo</h3>
            <div className="flex gap-4 items-start mb-4">
               <div className="w-24 h-24 bg-gray-100 rounded-xl flex items-center justify-center border-2 border-dashed border-gray-300 overflow-hidden shrink-0">
                  {photo ? <img src={photo} className="w-full h-full object-cover" /> : <Icons.Camera size={32} className="text-gray-400" />}
               </div>
               <label className="flex-1 bg-brand-50 text-brand-700 p-4 rounded-xl text-xs font-bold text-center border border-brand-100 cursor-pointer active:scale-95 transition h-fit self-center">
                  Upload Profile Picture
                  <input type="file" className="hidden" accept="image/*" onChange={handlePhotoUpload} />
               </label>
            </div>
            <div className="space-y-3">
              <Input placeholder="Full Name" value={formData.fullName} onChange={e => handleInputChange('fullName', e.target.value)} />
              <Input placeholder="Professional Title" value={formData.title} onChange={e => handleInputChange('title', e.target.value)} />
            </div>
          </div>

          <div className="bg-white p-5 rounded-2xl shadow-sm border border-brand-100">
            <h3 className="text-xs font-black uppercase text-brand-600 tracking-widest mb-4">Contact & Location</h3>
            <div className="space-y-3">
              <Input placeholder="Phone Number" value={formData.phone} onChange={e => handleInputChange('phone', e.target.value)} />
              <Input placeholder="Email Address" value={formData.email} onChange={e => handleInputChange('email', e.target.value)} />
              <Input placeholder="Location" value={formData.location} onChange={e => handleInputChange('location', e.target.value)} />
            </div>
          </div>

          <div className="bg-white p-5 rounded-2xl shadow-sm border border-brand-100">
            <h3 className="text-xs font-black uppercase text-brand-600 tracking-widest mb-4">Profile Summary</h3>
            <textarea 
              className="w-full p-4 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-brand-500 text-sm h-32"
              placeholder="Write a brief professional summary..."
              value={formData.profileSummary}
              onChange={e => handleInputChange('profileSummary', e.target.value)}
            />
          </div>

          <div className="bg-white p-5 rounded-2xl shadow-sm border border-brand-100 space-y-4">
             <div className="flex justify-between items-center">
                <h3 className="text-xs font-black uppercase text-brand-600 tracking-widest">Experience</h3>
                <button onClick={addExperience} className="text-brand-600 font-bold text-xs">+ Add</button>
             </div>
             {experiences.map((exp, idx) => (
                <div key={exp.id} className="p-4 bg-gray-50 rounded-xl border border-gray-100 space-y-3">
                   <Input placeholder="Job Title" value={exp.title} onChange={e => updateExperience(exp.id, 'title', e.target.value)} />
                   <Input placeholder="Company & City" value={exp.company} onChange={e => updateExperience(exp.id, 'company', e.target.value)} />
                   <Input placeholder="Date Range" value={exp.dateRange} onChange={e => updateExperience(exp.id, 'dateRange', e.target.value)} />
                   <textarea 
                      className="w-full p-3 border border-gray-300 rounded-lg text-xs"
                      placeholder="Bullet points (one per line)"
                      value={exp.description.join('\n')}
                      onChange={e => updateExperience(exp.id, 'description', e.target.value.split('\n'))}
                   />
                </div>
             ))}
          </div>

          <div className="bg-white p-5 rounded-2xl shadow-sm border border-brand-100 space-y-4">
             <div className="flex justify-between items-center">
                <h3 className="text-xs font-black uppercase text-brand-600 tracking-widest">Education</h3>
                <button onClick={addEducation} className="text-brand-600 font-bold text-xs">+ Add</button>
             </div>
             {education.map((edu, idx) => (
                <div key={edu.id} className="p-4 bg-gray-50 rounded-xl border border-gray-100 space-y-2">
                   <Input placeholder="Degree" value={edu.degree} onChange={e => updateEducation(edu.id, 'degree', e.target.value)} />
                   <Input placeholder="Institution" value={edu.institution} onChange={e => updateEducation(edu.id, 'institution', e.target.value)} />
                   <Input placeholder="Date Range" value={edu.dateRange} onChange={e => updateEducation(edu.id, 'dateRange', e.target.value)} />
                </div>
             ))}
          </div>

          <div className="bg-white p-5 rounded-2xl shadow-sm border border-brand-100">
            <h3 className="text-xs font-black uppercase text-brand-600 tracking-widest mb-4">Skills & Languages (Comma Separated)</h3>
            <div className="space-y-3">
               <Input placeholder="Skills (e.g. Design, Coding)" value={formData.skills.join(', ')} onChange={e => handleInputChange('skills', e.target.value.split(', '))} />
               <Input placeholder="Languages (e.g. Bengali, English)" value={formData.languages.join(', ')} onChange={e => handleInputChange('languages', e.target.value.split(', '))} />
               <Input placeholder="Certifications" value={formData.certifications.join(', ')} onChange={e => handleInputChange('certifications', e.target.value.split(', '))} />
            </div>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3">
           <Button onClick={() => handleDownload('pdf')} variant="secondary" className="py-4 font-black uppercase text-[10px] tracking-widest flex items-center justify-center gap-2">
              <Icons.Download size={14} /> Download PDF CV
           </Button>
           <Button onClick={() => handleDownload('img')} variant="primary" className="py-4 font-black uppercase text-[10px] tracking-widest flex items-center justify-center gap-2">
              <Icons.Camera size={14} /> Download Image CV
           </Button>
        </div>

        {/* --- HIGH FIDELITY PRINT TEMPLATE (Hidden) --- */}
        <div id="cv-template-visual" style={{ display: 'none', width: '800px', backgroundColor: 'white', color: '#333' }} className="font-sans">
           {/* Header Area */}
           <div className="p-12 pb-6 flex items-start gap-10">
              {photo && (
                <div className="w-[180px] h-[180px] shrink-0 border-4 border-gray-100 shadow-sm overflow-hidden">
                   <img src={photo} className="w-full h-full object-cover" />
                </div>
              )}
              <div className="flex-1 pt-4">
                 <h1 className="text-[48px] font-bold text-[#003B73] leading-tight mb-1 uppercase tracking-tight">{formData.fullName}</h1>
                 <p className="text-[24px] text-gray-500 font-medium mb-6">{formData.title}</p>
                 <div className="h-[2px] w-full bg-[#003B73] mb-6"></div>
                 
                 <div className="grid grid-cols-1 gap-3 text-[16px] text-gray-700 font-bold">
                    <div className="flex items-center gap-3">
                       <span className="text-[#003B73]"><Icons.Activity size={18} /></span> {formData.phone}
                    </div>
                    <div className="flex items-center gap-3">
                       <span className="text-[#003B73]"><Icons.FileText size={18} /></span> {formData.email}
                    </div>
                    <div className="flex items-center gap-3">
                       <span className="text-[#003B73]"><Icons.TrendingUp size={18} /></span> {formData.location}
                    </div>
                 </div>
              </div>
           </div>

           <div className="px-12 pb-16 flex gap-10 mt-8">
              {/* Sidebar Left */}
              <div className="w-[280px] space-y-10">
                 {/* Profile Section */}
                 <div>
                    <h2 className="bg-[#003B73] text-white py-1 px-4 text-[18px] font-bold uppercase tracking-wider mb-4">Profile</h2>
                    <p className="text-[14px] leading-relaxed text-gray-700 text-justify font-medium">{formData.profileSummary}</p>
                 </div>

                 {/* Skills Section */}
                 <div>
                    <h2 className="bg-[#003B73] text-white py-1 px-4 text-[18px] font-bold uppercase tracking-wider mb-4">Skills</h2>
                    <ul className="space-y-2 pl-2">
                       {formData.skills.map((s, i) => (
                          <li key={i} className="flex items-center gap-3 text-[14px] font-bold text-gray-700">
                             <span className="w-1.5 h-1.5 bg-[#003B73] rounded-full"></span> {s}
                          </li>
                       ))}
                    </ul>
                 </div>

                 {/* Languages Section */}
                 <div>
                    <h2 className="bg-[#003B73] text-white py-1 px-4 text-[18px] font-bold uppercase tracking-wider mb-4">Languages</h2>
                    <ul className="space-y-2 pl-2">
                       {formData.languages.map((l, i) => (
                          <li key={i} className="flex items-center gap-3 text-[14px] font-bold text-gray-700">
                             <span className="w-1.5 h-1.5 bg-[#003B73] rounded-full"></span> {l}
                          </li>
                       ))}
                    </ul>
                 </div>
              </div>

              {/* Main Body Right */}
              <div className="flex-1 space-y-10">
                 {/* Experience Section */}
                 <div>
                    <h2 className="bg-gradient-to-r from-[#003B73] to-white text-white py-1 px-4 text-[18px] font-bold uppercase tracking-wider mb-6">Experience</h2>
                    <div className="space-y-8">
                       {experiences.map(exp => (
                          <div key={exp.id}>
                             <div className="flex justify-between items-start mb-1">
                                <h3 className="text-[18px] font-bold text-[#003B73]">{exp.title}</h3>
                                <span className="text-[13px] text-gray-500 font-bold whitespace-nowrap">{exp.dateRange}</span>
                             </div>
                             <p className="text-[15px] font-bold text-gray-600 mb-3">{exp.company}</p>
                             <ul className="space-y-2 pl-4">
                                {exp.description.map((d, i) => d.trim() && (
                                   <li key={i} className="text-[14px] text-gray-700 leading-relaxed font-medium relative">
                                      <span className="absolute -left-4 top-2 w-1.5 h-1.5 bg-[#003B73] rounded-full"></span> {d}
                                   </li>
                                ))}
                             </ul>
                          </div>
                       ))}
                    </div>
                 </div>

                 {/* Education Section */}
                 <div>
                    <h2 className="bg-gradient-to-r from-[#003B73] to-white text-white py-1 px-4 text-[18px] font-bold uppercase tracking-wider mb-6">Education</h2>
                    <div className="space-y-6">
                       {education.map(edu => (
                          <div key={edu.id} className="flex justify-between items-start">
                             <div>
                                <h3 className="text-[16px] font-bold text-[#003B73]">{edu.degree}</h3>
                                <p className="text-[14px] font-bold text-gray-600">{edu.institution}</p>
                             </div>
                             <span className="text-[13px] text-gray-500 font-bold whitespace-nowrap">{edu.dateRange}</span>
                          </div>
                       ))}
                    </div>
                 </div>

                 {/* Certifications Section */}
                 <div>
                    <h2 className="bg-gradient-to-r from-[#003B73] to-white text-white py-1 px-4 text-[18px] font-bold uppercase tracking-wider mb-6">Certifications</h2>
                    <ul className="space-y-3">
                       {formData.certifications.map((c, i) => (
                          <li key={i} className="flex items-center gap-3 text-[14px] font-bold text-gray-700">
                             <span className="w-1.5 h-1.5 bg-[#003B73] rounded-full"></span> {c}
                          </li>
                       ))}
                    </ul>
                 </div>
              </div>
           </div>

           {/* Verify footer padding */}
           <div className="h-10"></div>
        </div>
      </div>
    </Layout>
  );
};
