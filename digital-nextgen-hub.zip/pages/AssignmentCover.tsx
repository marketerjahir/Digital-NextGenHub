
import React, { useState, useEffect } from 'react';
import { Layout, Button, Input } from '../components/Layout';
import { Icons } from '../constants';
import { StorageService } from '../services/storage';
import { User } from '../types';

export const AssignmentCover: React.FC<{ user: User, onBack: () => void }> = ({ user, onBack }) => {
  const [formData, setFormData] = useState({
    university: '',
    address: '',
    department: '',
    courseTitle: '',
    courseCode: '',
    assignmentNo: '',
    studentName: user.fullName, // Auto-populated
    studentId: '',
    studentBatch: '',
    teacherName: '',
    teacherDesignation: '',
    subDate: ''
  });

  const [logo, setLogo] = useState<string | null>(null);
  const [history, setHistory] = useState<Record<string, string[]>>({});
  const [isProcessing, setIsProcessing] = useState(false);

  useEffect(() => {
    const fields = ['university', 'address', 'department', 'courseTitle', 'courseCode', 'assignmentNo', 'studentId', 'studentBatch', 'teacherName', 'teacherDesignation', 'subDate'];
    const histData: Record<string, string[]> = {};
    fields.forEach(f => {
      const fieldHistory = StorageService.getAcademicHistory(f);
      histData[f] = fieldHistory;
    });

    // Auto-fill persistence
    setFormData(prev => ({
      ...prev,
      university: histData.university?.[histData.university.length - 1] || 'Uttara University',
      address: histData.address?.[histData.address.length - 1] || 'Holding 77, Beribadh Road, Turag, Uttara, Dhaka 1230, Bangladesh.',
      department: histData.department?.[histData.department.length - 1] || 'Civil Engineering',
      studentName: user.fullName, // Force locked name
      studentId: histData.studentId?.[histData.studentId.length - 1] || '',
      studentBatch: histData.studentBatch?.[histData.studentBatch.length - 1] || ''
    }));

    setHistory(histData);
    setLogo(StorageService.getAcademicLogo());
  }, [user.fullName]);

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64 = reader.result as string;
        setLogo(base64);
        StorageService.saveAcademicLogo(base64);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleDownloadPDF = async () => {
    const element = document.getElementById('assignment-report-template');
    const jspdfLib = (window as any).jspdf;
    
    if (element && (window as any).html2canvas && jspdfLib) {
      try {
        setIsProcessing(true);
        // Save to history
        Object.entries(formData).forEach(([key, value]) => {
          if (key !== 'studentName') {
            StorageService.saveAcademicEntry(key, value as string);
          }
        });
        
        // Refresh local history
        const fields = Object.keys(formData);
        const histData: Record<string, string[]> = {};
        fields.forEach(f => {
          histData[f] = StorageService.getAcademicHistory(f);
        });
        setHistory(histData);

        element.style.display = 'block';
        element.style.position = 'absolute';
        element.style.left = '-9999px';

        const canvas = await (window as any).html2canvas(element, { 
          useCORS: true, 
          scale: 4, 
          logging: false,
          allowTaint: true,
          backgroundColor: '#ffffff'
        });
        
        const imgData = canvas.toDataURL('image/png', 1.0);
        const { jsPDF } = jspdfLib;
        
        const pdf = new jsPDF('p', 'mm', 'a4');
        const imgWidth = 210; 
        const canvasImgHeight = (canvas.height * imgWidth) / canvas.width;
        
        pdf.addImage(imgData, 'PNG', 0, 0, imgWidth, canvasImgHeight, undefined, 'FAST');
        pdf.save(`Assignment_Cover_${formData.assignmentNo || 'Page'}.pdf`);
        
        element.style.display = 'none';
      } catch (e) {
        console.error("PDF Error:", e);
        alert("PDF Generation Failed.");
      } finally {
        setIsProcessing(false);
      }
    }
  };

  return (
    <Layout title="Assignment Cover Entry" onBack={onBack} className="bg-gray-50">
      <div className="p-4 space-y-6 pb-24 no-scrollbar overflow-y-auto">
        {isProcessing && (
          <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-[9999] flex flex-col items-center justify-center text-white p-6 text-center">
             <div className="w-12 h-12 border-4 border-white/20 border-t-white rounded-full animate-spin mb-4"></div>
             <p className="font-bold">Generating Assignment Cover...</p>
          </div>
        )}

        <div className="space-y-4">
          {/* ... Groups same as LabReport ... */}
          <div className="bg-white p-5 rounded-2xl shadow-sm border border-brand-100">
            <h3 className="text-[10px] font-black uppercase text-brand-600 tracking-widest mb-4">University & Dept Settings</h3>
            <div className="space-y-3">
              <div className="flex items-center gap-4 mb-2">
                 <div className="w-16 h-16 bg-gray-100 rounded-lg flex items-center justify-center border-2 border-dashed border-gray-300 overflow-hidden shrink-0 text-gray-400">
                    {logo ? (
                      <img src={logo} alt="Logo" className="w-full h-full object-contain" />
                    ) : (
                      <Icons.Camera size={24} />
                    )}
                 </div>
                 <div className="flex-1">
                    <label className="block w-full bg-brand-50 text-brand-700 px-4 py-2 rounded-lg text-xs font-bold text-center border border-brand-100 cursor-pointer active:scale-95 transition">
                       {logo ? 'Change Logo' : 'Upload Logo'}
                       <input type="file" className="hidden" accept="image/*" onChange={handleLogoUpload} />
                    </label>
                    {logo && (
                      <button onClick={() => { setLogo(null); StorageService.saveAcademicLogo(null); }} className="block w-full text-center text-[10px] text-red-500 font-bold mt-2 underline">Remove Logo</button>
                    )}
                 </div>
              </div>
              <div className="relative">
                <Input list="list-univ" value={formData.university} onChange={e => handleInputChange('university', e.target.value)} placeholder="University Name" />
                <datalist id="list-univ">{history.university?.map((item, idx) => <option key={idx} value={item} />)}</datalist>
              </div>
              <div className="relative">
                <Input list="list-addr" value={formData.address} onChange={e => handleInputChange('address', e.target.value)} placeholder="Full Address" />
                <datalist id="list-addr">{history.address?.map((item, idx) => <option key={idx} value={item} />)}</datalist>
              </div>
              <div className="relative">
                <Input list="list-dept" value={formData.department} onChange={e => handleInputChange('department', e.target.value)} placeholder="Department Name (e.g. Civil Engineering)" />
                <datalist id="list-dept">{history.department?.map((item, idx) => <option key={idx} value={item} />)}</datalist>
              </div>
            </div>
          </div>

          <div className="bg-white p-5 rounded-2xl shadow-sm border border-brand-100">
            <h3 className="text-[10px] font-black uppercase text-brand-600 tracking-widest mb-4">Course Details</h3>
            <div className="space-y-3">
              <div className="relative">
                <Input list="list-assign-courseTitle" value={formData.courseTitle} onChange={e => handleInputChange('courseTitle', e.target.value)} placeholder="Course Title" />
                <datalist id="list-assign-courseTitle">{history.courseTitle?.map((item, idx) => <option key={idx} value={item} />)}</datalist>
              </div>
              <div className="relative">
                <Input list="list-assign-courseCode" value={formData.courseCode} onChange={e => handleInputChange('courseCode', e.target.value)} placeholder="Course Code" />
                <datalist id="list-assign-courseCode">{history.courseCode?.map((item, idx) => <option key={idx} value={item} />)}</datalist>
              </div>
              <div className="relative">
                <Input list="list-assign-assignmentNo" value={formData.assignmentNo} onChange={e => handleInputChange('assignmentNo', e.target.value)} placeholder="Assignment No." />
                <datalist id="list-assign-assignmentNo">{history.assignmentNo?.map((item, idx) => <option key={idx} value={item} />)}</datalist>
              </div>
            </div>
          </div>

          <div className="bg-white p-5 rounded-2xl shadow-sm border border-brand-100">
            <h3 className="text-[10px] font-black uppercase text-brand-600 tracking-widest mb-4">Student Info</h3>
            <div className="space-y-3">
              <div className="relative">
                <label className="text-[9px] font-bold text-gray-400 uppercase ml-1">Student Name (Locked to Profile)</label>
                <Input 
                  value={formData.studentName} 
                  readOnly 
                  className="bg-gray-100 cursor-not-allowed font-bold text-gray-600"
                  placeholder="Student Name" 
                />
              </div>
              <div className="relative">
                <Input list="list-assign-studentId" value={formData.studentId} onChange={e => handleInputChange('studentId', e.target.value)} placeholder="Student ID" />
                <datalist id="list-assign-studentId">{history.studentId?.map((item, idx) => <option key={idx} value={item} />)}</datalist>
              </div>
              <div className="relative">
                <Input list="list-assign-studentBatch" value={formData.studentBatch} onChange={e => handleInputChange('studentBatch', e.target.value)} placeholder="Student Batch" />
                <datalist id="list-assign-studentBatch">{history.studentBatch?.map((item, idx) => <option key={idx} value={item} />)}</datalist>
              </div>
            </div>
          </div>

          <div className="bg-white p-5 rounded-2xl shadow-sm border border-brand-100">
            <h3 className="text-[10px] font-black uppercase text-brand-600 tracking-widest mb-4">Teacher Info</h3>
            <div className="space-y-3">
              <div className="relative">
                <Input list="list-assign-teacherName" value={formData.teacherName} onChange={e => handleInputChange('teacherName', e.target.value)} placeholder="Teacher Name" />
                <datalist id="list-assign-teacherName">{history.teacherName?.map((item, idx) => <option key={idx} value={item} />)}</datalist>
              </div>
              <div className="relative">
                <Input list="list-assign-teacherDesignation" value={formData.teacherDesignation} onChange={e => handleInputChange('teacherDesignation', e.target.value)} placeholder="Teacher Designation" />
                <datalist id="list-assign-teacherDesignation">{history.teacherDesignation?.map((item, idx) => <option key={idx} value={item} />)}</datalist>
              </div>
            </div>
          </div>

          <div className="bg-white p-5 rounded-2xl shadow-sm border border-brand-100">
            <h3 className="text-[10px] font-black uppercase text-brand-600 tracking-widest mb-4">Timeline</h3>
            <div className="space-y-3">
              <Input value={formData.subDate} onChange={e => handleInputChange('subDate', e.target.value)} placeholder="Submission Date" />
            </div>
          </div>
        </div>

        <Button onClick={handleDownloadPDF} className="py-4 font-black uppercase tracking-widest text-xs flex items-center justify-center gap-2">
           <Icons.Download size={18} /> Download High Quality PDF
        </Button>

        {/* --- ASSIGNMENT PRINT TEMPLATE --- */}
        <div id="assignment-report-template" style={{ display: 'none', fontFamily: '"Times New Roman", Times, serif' }} className="w-[794px] min-h-[1123px] bg-white p-[50px] relative text-black leading-tight border-[1.5px] border-black">
           
           <div className={`flex items-start w-full mt-4 relative ${logo ? '' : 'flex-col items-center text-center'}`}>
              {logo && (
                <div className="w-[140px] shrink-0 mr-8">
                   <img src={logo} alt="Logo" className="w-full h-auto max-h-[150px] object-contain" />
                </div>
              )}
              <div className={`flex-1 ${logo ? 'pr-[140px] text-center' : 'w-full'}`}>
                 <h1 className="text-[32px] font-bold leading-tight">Department of {formData.department || '...'}</h1>
                 <h2 className="text-[38px] font-bold leading-tight mt-1">{formData.university || '...'}</h2>
                 <p className="text-[17px] font-medium mt-2 max-w-[500px] mx-auto opacity-95">{formData.address || '...'}</p>
              </div>
           </div>

           <div className="mt-28 space-y-4 pl-12">
              <div className="grid grid-cols-[180px_30px_1fr] items-center text-[24px] font-bold">
                 <span>Course Title</span>
                 <span>:</span>
                 <span className="uppercase">{formData.courseTitle}</span>
              </div>
              <div className="grid grid-cols-[180px_30px_1fr] items-center text-[24px] font-bold">
                 <span>Course Code</span>
                 <span>:</span>
                 <span className="uppercase">{formData.courseCode}</span>
              </div>
              <div className="grid grid-cols-[180px_30px_1fr] items-center text-[24px] font-bold">
                 <span>Assignment No</span>
                 <span>:</span>
                 <span className="uppercase">{formData.assignmentNo}</span>
              </div>
           </div>

           <div className="mt-16 w-full border border-black overflow-hidden">
              <div className="flex w-full">
                 <div className="flex-1 border-r border-black p-6 space-y-4">
                    <h3 className="text-[22px] font-bold border-b border-black w-fit pb-1 pr-2">Submitted by :</h3>
                    <div className="space-y-1 text-[20px] font-medium leading-relaxed">
                       <p className="font-bold">{formData.studentName}</p>
                       <p>ID No : {formData.studentId}</p>
                       <p>Batch : {formData.studentBatch}</p>
                       <p>Dept. of {formData.department}</p>
                       <p>{formData.university}</p>
                    </div>
                 </div>

                 <div className="flex-1 p-6 space-y-4">
                    <h3 className="text-[22px] font-bold border-b border-black w-fit pb-1 pr-2">Submitted To :</h3>
                    <div className="space-y-1 text-[20px] font-medium leading-relaxed">
                       <p className="font-bold">{formData.teacherName}</p>
                       <p>{formData.teacherDesignation}</p>
                       <p>Dept. of {formData.department}</p>
                       <p>{formData.university}</p>
                    </div>
                 </div>
              </div>
           </div>

           <div className="mt-20">
              <p className="text-[24px] font-bold">Date of submission: {formData.subDate}</p>
           </div>

        </div>
      </div>
    </Layout>
  );
};
