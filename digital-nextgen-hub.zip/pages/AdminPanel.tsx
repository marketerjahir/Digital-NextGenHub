import React, { useState, useEffect, useRef, useMemo } from 'react';
import { Icons } from '../constants';
import { StorageService } from '../services/storage';
import { User, Screen, Transaction, TransactionType } from '../types';
import { Button, Input } from '../components/Layout';

interface AdminPanelProps {
  currentScreen: Screen;
  setScreen: (screen: Screen) => void;
}

type AdminSubScreen = 'OVERVIEW' | 'USER_LIST' | 'USER_AUDIT' | 'ALL_TRANSACTIONS' | 'AI_INSIGHTS' | 'LIVE_LOGS';

export const AdminPanel: React.FC<AdminPanelProps> = ({ currentScreen, setScreen }) => {
  const [subScreen, setSubScreen] = useState<AdminSubScreen>('OVERVIEW');
  const [adminIdInput, setAdminIdInput] = useState('');
  const [pass1Input, setPass1Input] = useState('');
  const [pass2Input, setPass2Input] = useState('');
  const [loginError, setLoginError] = useState('');
  const [users, setUsers] = useState<User[]>([]);
  const [allGlobalTxs, setAllGlobalTxs] = useState<Transaction[]>([]);
  const [globalLogs, setGlobalLogs] = useState<any[]>([]);
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  
  const [editEmail, setEditEmail] = useState('');
  const [editMobile, setEditMobile] = useState('');
  const [editPassword, setEditPassword] = useState('');

  const refreshCloudData = () => {
    setIsProcessing(true);
    if ((window as any).google?.script?.run) {
      (window as any).google.script.run
        .withSuccessHandler((data: any) => {
          setUsers(data.users);
          setAllGlobalTxs(data.transactions);
          setGlobalLogs(data.logs || []);
          setIsProcessing(false);
        })
        .getAdminData();
    } else {
      setUsers(StorageService.getUsers());
      setIsProcessing(false);
    }
  };

  useEffect(() => {
    if (currentScreen === 'ADMIN_DASHBOARD') {
      refreshCloudData();
    }
  }, [currentScreen]);

  useEffect(() => {
    if (selectedUser) {
      setEditEmail(selectedUser.email);
      setEditMobile(selectedUser.mobile);
      setEditPassword(selectedUser.password);
    }
  }, [selectedUser]);

  const handleAdminLogin = () => {
    const creds = StorageService.getAdminCreds();
    if (adminIdInput === creds.id && pass1Input === creds.pass1 && pass2Input === creds.pass2) {
      setScreen('ADMIN_DASHBOARD');
      setSubScreen('OVERVIEW');
    } else {
      setLoginError('Security Verification Failed.');
    }
  };

  const handleUpdateUserData = () => {
    if (!selectedUser) return;
    const updatedUser = { ...selectedUser, email: editEmail, mobile: editMobile, password: editPassword };
    setIsProcessing(true);
    if ((window as any).google?.script?.run) {
      (window as any).google.script.run
        .withSuccessHandler(() => {
          refreshCloudData();
          alert("User Updated Successfully");
        })
        .syncUserToCloud(updatedUser);
    }
  };

  // AI & HEURISTIC ENGINE
  const aiInsights = useMemo(() => {
    if (users.length === 0) return null;
    
    // Top User by volume
    const userVolumes: Record<string, number> = {};
    allGlobalTxs.forEach(t => {
       userVolumes[t.userId] = (userVolumes[t.userId] || 0) + t.amount;
    });
    
    const topUserId = Object.keys(userVolumes).reduce((a, b) => userVolumes[a] > userVolumes[b] ? a : b, '');
    const topUser = users.find(u => u.id === topUserId);

    // Growth Metrics
    const today = new Date().toISOString().split('T')[0];
    const txToday = allGlobalTxs.filter(t => t.dateStr === today).length;
    const regToday = users.filter(u => u.registeredAt?.startsWith(today)).length;

    return {
      topUser: topUser?.fullName || "None",
      topVolume: userVolumes[topUserId] || 0,
      velocity: txToday > 5 ? "High Activity" : "Normal",
      growth: regToday > 0 ? `+${regToday} New Users` : "Stable",
      risk: allGlobalTxs.some(t => t.amount > 50000) ? "Large TRX Detected" : "Low Risk"
    };
  }, [users, allGlobalTxs]);

  if (currentScreen === 'ADMIN_LOGIN') {
    return (
      <div className="h-[100dvh] w-full flex items-center justify-center bg-brand-50 p-6">
        <div className="w-full max-w-sm text-center space-y-6">
          <div onClick={() => setScreen('LOGIN')} className="w-20 h-20 bg-brand-600 rounded-3xl flex items-center justify-center mx-auto text-white shadow-xl cursor-pointer">
            <Icons.Lock size={40} />
          </div>
          <h1 className="text-2xl font-black text-brand-900 uppercase">Master Admin</h1>
          <div className="bg-white p-8 rounded-[2rem] shadow-xl space-y-4 border border-brand-100">
             <input type="text" value={adminIdInput} onChange={e => setAdminIdInput(e.target.value)} placeholder="ADMIN ID" className="w-full bg-slate-50 rounded-xl px-4 py-3 text-sm font-bold border-none focus:ring-2 focus:ring-brand-200 outline-none" />
             <input type="password" value={pass1Input} onChange={e => setPass1Input(e.target.value)} placeholder="PASS 1" className="w-full bg-slate-50 rounded-xl px-4 py-3 text-sm font-bold border-none focus:ring-2 focus:ring-brand-200 outline-none" />
             <input type="password" value={pass2Input} onChange={e => setPass2Input(e.target.value)} placeholder="PASS 2" className="w-full bg-slate-50 rounded-xl px-4 py-3 text-sm font-bold border-none focus:ring-2 focus:ring-brand-200 outline-none" />
             {loginError && <p className="text-red-500 text-xs font-bold">{loginError}</p>}
             <button onClick={handleAdminLogin} className="w-full bg-brand-600 text-white font-black py-4 rounded-xl shadow-lg active:scale-95 transition-all">AUTHORIZE</button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="h-[100dvh] w-full flex justify-center bg-slate-50 overflow-hidden">
      <div className="w-full max-w-md h-full flex flex-col bg-white shadow-2xl">
        {/* Header */}
        <div className="bg-brand-700 p-6 text-white shrink-0">
           <div className="flex justify-between items-center">
              <div className="flex items-center gap-3">
                 <button onClick={() => subScreen === 'OVERVIEW' ? setScreen('ADMIN_LOGIN') : setSubScreen('OVERVIEW')} className="bg-white/20 p-2 rounded-xl active:scale-90 transition-transform"><Icons.ArrowLeft size={18} /></button>
                 <div><h1 className="text-lg font-black tracking-tighter uppercase leading-none">Admin.IO</h1><p className="text-[8px] opacity-60 font-bold uppercase tracking-widest mt-1">Real-time Terminal</p></div>
              </div>
              <button onClick={refreshCloudData} className={`bg-white/20 p-2 rounded-xl ${isProcessing ? 'animate-spin' : 'active:scale-90'} transition-all`}><Icons.Activity size={20} /></button>
           </div>
        </div>

        {/* Sub-Nav */}
        <div className="bg-white border-b flex overflow-x-auto no-scrollbar shrink-0 px-4 py-2 gap-2">
           <button onClick={() => setSubScreen('OVERVIEW')} className={`px-4 py-2 rounded-full text-[10px] font-black uppercase whitespace-nowrap ${subScreen === 'OVERVIEW' ? 'bg-brand-600 text-white' : 'bg-brand-50 text-brand-600'}`}>Overview</button>
           <button onClick={() => setSubScreen('USER_LIST')} className={`px-4 py-2 rounded-full text-[10px] font-black uppercase whitespace-nowrap ${subScreen === 'USER_LIST' ? 'bg-brand-600 text-white' : 'bg-brand-50 text-brand-600'}`}>Users</button>
           <button onClick={() => setSubScreen('AI_INSIGHTS')} className={`px-4 py-2 rounded-full text-[10px] font-black uppercase whitespace-nowrap ${subScreen === 'AI_INSIGHTS' ? 'bg-indigo-600 text-white' : 'bg-indigo-50 text-indigo-600'}`}>AI Insights</button>
           <button onClick={() => setSubScreen('LIVE_LOGS')} className={`px-4 py-2 rounded-full text-[10px] font-black uppercase whitespace-nowrap ${subScreen === 'LIVE_LOGS' ? 'bg-emerald-600 text-white' : 'bg-emerald-50 text-emerald-600'}`}>Live Logs</button>
        </div>

        <div className="flex-1 overflow-y-auto no-scrollbar p-6 space-y-6">
          {subScreen === 'OVERVIEW' && (
            <div className="space-y-6 animate-fade-in">
               <div className="grid grid-cols-2 gap-4">
                  <div className="bg-white p-5 rounded-3xl shadow-sm border border-brand-50"><p className="text-[9px] font-black text-slate-400 uppercase">System Nodes</p><p className="text-2xl font-black text-brand-600">{users.length}</p></div>
                  <div className="bg-brand-600 p-5 rounded-3xl shadow-lg text-white"><p className="text-[9px] font-black opacity-60 uppercase">Volume (All)</p><p className="text-xl font-black">৳{allGlobalTxs.reduce((s,t)=>s+t.amount,0).toFixed(0)}</p></div>
               </div>
               
               <div className="bg-indigo-50 p-6 rounded-3xl border border-indigo-100">
                  <p className="text-[10px] font-black uppercase text-indigo-600 mb-3 flex items-center gap-2"><Icons.Brain size={14} /> Quick Intelligence</p>
                  <div className="grid grid-cols-2 gap-3 text-[10px] font-bold text-indigo-900">
                     <div className="bg-white p-3 rounded-xl border border-indigo-100">Top: {aiInsights?.topUser}</div>
                     <div className="bg-white p-3 rounded-xl border border-indigo-100">Trend: {aiInsights?.velocity}</div>
                  </div>
               </div>
               
               <Button onClick={() => setSubScreen('USER_LIST')} variant="outline">Browse User Directory</Button>
               <Button onClick={() => setSubScreen('ALL_TRANSACTIONS')}>Audit Master Stream</Button>
            </div>
          )}

          {subScreen === 'USER_LIST' && (
            <div className="space-y-4 animate-slide-up">
               <input placeholder="Search Node Name or ID..." value={searchQuery} onChange={e => setSearchQuery(e.target.value)} className="w-full bg-white border border-brand-100 rounded-2xl px-6 py-4 text-sm font-bold focus:ring-2 focus:ring-brand-100 outline-none" />
               {users.filter(u => u.fullName.toLowerCase().includes(searchQuery.toLowerCase()) || u.id.toLowerCase().includes(searchQuery.toLowerCase())).map(u => (
                  <button key={u.id} onClick={() => { setSelectedUser(u); setSubScreen('USER_AUDIT'); }} className="w-full bg-white p-4 rounded-2xl border border-slate-100 flex items-center justify-between active:bg-slate-50 transition">
                     <div className="flex items-center gap-4 text-left">
                        <div className="w-10 h-10 bg-brand-600 text-white rounded-xl flex items-center justify-center font-black">{u.fullName.charAt(0)}</div>
                        <div><p className="font-black text-slate-800 text-sm">{u.fullName}</p><p className="text-[9px] text-brand-400 font-bold uppercase">{u.id}</p></div>
                     </div>
                     <Icons.ArrowLeft className="rotate-180 text-slate-300" size={16} />
                  </button>
               ))}
            </div>
          )}

          {subScreen === 'AI_INSIGHTS' && (
             <div className="space-y-5 animate-slide-up">
                <div className="bg-gradient-to-br from-indigo-600 to-purple-700 p-6 rounded-[2.5rem] text-white shadow-xl relative overflow-hidden">
                   <div className="absolute top-0 right-0 p-4 opacity-10"><Icons.Brain size={150} /></div>
                   <h2 className="text-xl font-black uppercase tracking-tighter mb-4">Intelligence Report</h2>
                   <div className="space-y-4 relative z-10">
                      <div className="flex justify-between border-b border-white/10 pb-2"><span className="text-xs opacity-70">Power User</span><span className="text-sm font-black">{aiInsights?.topUser}</span></div>
                      <div className="flex justify-between border-b border-white/10 pb-2"><span className="text-xs opacity-70">Volume Growth</span><span className="text-sm font-black">{aiInsights?.growth}</span></div>
                      <div className="flex justify-between border-b border-white/10 pb-2"><span className="text-xs opacity-70">Security Status</span><span className={`text-sm font-black ${aiInsights?.risk.includes('Large') ? 'text-yellow-300' : 'text-green-300'}`}>{aiInsights?.risk}</span></div>
                      <div className="flex justify-between border-b border-white/10 pb-2"><span className="text-xs opacity-70">Network Velocity</span><span className="text-sm font-black">{aiInsights?.velocity}</span></div>
                   </div>
                </div>
                
                <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm">
                   <h3 className="text-[10px] font-black uppercase text-slate-400 mb-4 tracking-widest">Recommended Actions</h3>
                   <ul className="space-y-3">
                      <li className="flex gap-3 items-center text-xs font-bold text-slate-700 bg-slate-50 p-3 rounded-xl">
                         <div className="w-2 h-2 rounded-full bg-brand-500"></div> Monitor {aiInsights?.topUser} for potential business scaling.
                      </li>
                      <li className="flex gap-3 items-center text-xs font-bold text-slate-700 bg-slate-50 p-3 rounded-xl">
                         <div className="w-2 h-2 rounded-full bg-indigo-500"></div> System usage is {aiInsights?.velocity.toLowerCase()}.
                      </li>
                   </ul>
                </div>
             </div>
          )}

          {subScreen === 'LIVE_LOGS' && (
             <div className="space-y-4 animate-slide-up">
                <div className="flex justify-between items-center px-2">
                   <h3 className="text-xs font-black uppercase text-emerald-600 tracking-widest">Global Live Activity</h3>
                   <span className="text-[8px] bg-emerald-100 text-emerald-600 px-2 py-1 rounded-full font-bold">LIVE FEED</span>
                </div>
                <div className="bg-slate-900 rounded-3xl p-4 overflow-hidden border border-slate-800 divide-y divide-slate-800 shadow-2xl">
                   {globalLogs.length === 0 ? <p className="p-10 text-center text-slate-500 text-xs italic">Waiting for activity...</p> :
                      globalLogs.map((log, i) => (
                         <div key={i} className="py-3 px-1 flex flex-col gap-1">
                            <div className="flex justify-between items-center">
                               <span className={`text-[8px] font-black uppercase px-1.5 py-0.5 rounded ${log.type === 'Login' ? 'bg-blue-900 text-blue-300' : (log.type === 'Transaction' ? 'bg-emerald-900 text-emerald-300' : 'bg-indigo-900 text-indigo-300')}`}>{log.type}</span>
                               <span className="text-[8px] text-slate-500 font-mono">{new Date(log.timestamp).toLocaleTimeString()}</span>
                            </div>
                            <p className="text-[11px] font-bold text-slate-200 leading-tight">{log.detail}</p>
                         </div>
                      ))}
                </div>
             </div>
          )}

          {subScreen === 'USER_AUDIT' && selectedUser && (
            <div className="space-y-6 animate-slide-up pb-10">
               <div className="bg-white p-6 rounded-3xl shadow-sm border border-brand-50 space-y-4">
                  <div className="flex items-center gap-4 border-b pb-4">
                     <div className="w-16 h-16 bg-brand-50 text-brand-600 flex items-center justify-center text-2xl font-black rounded-2xl shadow-inner">{selectedUser.fullName.charAt(0)}</div>
                     <div className="text-left"><h2 className="font-black text-slate-800">{selectedUser.fullName}</h2><p className="text-xs text-brand-400 font-bold uppercase tracking-widest">ID: {selectedUser.id}</p></div>
                  </div>
                  <div className="space-y-3">
                     <Input value={editEmail} onChange={e => setEditEmail(e.target.value)} placeholder="Email" />
                     <Input value={editMobile} onChange={e => setEditMobile(e.target.value)} placeholder="Mobile" maxLength={11} />
                     <Input value={editPassword} onChange={e => setEditPassword(e.target.value)} placeholder="Password" />
                     <Button onClick={handleUpdateUserData}>Commit Changes</Button>
                     <button onClick={() => { if(window.confirm("Purge Node?")) {(window as any).google?.script?.run?.withSuccessHandler(refreshCloudData).deleteUserGlobally(selectedUser.id); setSubScreen('USER_LIST'); }}} className="w-full py-3 text-red-500 font-black text-[10px] uppercase tracking-widest border border-red-50 rounded-xl active:bg-red-50 transition-colors">Terminate Node Access</button>
                  </div>
               </div>
            </div>
          )}

          {subScreen === 'ALL_TRANSACTIONS' && (
             <div className="space-y-4 animate-slide-up">
                <div className="bg-white rounded-3xl border border-brand-50 overflow-hidden divide-y divide-slate-50 shadow-sm">
                   {allGlobalTxs.sort((a,b) => b.timestamp.localeCompare(a.timestamp)).map(tx => (
                      <div key={tx.id} className="p-4 flex justify-between items-center active:bg-slate-50 transition">
                         <div className="text-left"><p className="text-xs font-black text-slate-800">{tx.type} <span className="text-[8px] text-brand-400 font-bold">@{tx.userId}</span></p><p className="text-[8px] text-slate-400 font-bold uppercase">{new Date(tx.timestamp).toLocaleString()}</p></div>
                         <p className="text-sm font-black text-brand-600">৳{tx.amount}</p>
                      </div>
                   ))}
                </div>
             </div>
          )}
        </div>
      </div>
    </div>
  );
};
