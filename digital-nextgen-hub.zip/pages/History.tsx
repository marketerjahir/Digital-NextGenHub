
import React, { useState, useMemo, useEffect } from 'react';
import { Layout, Button } from '../components/Layout';
import { Transaction, User, TransactionType } from '../types';
import { StorageService } from '../services/storage';
import { Icons } from '../constants';

interface HistoryProps {
  user: User;
  onBack: () => void;
  mode: 'ALL' | 'DAILY' | 'TOTAL';
}

export const History: React.FC<HistoryProps> = ({ user, onBack, mode }) => {
  const getLocalDateStr = () => {
    const now = new Date();
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const day = String(now.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  };

  const [fromDate, setFromDate] = useState(getLocalDateStr());
  const [toDate, setToDate] = useState(getLocalDateStr());
  const [filteredTransactions, setFilteredTransactions] = useState<Transaction[]>([]);
  const [hasSearched, setHasSearched] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [selectedTx, setSelectedTx] = useState<Transaction | null>(null);

  // Fetch all transactions for this user
  const allUserTransactions = useMemo(() => {
    return StorageService.getTransactions(user.id);
  }, [user.id]);

  // For 'ALL' (Dashboard History) and 'TOTAL' (All Hisab) - Filter only Dashboard Entries
  const dashboardOnlyTransactions = useMemo(() => {
    return allUserTransactions.filter(t => t.type !== TransactionType.SEND_MONEY);
  }, [allUserTransactions]);

  const totals = useMemo(() => {
    const acc: Record<string, number> = {
      [TransactionType.CASH_IN]: 0,
      [TransactionType.CASH_OUT]: 0,
      [TransactionType.MOBILE_RECHARGE]: 0,
      [TransactionType.BILL_PAY]: 0,
    };
    
    dashboardOnlyTransactions.forEach(t => {
      if (acc[t.type] !== undefined) {
        acc[t.type] += t.amount;
      }
    });
    return acc;
  }, [dashboardOnlyTransactions]);

  const grandTotalValue = useMemo(() => {
    return (Object.values(totals) as number[]).reduce((a, b) => a + b, 0);
  }, [totals]);

  // Handle Initial Load
  useEffect(() => {
    if (mode === 'DAILY') {
      const today = getLocalDateStr();
      // UPDATED: Daily TX shows ALL transactions for today only (resets tomorrow)
      const results = allUserTransactions.filter(t => t.dateStr === today);
      setFilteredTransactions(results);
      setHasSearched(true);
    }
  }, [mode, allUserTransactions]);

  const handleSearch = () => {
    // Only for 'ALL' mode (Dashboard History)
    const results = dashboardOnlyTransactions.filter(t => t.dateStr >= fromDate && t.dateStr <= toDate);
    setFilteredTransactions(results);
    setHasSearched(true);
  };

  // --- DOWNLOAD LOGIC ---
  const handleDownloadSingle = async (tx: Transaction, type: 'pdf' | 'img') => {
    setSelectedTx(tx);
    // Wait for state to apply and DOM to render the hidden template
    setTimeout(async () => {
      const element = document.getElementById('single-receipt-capture');
      const jspdfLib = (window as any).jspdf;
      if (element && (window as any).html2canvas && jspdfLib) {
        try {
          setIsProcessing(true);
          element.style.display = 'block';
          element.style.position = 'absolute';
          element.style.left = '-9999px';

          const canvas = await (window as any).html2canvas(element, { useCORS: true, scale: 3 });
          const imgData = canvas.toDataURL('image/png');

          if (type === 'pdf') {
            const pdf = new jspdfLib.jsPDF('p', 'mm', 'a4');
            const pdfWidth = 210;
            const imgWidth = 140; // centered smaller width for single receipt
            const imgHeight = (canvas.height * imgWidth) / canvas.width;
            pdf.addImage(imgData, 'PNG', (pdfWidth - imgWidth) / 2, 20, imgWidth, imgHeight);
            pdf.save(`Receipt_${tx.id}.pdf`);
          } else {
            const link = document.createElement('a');
            link.href = imgData;
            link.download = `Receipt_${tx.id}.png`;
            link.click();
          }
          element.style.display = 'none';
        } catch (e) {
          alert("Download failed.");
        } finally {
          setIsProcessing(false);
          setSelectedTx(null);
        }
      }
    }, 100);
  };

  const handleDownloadGlobal = async (type: 'pdf' | 'img') => {
    const element = document.getElementById('history-report-content');
    const jspdfLib = (window as any).jspdf;
    if (element && (window as any).html2canvas && jspdfLib) {
      try {
        setIsProcessing(true);
        const canvas = await (window as any).html2canvas(element, { useCORS: true, scale: 2 });
        const imgData = canvas.toDataURL('image/png');
        if (type === 'pdf') {
          const pdf = new jspdfLib.jsPDF('p', 'mm', 'a4');
          const pdfWidth = 210;
          const imgHeight = (canvas.height * pdfWidth) / canvas.width;
          pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, imgHeight);
          pdf.save(`History_Report_${new Date().getTime()}.pdf`);
        } else {
          const link = document.createElement('a');
          link.href = imgData;
          link.download = `History_Report_${new Date().getTime()}.png`;
          link.click();
        }
      } catch (e) { alert("Download failed."); } finally { setIsProcessing(false); }
    }
  };

  if (mode === 'TOTAL') {
    return (
      <Layout title="Total All Hisab" onBack={onBack}>
        <div className="p-4 space-y-4">
           {isProcessing && (
              <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-[9999] flex flex-col items-center justify-center text-white p-6 text-center">
                 <div className="w-12 h-12 border-4 border-white/20 border-t-white rounded-full animate-spin mb-4"></div>
                 <p className="font-bold text-lg">Generating Summary...</p>
              </div>
           )}

           <div className="grid grid-cols-1 gap-4">
             {Object.entries(totals).map(([type, amount]) => (
                <div key={type} className="bg-white p-5 rounded-xl shadow-md border-l-4 border-brand-500 flex justify-between items-center animate-slide-up">
                  <span className="font-semibold text-gray-700">{type}</span>
                  <span className="text-xl font-bold text-brand-700">৳ {(amount as number).toFixed(2)}</span>
                </div>
             ))}
           </div>
           
           <div className="mt-8 bg-white p-5 rounded-xl shadow-lg border border-brand-100">
             <div className="flex justify-between items-center border-b border-dashed pb-3 mb-3">
               <span className="text-gray-500 font-medium">Dashboard Records</span>
               <span className="font-bold bg-gray-100 px-3 py-1 rounded-full text-sm">{dashboardOnlyTransactions.length}</span>
             </div>
             <div className="flex justify-between items-center">
                <span className="text-gray-600 font-bold uppercase tracking-wider text-xs">Grand Total Value</span>
                {/* Fixed Error: Explicitly casting grandTotalValue to number to fix 'unknown' inference */}
                <span className="font-bold text-2xl text-brand-600">৳ {(grandTotalValue as number).toFixed(2)}</span>
             </div>
           </div>

           <div className="grid grid-cols-1 gap-2 pt-4">
             <Button onClick={() => handleDownloadGlobal('pdf')} variant="secondary">Download PDF Summary</Button>
             <Button onClick={() => handleDownloadGlobal('img')} variant="primary">Download Image Summary</Button>
           </div>
        </div>

        {/* Total Hisab Hidden Element for Capture */}
        <div id="history-report-content" style={{ display: 'none' }} className="w-[400px] bg-white p-8 border">
           <h1 className="text-xl font-black text-center mb-6 uppercase text-brand-600">Digital NextGen Hub Summary</h1>
           <div className="space-y-4">
              {Object.entries(totals).map(([k, v]) => (
                /* Fixed Error: Explicitly casting v to number as Object.entries value might be inferred as unknown */
                <div key={k} className="flex justify-between border-b pb-2"><span className="font-bold">{k}</span><span>৳ {(v as number).toFixed(2)}</span></div>
              ))}
              {/* Fixed Error: Explicitly casting grandTotalValue to number to fix 'unknown' inference on line 185 */}
              <div className="pt-4 flex justify-between font-black text-lg border-t-2"><span>TOTAL</span><span>৳ {(grandTotalValue as number).toFixed(2)}</span></div>
           </div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout title={mode === 'DAILY' ? "Daily Transaction" : "Dashboard History"} onBack={onBack}>
      <div className="p-4 flex flex-col h-full overflow-y-auto no-scrollbar relative">
        {isProcessing && (
          <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-[9999] flex flex-col items-center justify-center text-white p-6 text-center">
             <div className="w-12 h-12 border-4 border-white/20 border-t-white rounded-full animate-spin mb-4"></div>
             <p className="font-bold text-lg">Processing...</p>
          </div>
        )}

        {mode === 'ALL' && (
          <div className="bg-white p-4 rounded-xl shadow-sm mb-4 space-y-3 no-print">
            <div className="flex gap-3">
              <div className="flex-1"><label className="text-xs font-bold text-gray-500 block mb-1">From</label><input type="date" value={fromDate} onChange={e => setFromDate(e.target.value)} className="w-full text-sm border p-2 rounded-lg"/></div>
              <div className="flex-1"><label className="text-xs font-bold text-gray-500 block mb-1">To</label><input type="date" value={toDate} onChange={e => setToDate(e.target.value)} className="w-full text-sm border p-2 rounded-lg"/></div>
            </div>
            <Button onClick={handleSearch} className="py-2">Search</Button>
          </div>
        )}

        <div id="history-report-content" className="bg-white p-4 rounded-xl shadow-sm min-h-[300px] mb-4">
           <div className="text-center mb-4 border-b pb-4">
              <h2 className="text-xl font-bold text-brand-700 uppercase">Digital NextGen Hub</h2>
              <p className="text-sm text-gray-500">{mode === 'DAILY' ? 'Today\'s All Activity' : 'Dashboard History'}</p>
           </div>
           <div className="space-y-4">
             {filteredTransactions.length === 0 ? (
               <p className="text-center text-gray-400 py-10">No records found for today.</p>
             ) : (
               filteredTransactions.map((tx, idx) => (
                 <div key={tx.id} className="border-b border-gray-100 pb-3 last:border-0">
                    <div className="flex justify-between items-center mb-1">
                      <div className="flex items-center gap-2"><span className="bg-gray-800 text-white text-[10px] font-bold px-1.5 py-0.5 rounded">#{idx + 1}</span><span className="text-[10px] font-bold text-gray-600">{new Date(tx.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</span></div>
                      <span className={`text-[9px] font-bold uppercase px-1.5 py-0.5 rounded ${tx.type === TransactionType.SEND_MONEY ? 'bg-indigo-50 text-indigo-600' : 'bg-brand-50 text-brand-600'}`}>{tx.type}</span>
                    </div>
                    <div className="flex justify-between items-start">
                       <div className="flex-1">
                          <div className="text-[10px] font-mono text-gray-400 truncate">ID: {tx.id}</div>
                          <div className="text-xs font-bold text-gray-800">{tx.mobileNumber} <span className="text-[10px] font-normal text-gray-500 ml-1">({tx.customerName})</span></div>
                       </div>
                       <div className="text-right flex flex-col items-end">
                          <p className="text-xs font-black text-brand-600 mb-1">৳ {tx.amount}</p>
                          
                          {/* UPDATED: Individual Download Buttons ONLY for Daily TX mode */}
                          {mode === 'DAILY' && (
                             <div className="flex gap-1">
                                <button onClick={() => handleDownloadSingle(tx, 'pdf')} className="p-1.5 bg-gray-100 text-gray-600 rounded-lg hover:bg-gray-200 active:scale-90 transition shadow-sm"><Icons.Download size={14}/></button>
                                <button onClick={() => handleDownloadSingle(tx, 'img')} className="p-1.5 bg-brand-50 text-brand-600 rounded-lg hover:bg-brand-100 active:scale-90 transition shadow-sm"><Icons.Camera size={14}/></button>
                             </div>
                          )}
                       </div>
                    </div>
                 </div>
               ))
             )}
           </div>
           
           {filteredTransactions.length > 0 && mode === 'ALL' && (
              <div className="mt-4 pt-3 border-t border-gray-200">
                <div className="flex justify-between font-bold text-[11px] text-gray-600 mb-4">
                   <span>Count: {filteredTransactions.length}</span>
                   {/* Explicitly cast reduce result to number for toFixed */}
                   <span>Total: ৳ {(filteredTransactions.reduce((acc, curr) => acc + curr.amount, 0) as number).toFixed(2)}</span>
                </div>
                <div className="grid grid-cols-1 gap-2 no-print">
                  <Button onClick={() => handleDownloadGlobal('pdf')} variant="secondary" className="py-2 text-xs">Download Full PDF</Button>
                  <Button onClick={() => handleDownloadGlobal('img')} variant="primary" className="py-2 text-xs">Download Full Image</Button>
                </div>
              </div>
           )}
        </div>

        {/* --- HIDDEN SINGLE RECEIPT TEMPLATE --- */}
        {selectedTx && (
          <div id="single-receipt-capture" style={{ display: 'none' }} className="w-[360px] bg-white overflow-hidden rounded-none font-sans relative">
             <div className="bg-brand-600 h-32 flex flex-col items-center justify-center text-white pb-4">
                <h2 className="text-lg font-black tracking-widest uppercase">Transaction Successful</h2>
                <p className="text-[10px] font-bold opacity-80 uppercase">Official Hub Record</p>
             </div>
             <div className="px-8 py-6 bg-white -mt-4 rounded-t-3xl relative">
                <div className="text-center mb-6">
                   <h3 className="text-gray-400 font-black uppercase text-[10px] tracking-widest mb-1">{selectedTx.type}</h3>
                   <div className="text-brand-600 text-4xl font-black">৳{selectedTx.amount + selectedTx.charge}</div>
                </div>
                <div className="border-b-2 border-dashed border-gray-100 mb-6"></div>
                <div className="space-y-4 text-xs">
                   <div className="flex justify-between">
                      <span className="text-gray-400 font-bold uppercase text-[9px]">Receipt ID</span>
                      <span className="font-black text-gray-800">{selectedTx.id}</span>
                   </div>
                   <div className="flex justify-between">
                      <span className="text-gray-400 font-bold uppercase text-[9px]">Mobile No</span>
                      <span className="font-black text-gray-800">{selectedTx.mobileNumber}</span>
                   </div>
                   <div className="flex justify-between">
                      <span className="text-gray-400 font-bold uppercase text-[9px]">Recipient</span>
                      <span className="font-black text-gray-800">{selectedTx.customerName}</span>
                   </div>
                   <div className="flex justify-between">
                      <span className="text-gray-400 font-bold uppercase text-[9px]">Net Amount</span>
                      <span className="font-black text-gray-800">৳{selectedTx.amount}</span>
                   </div>
                   <div className="flex justify-between">
                      <span className="text-gray-400 font-bold uppercase text-[9px]">Platform Charge</span>
                      <span className="font-black text-gray-800">৳{selectedTx.charge}</span>
                   </div>
                   <div className="flex justify-between border-t border-gray-50 pt-2">
                      <span className="text-gray-400 font-bold uppercase text-[9px]">Logged At</span>
                      <span className="font-bold text-gray-800">{new Date(selectedTx.timestamp).toLocaleString()}</span>
                   </div>
                </div>
                <div className="mt-10 pt-4 border-t border-gray-50 text-center">
                   <p className="text-[8px] text-gray-300 font-black uppercase tracking-[0.3em]">Verified by NextGen Hub</p>
                </div>
             </div>
          </div>
        )}
      </div>
    </Layout>
  );
};
