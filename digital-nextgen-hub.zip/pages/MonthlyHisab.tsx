import React, { useState, useMemo, useEffect } from 'react';
import { Layout, Button, Input } from '../components/Layout';
import { User, TransactionType, Transaction, MonthlyUpdate } from '../types';
import { StorageService } from '../services/storage';
import { Icons } from '../constants';

interface MonthlyHisabProps {
  user: User;
  onBack: () => void;
}

export const MonthlyHisab: React.FC<MonthlyHisabProps> = ({ user, onBack }) => {
  const [selectedPerson, setSelectedPerson] = useState('General');
  const [searchInput, setSearchInput] = useState('General');
  
  const [updateAmount, setUpdateAmount] = useState('');
  const [isUpdating, setIsUpdating] = useState(false);
  const [subtractAmount, setSubtractAmount] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [refreshTrigger, setRefreshTrigger] = useState(0);
  
  const [amount, setAmount] = useState('');
  const [charge, setCharge] = useState('');
  const [mobileNum, setMobileNum] = useState('');
  const [note, setNote] = useState('');
  const [saveStatus, setSaveStatus] = useState('');
  const [editTxId, setEditTxId] = useState<string | null>(null);

  // History Search States
  const [histMonth, setHistMonth] = useState(String(new Date().getMonth() + 1).padStart(2, '0'));
  const [histYear, setHistYear] = useState(String(new Date().getFullYear()));
  const [searchedHist, setSearchedHist] = useState<{ 
    transactions: Transaction[], 
    startingBalance: number,
    totalSpent: number,
    monthStr: string,
    formattedLabel: string
  } | null>(null);

  const months = [
    { label: 'January', value: '01' }, { label: 'February', value: '02' }, { label: 'March', value: '03' },
    { label: 'April', value: '04' }, { label: 'May', value: '05' }, { label: 'June', value: '06' },
    { label: 'July', value: '07' }, { label: 'August', value: '08' }, { label: 'September', value: '09' },
    { label: 'October', value: '10' }, { label: 'November', value: '11' }, { label: 'December', value: '12' }
  ];

  const years = ['2024', '2025', '2026', '2027', '2028', '2029', '2030'];

  const getLocalMonthStr = () => {
    const now = new Date();
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, '0');
    return `${year}-${month}`;
  };

  const getLocalDateStr = () => {
    const now = new Date();
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const day = String(now.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  };

  const currentMonth = useMemo(() => getLocalMonthStr(), []);
  
  const currentMonthFormatted = useMemo(() => {
    const [year, month] = currentMonth.split('-');
    return new Date(parseInt(year), parseInt(month) - 1).toLocaleString('default', { month: 'long', year: 'numeric' });
  }, [currentMonth]);

  const transactions = useMemo(() => StorageService.getTransactions(user.id), [user.id, refreshTrigger]);
  const updates = useMemo(() => StorageService.getMonthlyUpdates(user.id), [user.id, refreshTrigger]);

  const existingPersons = useMemo(() => {
    const names = new Set<string>(['General']);
    transactions.filter(t => t.type === TransactionType.SEND_MONEY).forEach(t => names.add(t.customerName));
    updates.forEach(u => { if (u.personName) names.add(u.personName); });
    return Array.from(names).filter(n => n && n.trim() !== '');
  }, [transactions, updates]);

  const expenseEntries = useMemo(() => {
    return transactions.filter(t => 
      t.dateStr.startsWith(currentMonth) && 
      t.type === TransactionType.SEND_MONEY &&
      t.customerName === selectedPerson
    );
  }, [transactions, currentMonth, selectedPerson]);
  
  const startingBalance = useMemo(() => {
    return updates
      .filter(u => u.month === currentMonth && (u.personName === selectedPerson || (!u.personName && selectedPerson === 'General')))
      .reduce((sum, u) => sum + (Number(u.addedAmount) || 0), 0);
  }, [updates, currentMonth, selectedPerson]);
  
  const totalSpent = useMemo(() => {
    return expenseEntries.reduce((sum, t) => sum + (Number(t.amount) || 0) + (Number(t.charge) || 0), 0);
  }, [expenseEntries]);

  const remaining = useMemo(() => startingBalance - totalSpent, [startingBalance, totalSpent]);

  const handleUpdateBalance = () => {
    const numAmount = parseFloat(updateAmount);
    if (isNaN(numAmount)) {
      alert("Please enter a valid number");
      return;
    }

    StorageService.saveMonthlyUpdate({
      id: "UPD" + Date.now().toString(),
      userId: user.id,
      month: currentMonth,
      addedAmount: numAmount,
      timestamp: new Date().toISOString(),
      personName: selectedPerson
    });
    
    setIsUpdating(false);
    setUpdateAmount('');
    setRefreshTrigger(prev => prev + 1);
    alert(`Initial balance set for ${selectedPerson}!`);
  };

  const handleSubtractBalance = () => {
    const numAmount = parseFloat(subtractAmount);
    if (isNaN(numAmount) || numAmount <= 0) {
      alert("Please enter a valid amount");
      return;
    }

    // Save as negative amount to effectively subtract from the startingBalance reduce logic
    StorageService.saveMonthlyUpdate({
      id: "SUB" + Date.now().toString(),
      userId: user.id,
      month: currentMonth,
      addedAmount: -numAmount,
      timestamp: new Date().toISOString(),
      personName: selectedPerson
    });
    
    setSubtractAmount('');
    setRefreshTrigger(prev => prev + 1);
    alert(`Balance subtracted successfully from ${selectedPerson}!`);
  };

  const handleRemoveInitialBalance = () => {
    if (window.confirm(`${selectedPerson} এর সেট করা মেইন ব্যালেন্স রিমুভ করতে চান?`)) {
      const allUpdates = localStorage.getItem('dnh_monthly_updates');
      if (allUpdates) {
        const parsed = JSON.parse(allUpdates);
        const filtered = parsed.filter((u: any) => !(u.userId === user.id && u.month === currentMonth && (u.personName === selectedPerson || (!u.personName && selectedPerson === 'General'))));
        localStorage.setItem('dnh_monthly_updates', JSON.stringify(filtered));
      }
      setRefreshTrigger(refreshTrigger + 1);
      alert(`ব্যালেন্স রিমুভ করা হয়েছে।`);
    }
  };

  const handleClearBalance = () => {
    if (window.confirm(`${selectedPerson} এর এই মাসের সমস্ত হিসাব মুছে ফেলতে চান?`)) {
      const allTx = localStorage.getItem('dnh_transactions');
      if (allTx) {
        const parsed = JSON.parse(allTx);
        const filtered = parsed.filter((t: any) => !(t.userId === user.id && t.dateStr.startsWith(currentMonth) && t.type === TransactionType.SEND_MONEY && t.customerName === selectedPerson));
        localStorage.setItem('dnh_transactions', JSON.stringify(filtered));
      }
      
      const allUpdates = localStorage.getItem('dnh_monthly_updates');
      if (allUpdates) {
        const parsed = JSON.parse(allUpdates);
        const filtered = parsed.filter((u: any) => !(u.userId === user.id && u.month === currentMonth && (u.personName === selectedPerson || (!u.personName && selectedPerson === 'General'))));
        localStorage.setItem('dnh_monthly_updates', JSON.stringify(filtered));
      }

      setRefreshTrigger(refreshTrigger + 1);
      alert(`${selectedPerson} এর হিসাব সফলভাবে ক্লিয়ার করা হয়েছে।`);
    }
  };

  const handleSaveSendMoney = () => {
    const numAmount = parseFloat(amount);
    if (isNaN(numAmount) || numAmount <= 0) {
      alert("Please enter a valid amount");
      return;
    }
    
    if (editTxId) {
      const existingTx = transactions.find(t => t.id === editTxId);
      if (existingTx) {
        const updatedTx: Transaction = {
          ...existingTx,
          amount: numAmount,
          charge: parseFloat(charge || '0'),
          mobileNumber: mobileNum || 'N/A',
          note: note || 'General'
        };
        StorageService.updateTransaction(updatedTx);
        setEditTxId(null);
        setSaveStatus(`তথ্য সফলভাবে আপডেট করা হয়েছে!`);
      }
    } else {
      const newTx: Transaction = {
        id: "TX" + Date.now().toString(),
        userId: user.id,
        type: TransactionType.SEND_MONEY,
        mobileNumber: mobileNum || 'N/A',
        customerName: selectedPerson,
        amount: numAmount,
        charge: parseFloat(charge || '0'),
        note: note || 'General',
        timestamp: new Date().toISOString(),
        dateStr: getLocalDateStr()
      };
      StorageService.saveTransaction(newTx);
      setSaveStatus(`${selectedPerson} এর জন্য তথ্য সফলভাবে সেভ করা হয়েছে!`);
    }
    
    setAmount('');
    setCharge('');
    setMobileNum('');
    setNote('');
    setRefreshTrigger(prev => prev + 1);
    setTimeout(() => setSaveStatus(''), 4000);
  };

  const handleEditEntry = (tx: Transaction) => {
    setEditTxId(tx.id);
    setAmount(tx.amount.toString());
    setCharge(tx.charge.toString());
    setMobileNum(tx.mobileNumber === 'N/A' ? '' : tx.mobileNumber);
    setNote(tx.note);
    // Scroll to form
    window.scrollTo({ top: 400, behavior: 'smooth' });
  };

  const handlePersonSwitch = () => {
    if (!searchInput.trim()) {
      alert("Please enter or select a name.");
      return;
    }
    setSelectedPerson(searchInput.trim());
    setSearchedHist(null);
  };

  const handleAddPerson = () => {
    if (!searchInput.trim()) {
      alert("নামটি আগে লিখুন।");
      return;
    }
    setSelectedPerson(searchInput.trim());
    alert(`${searchInput.trim()} সফলভাবে সক্রিয় করা হয়েছে। এখন তথ্য এন্ট্রি করলে এই নামটি লিস্টে জমা থাকবে।`);
  };

  const handleSearchHistory = () => {
    const targetMonthStr = `${histYear}-${histMonth}`;
    
    const histTxs = transactions.filter(t => 
      t.dateStr.startsWith(targetMonthStr) && 
      t.type === TransactionType.SEND_MONEY &&
      t.customerName === selectedPerson
    );
    const histBudget = updates
      .filter(u => u.month === targetMonthStr && (u.personName === selectedPerson || (!u.personName && selectedPerson === 'General')))
      .reduce((sum, u) => sum + (Number(u.addedAmount) || 0), 0);
    const histSpent = histTxs.reduce((sum, t) => sum + (Number(t.amount) || 0) + (Number(t.charge) || 0), 0);
    
    const label = months.find(m => m.value === histMonth)?.label + " " + histYear;

    if (histTxs.length === 0 && histBudget === 0) {
      alert(`${selectedPerson} এর জন্য এই মাসের কোনো তথ্য খুঁজে পাওয়া যায়নি।`);
      setSearchedHist(null);
      return;
    }

    setSearchedHist({
      transactions: histTxs,
      startingBalance: histBudget,
      totalSpent: histSpent,
      monthStr: targetMonthStr,
      formattedLabel: label
    });
  };

  const handleExport = async (type: 'pdf' | 'img', elementId: string, filename: string) => {
    const element = document.getElementById(elementId);
    const jspdfLib = (window as any).jspdf;
    
    if (element && (window as any).html2canvas && jspdfLib) {
      try {
        setIsProcessing(true);
        element.style.display = 'block';
        element.style.position = 'absolute';
        element.style.left = '-9999px';

        const canvas = await (window as any).html2canvas(element, { 
          useCORS: true, 
          scale: 2,
          logging: false 
        });
        
        const imgData = canvas.toDataURL('image/png');
        
        if (type === 'pdf') {
          const { jsPDF } = jspdfLib;
          const imgWidth = 210; 
          const pageHeight = 295; 
          const canvasImgHeight = (canvas.height * imgWidth) / canvas.width;
          
          const pdf = new jsPDF('p', 'mm', 'a4');
          let heightLeft = canvasImgHeight;
          let position = 0;

          pdf.addImage(imgData, 'PNG', 0, position, imgWidth, canvasImgHeight);
          heightLeft -= pageHeight;

          while (heightLeft > 0) {
            position = heightLeft - canvasImgHeight;
            pdf.addPage();
            pdf.addImage(imgData, 'PNG', 0, position, imgWidth, canvasImgHeight);
            heightLeft -= pageHeight;
          }
          pdf.save(`${filename}.pdf`);
        } else {
          const link = document.createElement('a');
          link.href = imgData;
          link.download = `${filename}.png`;
          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link);
        }
        
        element.style.display = 'none';
      } catch (e) {
        console.error("Export Error:", e);
        alert("Generation Failed.");
      } finally {
        setIsProcessing(false);
      }
    }
  };

  return (
    <Layout title={`Monthly Hisab - ${selectedPerson}`} onBack={onBack}>
      <div className="p-4 space-y-4 pb-24">
        
        {isProcessing && (
          <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-[9999] flex flex-col items-center justify-center text-white p-6 text-center">
             <div className="w-12 h-12 border-4 border-white/20 border-t-white rounded-full animate-spin mb-4"></div>
             <p className="font-bold text-lg text-white">Generating Statement...</p>
          </div>
        )}

        {/* --- PERSON SEARCH & SWITCHER --- */}
        <div className="bg-white p-3 rounded-2xl shadow-sm border border-brand-100 space-y-3 animate-fade-in">
           <div className="flex items-center gap-2">
              <div className="p-2 text-brand-500">
                <Icons.User size={20} />
              </div>
              <input 
                list="hisab-persons-list"
                placeholder="Search or Add Name..." 
                value={searchInput} 
                onChange={e => setSearchInput(e.target.value)}
                className="flex-1 bg-transparent border-none focus:ring-0 text-brand-800 font-black placeholder:text-brand-200 text-sm"
              />
              <datalist id="hisab-persons-list">
                 {existingPersons.map(p => <option key={p} value={p} />)}
              </datalist>
              <div className="flex gap-1">
                <button 
                  onClick={handlePersonSwitch}
                  className="bg-brand-600 text-white px-3 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest active:scale-95 transition"
                >
                  Switch
                </button>
                <button 
                  onClick={handleAddPerson}
                  className="bg-teal-600 text-white px-3 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest active:scale-95 transition flex items-center gap-1"
                >
                  <Icons.Plus size={12} /> Add
                </button>
              </div>
           </div>
           
           <div className="flex overflow-x-auto gap-2 no-scrollbar pb-1">
              {existingPersons.map(p => (
                <button
                  key={p}
                  onClick={() => {
                    setSelectedPerson(p);
                    setSearchInput(p);
                    setSearchedHist(null);
                  }}
                  className={`px-3 py-1.5 rounded-full text-[9px] font-black uppercase transition-all whitespace-nowrap border ${
                    selectedPerson === p 
                    ? 'bg-brand-600 text-white border-brand-600 shadow-md transform scale-105' 
                    : 'bg-white text-gray-500 border-gray-200 hover:border-brand-300'
                  }`}
                >
                  {p}
                </button>
              ))}
           </div>
        </div>

        {/* Current Balance Card */}
        <div className="bg-gradient-to-br from-brand-600 to-brand-800 rounded-2xl p-6 text-white shadow-xl">
          <div className="flex justify-between items-center mb-4">
            <span className="opacity-80 font-black uppercase tracking-widest text-[10px]">Budget of {selectedPerson}</span>
            <span className="text-[10px] bg-white/20 px-2 py-1 rounded font-bold">{currentMonthFormatted}</span>
          </div>
          <div className="text-4xl font-black mb-3">৳ {remaining.toFixed(2)}</div>
          <div className="flex justify-between text-[11px] opacity-75 mb-6 font-bold border-t border-white/10 pt-3">
             <span>Initial: {startingBalance.toFixed(2)}</span>
             <span>Spent: {totalSpent.toFixed(2)}</span>
          </div>
          
          <div className="space-y-3">
            {!isUpdating ? (
              <div className="flex gap-2">
                <button 
                  onClick={() => setIsUpdating(true)}
                  className="flex-1 bg-white text-brand-600 py-3 rounded-xl text-xs font-black transition active:scale-95 shadow-lg uppercase tracking-widest"
                >
                  Set Initial Balance
                </button>
                <button 
                  onClick={handleRemoveInitialBalance}
                  className="bg-white/20 text-white p-3 rounded-xl active:scale-95 transition shadow-lg"
                  title="Remove Main Balance"
                >
                  <Icons.Trash size={18} />
                </button>
              </div>
            ) : (
              <div className="bg-white/10 p-4 rounded-xl space-y-2 animate-fade-in border border-white/20">
                <Input 
                  type="number" 
                  placeholder={`Set Initial for ${selectedPerson}`} 
                  value={updateAmount} 
                  onChange={e => setUpdateAmount(e.target.value)}
                  className="text-black h-12"
                />
                <div className="flex gap-2">
                  <button onClick={handleUpdateBalance} className="flex-1 bg-green-500 py-3 rounded-lg font-black text-xs uppercase shadow-md">Confirm</button>
                  <button onClick={() => setIsUpdating(false)} className="flex-1 bg-white/20 py-3 rounded-lg font-black text-xs uppercase">Cancel</button>
                </div>
              </div>
            )}
            <button onClick={handleClearBalance} className="w-full bg-red-500 py-3 rounded-xl text-xs font-black shadow-lg uppercase tracking-widest">Clear Records</button>
          </div>
        </div>

        {/* --- SUBTRACT BALANCE ENTRY SECTION --- */}
        <div className="bg-white p-5 rounded-2xl shadow-sm border border-brand-100 border-l-4">
           <h3 className="font-black text-brand-600 mb-3 text-[10px] uppercase tracking-widest flex items-center gap-2">
             <Icons.Trash size={14} /> Subtract from Balance
           </h3>
           <div className="flex gap-2">
              <Input 
                type="number" 
                placeholder="Enter amount to subtract" 
                value={subtractAmount} 
                onChange={e => setSubtractAmount(e.target.value)} 
                className="flex-1"
              />
              <button 
                onClick={handleSubtractBalance}
                className="bg-red-600 text-white px-6 py-2 rounded-xl text-xs font-black uppercase tracking-widest active:scale-95 transition shadow-md"
              >
                Subtract
              </button>
           </div>
        </div>

        {/* Expense Form */}
        <div className="bg-white p-5 rounded-2xl shadow-sm border border-gray-100">
           <h3 className="font-black text-gray-700 mb-4 border-b border-gray-50 pb-3 text-[10px] uppercase tracking-widest flex items-center gap-2">
             <div className="w-2 h-2 rounded-full bg-brand-500"></div>
             {editTxId ? `Update Entry for ${selectedPerson}` : `Add Expense for ${selectedPerson}`}
           </h3>
           <div className="space-y-4">
             <Input type="number" placeholder="Amount" value={amount} onChange={e => setAmount(e.target.value)} />
             <div className="grid grid-cols-2 gap-2">
               <Input type="number" placeholder="Charge" value={charge} onChange={e => setCharge(e.target.value)} />
               <Input type="tel" placeholder="Mobile Number" value={mobileNum} onChange={e => setMobileNum(e.target.value)} maxLength={11} />
             </div>
             <Input type="text" placeholder="Note (Ref)" value={note} onChange={e => setNote(e.target.value)} />
             <Button onClick={handleSaveSendMoney} className="font-black uppercase tracking-widest py-4">
               {editTxId ? 'Update Info' : 'Save Expense'}
             </Button>
             
             {saveStatus && (
               <div className="mt-2 text-[10px] font-black text-green-600 flex items-center justify-center gap-2 animate-slide-up bg-green-50 p-3 rounded-xl border border-green-100">
                 <div className="w-4 h-4 bg-green-500 text-white rounded-full flex items-center justify-center text-[8px] font-black">✓</div>
                 {saveStatus}
               </div>
             )}
           </div>
        </div>

        {/* RECENT ENTRIES WITH EDIT ACTION */}
        <div className="space-y-3">
           <h3 className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-1">Recent Entries</h3>
           {expenseEntries.slice(0, 10).reverse().map((tx) => (
             <div key={tx.id} className="bg-white p-4 rounded-2xl border border-gray-100 flex justify-between items-center shadow-sm animate-fade-in">
                <div>
                   <p className="text-xs font-black text-gray-800">{tx.note}</p>
                   <p className="text-[9px] text-gray-400 font-bold uppercase">{tx.mobileNumber} • {new Date(tx.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</p>
                </div>
                <div className="flex items-center gap-3">
                   <p className="text-sm font-black text-brand-600">৳{tx.amount}</p>
                   <button onClick={() => handleEditEntry(tx)} className="p-2 bg-gray-100 rounded-lg text-gray-500 active:bg-brand-50 active:text-brand-600 transition">
                      <Icons.Edit size={14} />
                   </button>
                </div>
             </div>
           ))}
        </div>

        {/* --- HISTORY SEARCH SECTION --- */}
        <div className="bg-white p-5 rounded-2xl shadow-sm border border-brand-100 border-l-4">
           <h3 className="font-black text-brand-600 mb-4 text-[10px] uppercase tracking-widest flex items-center gap-2">
             <Icons.History size={14} /> {selectedPerson}'s Past Statements
           </h3>
           
           <div className="flex gap-2 items-end mb-4">
              <div className="flex-1">
                 <label className="text-[9px] font-bold text-gray-400 uppercase ml-1">Select Month</label>
                 <select 
                   value={histMonth}
                   onChange={e => setHistMonth(e.target.value)}
                   className="w-full px-3 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm font-bold focus:outline-none focus:ring-2 focus:ring-brand-500"
                 >
                   {months.map(m => <option key={m.value} value={m.value}>{m.label}</option>)}
                 </select>
              </div>
              <div className="flex-1">
                 <label className="text-[9px] font-bold text-gray-400 uppercase ml-1">Select Year</label>
                 <select 
                   value={histYear}
                   onChange={e => setHistYear(e.target.value)}
                   className="w-full px-3 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm font-bold focus:outline-none focus:ring-2 focus:ring-brand-500"
                 >
                   {years.map(y => <option key={y} value={y}>{y}</option>)}
                 </select>
              </div>
              <button 
                onClick={handleSearchHistory}
                className="bg-brand-600 text-white p-2.5 rounded-xl shadow-md active:scale-90 transition-transform flex items-center justify-center min-w-[50px]"
                title="Search History"
              >
                <Icons.TrendingUp size={20} />
              </button>
           </div>

           {searchedHist && (
             <div className="mt-6 animate-fade-in border-t border-dashed border-gray-200 pt-6 space-y-4">
                <div className="bg-brand-50 rounded-2xl p-4 border border-brand-100">
                   <p className="text-[10px] text-brand-600 font-black uppercase mb-2">Report For: {selectedPerson} ({searchedHist.formattedLabel})</p>
                   <div className="grid grid-cols-2 gap-4">
                      <div>
                         <p className="text-[9px] font-bold text-gray-400 uppercase">Total Budget</p>
                         <p className="text-sm font-black text-gray-800">৳ {searchedHist.startingBalance.toFixed(2)}</p>
                      </div>
                      <div className="text-right">
                         <p className="text-[9px] font-bold text-gray-400 uppercase">Remaining</p>
                         <p className="text-sm font-black text-green-600">৳ {(searchedHist.startingBalance - searchedHist.totalSpent).toFixed(2)}</p>
                      </div>
                   </div>
                </div>

                <div className="flex flex-col gap-2">
                   <Button onClick={() => handleExport('pdf', 'searched-report-capture', `Statement_${selectedPerson}_${searchedHist.monthStr}`)} variant="secondary" className="py-3 font-black text-[10px] uppercase tracking-widest flex items-center justify-center gap-2">
                      <Icons.Download size={14} /> Download PDF History
                   </Button>
                   <Button onClick={() => handleExport('img', 'searched-report-capture', `Statement_${selectedPerson}_${searchedHist.monthStr}`)} variant="primary" className="py-3 font-black text-[10px] uppercase tracking-widest flex items-center justify-center gap-2">
                      <Icons.Camera size={14} /> Download Image History
                   </Button>
                </div>
             </div>
           )}
        </div>

        {/* --- REPORT CAPTURE AREA (Hidden) --- */}
        <div id="searched-report-capture" style={{ display: 'none' }} className="w-[800px] bg-white p-12 font-sans text-gray-800">
           <div className="text-center border-b-4 border-brand-600 pb-8 mb-8">
              <h1 className="text-6xl font-black text-brand-700 uppercase tracking-tighter mb-1">Digital NextGen Hub</h1>
              <p className="text-xl text-gray-400 uppercase font-bold tracking-[0.3em]">Monthly Statement of Accounts</p>
           </div>

           <div className="grid grid-cols-2 gap-10 mb-8">
              <div className="space-y-1">
                 <p className="text-[10px] text-brand-600 font-black uppercase tracking-widest">Statement For</p>
                 <p className="text-3xl font-black text-gray-900">{selectedPerson}</p>
              </div>
              <div className="text-right space-y-1">
                 <p className="text-[10px] text-brand-600 font-black uppercase tracking-widest">Statement</p>
                 <p className="text-2xl font-black text-gray-900 uppercase">{searchedHist?.formattedLabel || 'Report'}</p>
                 <p className="text-xs text-gray-400 italic">Generated: {new Date().toLocaleString()}</p>
              </div>
           </div>

           <div className="bg-gray-50 rounded-xl p-5 grid grid-cols-3 gap-4 mb-8 border border-gray-100">
              <div className="text-center border-r border-gray-200">
                 <p className="text-[8px] text-gray-400 font-black uppercase mb-0.5 tracking-wider">Initial Budget</p>
                 <p className="text-xl font-black text-gray-800">৳ {searchedHist?.startingBalance.toFixed(2)}</p>
              </div>
              <div className="text-center border-r border-gray-200">
                 <p className="text-[8px] text-gray-400 font-black uppercase mb-0.5 tracking-wider">Spent This Month</p>
                 <p className="text-xl font-black text-red-600">৳ {searchedHist?.totalSpent.toFixed(2)}</p>
              </div>
              <div className="text-center">
                 <p className="text-[8px] text-gray-400 font-black uppercase mb-0.5 tracking-wider">Net Remaining</p>
                 <p className="text-xl font-black text-green-600">৳ {( (searchedHist?.startingBalance || 0) - (searchedHist?.totalSpent || 0) ).toFixed(2)}</p>
              </div>
           </div>

           <div className="mb-10">
              <h3 className="text-xl font-black border-b border-gray-100 pb-3 mb-6 uppercase text-gray-700 tracking-[0.2em]">Detailed Breakdown</h3>
              <table className="w-full text-left border-collapse">
                 <thead>
                    <tr className="bg-brand-600 text-white">
                       <th className="p-4 text-[9px] font-black uppercase tracking-widest">Date</th>
                       <th className="p-4 text-[9px] font-black uppercase tracking-widest">Amount</th>
                       <th className="p-4 text-[9px] font-black uppercase tracking-widest">Charges</th>
                       <th className="p-4 text-[9px] font-black uppercase tracking-widest">Total</th>
                       <th className="p-4 text-[9px] font-black uppercase tracking-widest">Mobile</th>
                       <th className="p-4 text-[9px] font-black uppercase tracking-widest">Note/Ref</th>
                    </tr>
                 </thead>
                 <tbody>
                    {searchedHist?.transactions.map((tx, idx) => (
                        <tr key={tx.id} className="border-b border-gray-50 hover:bg-brand-50/10">
                           <td className="p-4 text-xs font-black text-gray-800">{tx.dateStr}</td>
                           <td className="p-4 text-xs font-bold">৳ {tx.amount.toFixed(2)}</td>
                           <td className="p-4 text-xs font-medium text-gray-400">৳ {tx.charge.toFixed(2)}</td>
                           <td className="p-4 text-xs font-black text-brand-600">৳ {(tx.amount + tx.charge).toFixed(2)}</td>
                           <td className="p-4 text-xs font-bold text-gray-800">{tx.mobileNumber}</td>
                           <td className="p-4 text-xs text-gray-500 font-medium italic">{tx.note}</td>
                        </tr>
                    ))}
                    {searchedHist?.transactions.length === 0 && (
                      <tr><td colSpan={6} className="p-16 text-center text-gray-300 font-black uppercase tracking-widest">No Expenses Found</td></tr>
                    )}
                 </tbody>
              </table>
           </div>

           <div className="mt-16 pt-8 border-t border-dashed border-gray-200 text-center">
              <p className="text-[9px] text-gray-400 font-black uppercase tracking-widest">Official Secure Statement - Verified by Digital NextGen Hub</p>
           </div>
        </div>

      </div>
    </Layout>
  );
};