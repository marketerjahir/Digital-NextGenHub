
import React, { useState } from 'react';
import { Layout } from '../components/Layout';

export const Calculator: React.FC<{ onBack: () => void }> = ({ onBack }) => {
  const [display, setDisplay] = useState('0');
  const [expression, setExpression] = useState('');
  const [prev, setPrev] = useState<string | null>(null);
  const [op, setOp] = useState<string | null>(null);
  const [newNum, setNewNum] = useState(true);

  const handleNum = (n: string) => {
    if (newNum) {
      setDisplay(n);
      setNewNum(false);
    } else {
      setDisplay(display === '0' ? n : display + n);
    }
  };

  const handleOp = (operator: string) => {
    setOp(operator);
    setPrev(display);
    setExpression(`${display} ${operator}`);
    setNewNum(true);
  };

  const calculate = () => {
    if (!prev || !op) return;
    const a = parseFloat(prev);
    const b = parseFloat(display);
    let res = 0;
    switch (op) {
      case '+': res = a + b; break;
      case '-': res = a - b; break;
      case '×': res = a * b; break;
      case '÷': res = a / b; break;
    }
    const resultStr = String(parseFloat(res.toFixed(8)));
    setExpression(`${prev} ${op} ${display} =`);
    setDisplay(resultStr);
    setOp(null);
    setPrev(null);
    setNewNum(true);
  };

  const clear = () => {
    setDisplay('0');
    setExpression('');
    setPrev(null);
    setOp(null);
    setNewNum(true);
  };

  const handlePercent = () => {
    const val = parseFloat(display) / 100;
    setDisplay(String(val));
  };

  const handlePlusMinus = () => {
    if (display.startsWith('-')) {
      setDisplay(display.substring(1));
    } else if (display !== '0') {
      setDisplay('-' + display);
    }
  };

  const Btn = ({ v, c, onClick, span }: any) => (
    <button 
      onClick={onClick || (() => handleNum(v))} 
      className={`
        ${c || 'bg-white text-gray-800 hover:bg-gray-50'} 
        ${span ? span : ''}
        p-4 rounded-2xl text-xl font-bold shadow-sm active:scale-95 transition-all duration-150 flex items-center justify-center border border-gray-100
      `}
    >
      {v}
    </button>
  );

  return (
    <Layout title="Modern Calculator" onBack={onBack} className="bg-gray-50">
      <div className="p-4 flex flex-col h-[calc(100vh-80px)]">
        {/* Display Area */}
        <div className="bg-white p-6 rounded-3xl mb-6 shadow-xl shadow-brand-100/50 flex flex-col items-end justify-center min-h-[160px] border border-brand-50 relative overflow-hidden">
          <div className="absolute top-0 right-0 p-3">
             <div className="bg-brand-50 px-2 py-0.5 rounded text-[8px] font-black text-brand-600 uppercase tracking-widest">Dynamic Precise</div>
          </div>
          <div className="text-gray-400 text-sm font-bold mb-2 h-6 tracking-wide truncate w-full text-right uppercase">
            {expression}
          </div>
          <div className="text-gray-900 text-5xl font-black break-all w-full text-right tracking-tight leading-tight">
            {display}
          </div>
        </div>

        {/* Keypad */}
        <div className="grid grid-cols-4 gap-3 flex-1 pb-4">
          <Btn v="AC" c="bg-red-50 text-red-600 hover:bg-red-100" onClick={clear} />
          <Btn v="±" c="bg-brand-50 text-brand-600 hover:bg-brand-100" onClick={handlePlusMinus} />
          <Btn v="%" c="bg-brand-50 text-brand-600 hover:bg-brand-100" onClick={handlePercent} />
          <Btn v="÷" c="bg-brand-100 text-brand-700 hover:bg-brand-200" onClick={() => handleOp('÷')} />
          
          <Btn v="7" /> <Btn v="8" /> <Btn v="9" />
          <Btn v="×" c="bg-brand-100 text-brand-700 hover:bg-brand-200" onClick={() => handleOp('×')} />
          
          <Btn v="4" /> <Btn v="5" /> <Btn v="6" />
          <Btn v="-" c="bg-brand-100 text-brand-700 hover:bg-brand-200" onClick={() => handleOp('-')} />

          <Btn v="1" /> <Btn v="2" /> <Btn v="3" />
          <Btn v="+" c="bg-brand-100 text-brand-700 hover:bg-brand-200" onClick={() => handleOp('+')} />

          <Btn v="0" span="col-span-2" />
          <Btn v="." />
          <Btn v="=" c="bg-brand-600 text-white hover:bg-brand-700 shadow-lg shadow-brand-200" onClick={calculate} />
        </div>

        <div className="text-center py-2">
           <p className="text-[8px] text-gray-300 font-bold uppercase tracking-[0.4em]">Professional Computing Core</p>
        </div>
      </div>
    </Layout>
  );
};
